var mx
var my
var turn=1;
var t=1;
var clickvalidation=0;
var delayvalidate=0
var gmovedirection=new Array(5);
var gfinalmovevalue=0;
var bmovedirection=new Array(5);
var bfinalmovevalue=0;
var rmovedirection=new Array(5);
var rfinalmovevalue=0;
var ymovedirection=new Array(5);
var yfinalmovevalue=0;
var a=1;
var dicevalue;
var i=0;
var gmovepawn;
var dice
var bmovepawn;
var rmovepawn;
var ymovepawn;
var moveconsent=0;
var p
var q
var r
var s
var dicevalues=new Array(10);
var dval;
var b=0;
var special=0;
var j;
var val;
var allowselect=0;
var valueselected;
var specialgame=1;
var check=0;
var killvalid=0;
var ma=new Array(5);
var mac=new Array(5);
var gkill=0;
var bkill=0;
var ykill=0;
var rkill=0;
var sp;
var g1curposition=1;
var g2curposition=1;
var g3curposition=1;
var g4curposition=1;
var b1curposition=1;
var b2curposition=1;
var b3curposition=1;
var b4curposition=1;
var r1curposition=1;
var r2curposition=1;
var r3curposition=1;
var r4curposition=1;
var y1curposition=1;
var y2curposition=1;
var y3curposition=1;
var y4curposition=1;
var killchance=0;
var c;
var d=0;
var killvalidate;
var nkillchance;
var bkillchance;
var rkillchance;
var ykillchance;
var k;
var kb=0;
var kg=0;
var kr=0;
var ky=0;
var specialchance=0;
var gmultikill=0;
var rmultikill=0;
var ymultikill=0;
var bmultikill=0;
var killchoice;
var c;
var g1expectedpos
var g2expectedpos
var g3expectedpos
var g4expectedpos
var b1expectedpos
var b2expectedpos
var b3expectedpos
var b4expectedpos
var r1expectedpos
var r2expectedpos
var r3expectedpos
var r4expectedpos
var y1expectedpos
var y2expectedpos
var y3expectedpos
var y4expectedpos
var gbtest
var grtest
var gytest
var bgtest
var brtest
var bytest
var rbtest
var rgtest
var rytest
var ybtest
var ygtest
var yrtest
var gmove1=0
var gmove2=0
var bmove1=0
var bmove2=0
var rmove1=0
var rmove2=0
var ymove1=0
var ymove2=0
var n1
var n2
var n3
var n4
var bwin=0;
var gwin=0;
var rwin=0;
var ywin=0;
mac[1]=0;
mac[2]=0;
mac[3]=0;
mac[4]=0;
mac[5]=0;
/*ma[1]=0;
ma[2]=0;
ma[3]=0;
ma[4]=0;
ma[5]=0;*/
dicevalues[1]=0;
dicevalues[2]=0;
dicevalues[3]=0;
dicevalues[4]=0;
dicevalues[5]=0;
gmovedirection[1]=0;
gmovedirection[2]=0;
gmovedirection[3]=0;
gmovedirection[4]=0;
bmovedirection[1]=0;
bmovedirection[2]=0;
bmovedirection[3]=0;
bmovedirection[4]=0;
rmovedirection[1]=0;
rmovedirection[2]=0;
rmovedirection[3]=0;
rmovedirection[4]=0;
ymovedirection[1]=0;
ymovedirection[2]=0;
ymovedirection[3]=0;
ymovedirection[4]=0;
function resetall(){
    console.log("resetting everything")
    text6.color="#719500"
    bwin=0;
    gwin=0;
    rwin=0;
    ywin=0;
    //text6.text=n1
    greenturn.opacity=1;
    blueturn.opacity=0;
    redturn.opacity=0;
    yellowturn.opacity=0;
    g1.x=166
    g1.y=290
    g2.x=198
    g2.y=300
    g3.x=184
    g3.y=328
    g4.x=150
    g4.y=320
    b1.x=290
    b1.y=158
    b2.x=320
    b2.y=150
    b3.x=336
    b3.y=182
    b4.x=300
    b4.y=192
    r1.x=174
    r1.y=16
    r2.x=188
    r2.y=30
    r3.x=174
    r3.y=42
    r4.x=160
    r4.y=30
    y1.x=24
    y1.y=160
    y2.x=48
    y2.y=160
    y3.x=48
    y3.y=184
    y4.x=24
    y4.y=184
    specialgame=1;
    check=0;
    killvalid=0;
    allowselect=0
    kb=0;
    kg=0;
    kr=0;
    ky=0;
    a=1;
    i=0;
    moveconsent=0
    gfinalmovevalue=0
    yfinalmovevalue=0
    rfinalmovevalue=0
    bfinalmovevalue=0
    b=0
    special=0
    d=0
    t=1
    check=0;
    killvalid=0;
    g1curposition=0;
    g2curposition=0;
    g3curposition=0;
    g4curposition=0;
    b1curposition=0;
    b2curposition=0;
    b3curposition=0;
    b4curposition=0;
    r1curposition=0;
    r2curposition=0;
    r3curposition=0;
    r4curposition=0;
    y1curposition=0;
    y2curposition=0;
    y3curposition=0;
    y4curposition=0;
    gmove1=0
    gmove2=0
    bmove1=0
    bmove2=0
    rmove1=0
    rmove2=0
    ymove1=0
    ymove2=0
    mac[1]=0;
    mac[2]=0;
    mac[3]=0;
    mac[4]=0;
    mac[5]=0;
    dicevalues[1]=0;
    dicevalues[2]=0;
    dicevalues[3]=0;
    dicevalues[4]=0;
    dicevalues[5]=0;
    gmovedirection[1]=0;
    gmovedirection[2]=0;
    gmovedirection[3]=0;
    gmovedirection[4]=0;
    bmovedirection[1]=0;
    bmovedirection[2]=0;
    bmovedirection[3]=0;
    bmovedirection[4]=0;
    rmovedirection[1]=0;
    rmovedirection[2]=0;
    rmovedirection[3]=0;
    rmovedirection[4]=0;
    ymovedirection[1]=0;
    ymovedirection[2]=0;
    ymovedirection[3]=0;
    ymovedirection[4]=0;
    console.log("resetting over")
    return;
}

function movepawn(mx,my){

    if(t==1){
    if((((g1.x-16)<mx)&&((g1.x+41)>mx))&&(((g1.y-3)<my)&&((g1.y+51)>my))){

        greenmovevalidation(g1);
        }
   else if((((g2.x-48)<mx)&&((g2.x+8)>mx))&&(((g2.y-13)<my)&&((g2.y+41)>my))){

        greenmovevalidation(g2);
       }
    else if((((g3.x-34)<mx)&&((g3.x+22)>mx))&&(((g3.y-41)<my)&&((g3.y+13)>my))){

        greenmovevalidation(g3);
        }
    else if(((g4.x<mx)&&((g4.x+56)>mx))&&(((g4.y-33)<my)&&((g4.y+21)>my))){

        greenmovevalidation(g4);
       }
        }
    if(t==2){
        if(((b1.x<mx)&&((b1.x+56)>mx))&&(((b1.y-11)<my)&&((b1.y+43)>my))){

            bluemovevalidation(b1);}
       else if((((b2.x-30)<mx)&&((b2.x+26)>mx))&&(((b2.y-3)<my)&&((b2.y+51)>my))){

             bluemovevalidation(b2);}
        else if((((b3.x-46)<mx)&&((b3.x+10)>mx))&&(((b3.y-35)<my)&&((b3.y+19)>my))){

         bluemovevalidation(b3);}
        else if((((b4.x-10)<mx)&&((b4.x+46)>mx))&&(((b4.y-45)<my)&&((b4.y+9)>my))){     
            bluemovevalidation(b4);
}
}
    if(t==3){
        if((((r1.x-23)<mx)&&((r1.x+33)>mx))&&(((r1.y-10)<my)&&((r1.y+46)>my))){
            redmovevalidation(r1);}
       else if((((r2.x-37)<mx)&&((r2.x+19)>mx))&&(((r2.y-24)<my)&&((r2.y+32)>my))){         
             redmovevalidation(r2);}
        else if((((r3.x-23)<mx)&&((r3.x+33)>mx))&&(((r3.y-36)<my)&&((r3.y+20)>my))){
             redmovevalidation(r3);}
        else if((((r4.x-9)<mx)&&((r4.x+47)>mx))&&(((r4.y-24)<my)&&((r4.y+32)>my))){
             redmovevalidation(r4);}

    }

    if(t==4){
        if((((y1.x-18)<mx)&&((y1.x+44)>mx))&&(((y1.y-12)<my)&&((y1.y+44)>my))){
            yellowmovevalidation(y1);}
       else if((((y2.x-42)<mx)&&((y2.x+20)>mx))&&(((y2.y-12)<my)&&((y2.y+44)>my))){
            yellowmovevalidation(y2);}
        else if((((y3.x-42)<mx)&&((y3.x+20)>mx))&&(((y3.y-36)<my)&&((y3.y+20)>my))){
             yellowmovevalidation(y3);}
        else if((((y4.x-18)<mx)&&((y4.x+44)>mx))&&(((y4.y-36)<my)&&((y4.y+20)>my))){
            yellowmovevalidation(y4);
    }
}


}
function greenmovevalidation(pw){
    if(allowselect!=1){
    g1expectedpos=g1curposition+dicevalue;
    g2expectedpos=g2curposition+dicevalue;
    g3expectedpos=g3curposition+dicevalue;
    g4expectedpos=g4curposition+dicevalue;

    console.log("g1expected value="+g1expectedpos)
    console.log("g2expected value="+g2expectedpos)
    console.log("g3expected value="+g3expectedpos)
    console.log("g4expected value="+g4expectedpos)
    if((g1expectedpos>25)&&(g2expectedpos>25)&&(g3expectedpos>25)&&(g4expectedpos>25)){
        console.log("no valid moves for green");
       // turnchange();
        image10.opacity=1;
        nomove.running=true;
    }


  else{  if(pw==g1)  {
        console.log("greenmovevalidationcalled")
    g1expectedpos=g1curposition+dicevalue;
        if(g1expectedpos<=16){
            gmove1=1;
        }
            if(g1expectedpos>=17){
                if(gkill>=1){
                    gmove1=1;
                }
                else{
                    image11.opacity=1;
                    cantmove.running=true;
                }
            }
            if(g1expectedpos>25){
                image11.opacity=1;
                cantmove.running=true;
                console.log("no valid move")
            }
            else{
                gmove2=1;
            }
            if((gmove1==1)&&(gmove2==1)){
                if(allowselect==1){

                    diceclick.enabled=false;
                    selectionmove(g1)
                }
                else if(specialchance>0){
                    specialfunction(g1);
                }else

                {
                    diceclick.enabled=false;
                gmovepawn=1;
               moveconsent=1;
                tg1.running=true;
            }
            }
        }



    else if(pw==g2) {
    g2expectedpos=g2curposition+dicevalue;
        if(g2expectedpos<=16){
            gmove1=1;
        }
            if(g2expectedpos>=17){
                if(gkill>=1){
                    gmove1=1;
                }
                else{
                    image11.opacity=1;
                    cantmove.running=true;
                    console.log("no valid move for this pawn you dont have a kill yet")
                }
            }
            if(g2expectedpos>25){
                image11.opacity=1;
                cantmove.running=true;
                console.log("novalid move")
            }
            else{
                gmove2=1;
            }
            if((gmove1==1)&&(gmove2==1)){
                if(allowselect==1){
                    diceclick.enabled=false;
                    selectionmove(g2)
                }
                else if(specialchance>0){
                    specialfunction(g2);}
        else{   diceclick.enabled=false;
                gmovepawn=2;
                 moveconsent=1;
                tg1.running=true;
            }
            }
}
    else  if(pw==g3) {
        g3expectedpos=g3curposition+dicevalue;
        if(g3expectedpos<=16){
            gmove1=1;
        }
            if(g3expectedpos>=17){
                if(gkill>=1){
                    gmove1=1;
                }
                else{
                    image11.opacity=1;
                    cantmove.running=true;
                    console.log("no valid move for this pawn you dont have a kill yet")
                }
            }
            if(g3expectedpos>25){
                image11.opacity=1;
                cantmove.running=true;
                console.log("no valid move")
            }
            else{
                gmove2=1;
            }
            if((gmove1==1)&&(gmove2==1)){
                if(allowselect==1){
                    diceclick.enabled=false;
                    selectionmove(g3)
                }
                else if(specialchance>0){
                    specialfunction(g3);}
                else{   diceclick.enabled=false;
                    gmovepawn=3;
                    moveconsent=1;
                    tg1.running=true;
                }
            }
    }
    else  if(pw==g4) {
        g4expectedpos=g4curposition+dicevalue;
        if(g4expectedpos<=16){
            gmove1=1;
        }
            if(g4expectedpos>=17){
                if(gkill>=1){
                    gmove1=1;
                }
                else{
                    image11.opacity=1;
                    cantmove.running=true;
                    console.log("no valid move for this pawn you dont have a kill yet")
                }
            }
            if(g4expectedpos>25){
                image11.opacity=1;
                cantmove.running=true;
                console.log("no valid move")
            }
            else{
                gmove2=1;
            }
            if((gmove1==1)&&(gmove2==1)){
                if(allowselect==1){
                    diceclick.enabled=false;
                    selectionmove(g4)
                }
                else if(specialchance>0){
                    specialfunction(g4);}
        else{   diceclick.enabled=false;
                gmovepawn=4;
                 moveconsent=1;
                tg1.running=true;
            }
            }

    }
}}
    else if(allowselect==1){


        g1expectedpos=g1curposition+valueselected;
        g2expectedpos=g2curposition+valueselected;
        g3expectedpos=g3curposition+valueselected;
        g4expectedpos=g4curposition+valueselected;

        console.log("g1expected value="+g1expectedpos)
        console.log("g2expected value="+g2expectedpos)
        console.log("g3expected value="+g3expectedpos)
        console.log("g4expected value="+g4expectedpos)
        if((g1expectedpos>25)&&(g2expectedpos>25)&&(g3expectedpos>25)&&(g4expectedpos>25)){
            console.log("no valid moves for green");
           // turnchange();
            image10.opacity=1;
            nomove.running=true;
        }


      else{  if(pw==g1)  {
            console.log("greenmovevalidationcalled")
        g1expectedpos=g1curposition+valueselected;
            if(g1expectedpos<=16){
                gmove1=1;
            }
                if(g1expectedpos>=17){
                    if(gkill>=1){
                        gmove1=1;
                    }
                    else{
                        image11.opacity=1;
                        cantmove.running=true;
                    }
                }
                if(g1expectedpos>25){
                    image11.opacity=1;
                    cantmove.running=true;
                    console.log("no valid move")
                }
                else{
                    gmove2=1;
                }
                if((gmove1==1)&&(gmove2==1)){
                    if(allowselect==1){

                        diceclick.enabled=false;
                        selectionmove(g1)
                    }
                    else if(specialchance>0){
                        specialfunction(g1);
                    }else

                    {
                        diceclick.enabled=false;
                    gmovepawn=1;
                   moveconsent=1;
                    tg1.running=true;
                }
                }
            }



        else if(pw==g2) {
        g2expectedpos=g2curposition+valueselected;
            if(g2expectedpos<=16){
                gmove1=1;
            }
                if(g2expectedpos>=17){
                    if(gkill>=1){
                        gmove1=1;
                    }
                    else{
                        image11.opacity=1;
                        cantmove.running=true;
                        console.log("no valid move for this pawn you dont have a kill yet")
                    }
                }
                if(g2expectedpos>25){
                    image11.opacity=1;
                    cantmove.running=true;
                    console.log("novalid move")
                }
                else{
                    gmove2=1;
                }
                if((gmove1==1)&&(gmove2==1)){
                    if(allowselect==1){
                        diceclick.enabled=false;
                        selectionmove(g2)
                    }
                    else if(specialchance>0){
                        specialfunction(g2);}
            else{   diceclick.enabled=false;
                    gmovepawn=2;
                     moveconsent=1;
                    tg1.running=true;
                }
                }
    }
        else  if(pw==g3) {
            g3expectedpos=g3curposition+valueselected;
            if(g3expectedpos<=16){
                gmove1=1;
            }
                if(g3expectedpos>=17){
                    if(gkill>=1){
                        gmove1=1;
                    }
                    else{
                        image11.opacity=1;
                        cantmove.running=true;
                        console.log("no valid move for this pawn you dont have a kill yet")
                    }
                }
                if(g3expectedpos>25){
                    image11.opacity=1;
                    cantmove.running=true;
                    console.log("no valid move")
                }
                else{
                    gmove2=1;
                }
                if((gmove1==1)&&(gmove2==1)){
                    if(allowselect==1){
                        diceclick.enabled=false;
                        selectionmove(g3)
                    }
                    else if(specialchance>0){
                        specialfunction(g3);}
                    else{   diceclick.enabled=false;
                        gmovepawn=3;
                        moveconsent=1;
                        tg1.running=true;
                    }
                }
        }
        else  if(pw==g4) {
            g4expectedpos=g4curposition+valueselected;
            if(g4expectedpos<=16){
                gmove1=1;
            }
                if(g4expectedpos>=17){
                    if(gkill>=1){
                        gmove1=1;
                    }
                    else{
                        image11.opacity=1;
                        cantmove.running=true;
                        console.log("no valid move for this pawn you dont have a kill yet")
                    }
                }
                if(g4expectedpos>25){
                    image11.opacity=1;
                    cantmove.running=true;
                    console.log("no valid move")
                }
                else{
                    gmove2=1;
                }
                if((gmove1==1)&&(gmove2==1)){
                    if(allowselect==1){
                        diceclick.enabled=false;
                        selectionmove(g4)
                    }
                    else if(specialchance>0){
                        specialfunction(g4);}
            else{   diceclick.enabled=false;
                    gmovepawn=4;
                     moveconsent=1;
                    tg1.running=true;
                }
                }

        }
    }}

    }
function bluemovevalidation(pw){
 if(allowselect!=1){
    b1expectedpos=b1curposition+dicevalue;
    b2expectedpos=b2curposition+dicevalue;
    b3expectedpos=b3curposition+dicevalue;
    b4expectedpos=b4curposition+dicevalue;
    if((b1expectedpos>25)&&(b2expectedpos>25)&&(b3expectedpos>25)&&(b4expectedpos>25)){
        console.log("no valid moves for blue");
        turnchange();
    }

  else{  if(pw==b1)  {
        console.log("bluemovevalidationcalled")
    b1expectedpos=b1curposition+dicevalue;
        if(b1expectedpos<=16){
            bmove1=1;
        }
            if(b1expectedpos>=17){
                if(bkill>=1){
                    bmove1=1;
                }
                else{
                    image11.opacity=1;
                    cantmove.running=true;
                    console.log("no valid move for this pawn you dont have a kill yet")
                }
            }
            if(b1expectedpos>25){
                image11.opacity=1;
                cantmove.running=true;
                console.log("no valid move")
            }
            else{
                bmove2=1;
            }
            if((bmove1==1)&&(bmove2==1)){
                if(allowselect==1){

                    diceclick.enabled=false;
                    selectionmove(b1)
                }
                else if(specialchance>0){
                    specialfunction(b1);
                }else

                {
                    diceclick.enabled=false;
                bmovepawn=1;
               moveconsent=1;
                tb1.running=true;
            }
            }
        }


    else if(pw==b2) {
    b2expectedpos=b2curposition+dicevalue;
        if(b2expectedpos<=16){
            bmove1=1;
        }
            if(b2expectedpos>=17){
                if(bkill>=1){
                    bmove1=1;
                }
                else{
                    image11.opacity=1;
                    cantmove.running=true;
                    console.log("no valid move for this pawn you dont have a kill yet")
                }
            }
            if(b2expectedpos>25){
                image11.opacity=1;
                cantmove.running=true;
                console.log("novalid move")
            }
            else{
                bmove2=1;
            }
            if((bmove1==1)&&(bmove2==1)){
                if(allowselect==1){
                    diceclick.enabled=false;
                    selectionmove(b2)
                }
                else if(specialchance>0){
                    specialfunction(b2);}
        else{   diceclick.enabled=false;
                bmovepawn=2;
                 moveconsent=1;
                tb1.running=true;
            }
            }
}
    else  if(pw==b3) {
        b3expectedpos=b3curposition+dicevalue;
        if(b3expectedpos<=16){
            bmove1=1;
        }
            if(b3expectedpos>=17){
                if(bkill>=1){
                    bmove1=1;
                }
                else{
                    image11.opacity=1;
                    cantmove.running=true;
                    console.log("no valid move for this pawn you dont have a kill yet")
                }
            }
            if(b3expectedpos>25){
                image11.opacity=1;
                cantmove.running=true;
                console.log("no valid move")
            }
            else{
                bmove2=1;
            }
            if((bmove1==1)&&(bmove2==1)){
                if(allowselect==1){
                    diceclick.enabled=false;
                    selectionmove(b3)
                }
                else if(specialchance>0){
                    specialfunction(b3);}
                else{   diceclick.enabled=false;
                    bmovepawn=3;
                    moveconsent=1;
                    tb1.running=true;
                }
            }
    }
    else  if(pw==b4) {
        b4expectedpos=b4curposition+dicevalue;
        if(b4expectedpos<=16){
            bmove1=1;
        }
            if(b4expectedpos>=17){
                if(bkill>=1){
                    bmove1=1;
                }
                else{
                    image11.opacity=1;
                    cantmove.running=true;
                    console.log("no valid move for this pawn you dont have a kill yet")
                }
            }
            if(b4expectedpos>25){
                image11.opacity=1;
                cantmove.running=true;
                console.log("no valid move")
            }
            else{
                bmove2=1;
            }
            if((bmove1==1)&&(bmove2==1)){
                if(allowselect==1){
                    diceclick.enabled=false;
                    selectionmove(b4)
                }
                else if(specialchance>0){
                    specialfunction(b4);}
        else{   diceclick.enabled=false;
                bmovepawn=4;
                 moveconsent=1;
                tb1.running=true;
            }
            }

    }
}

}
 else if(allowselect==1){

     b1expectedpos=b1curposition+valueselected;
     b2expectedpos=b2curposition+valueselected;
     b3expectedpos=b3curposition+valueselected;
     b4expectedpos=b4curposition+valueselected;
     if((b1expectedpos>25)&&(b2expectedpos>25)&&(b3expectedpos>25)&&(b4expectedpos>25)){
         console.log("no valid moves for blue");
         turnchange();
     }

   else{  if(pw==b1)  {
         console.log("bluemovevalidationcalled")
     b1expectedpos=b1curposition+valueselected;
         if(b1expectedpos<=16){
             bmove1=1;
         }
             if(b1expectedpos>=17){
                 if(bkill>=1){
                     bmove1=1;
                 }
                 else{
                     image11.opacity=1;
                     cantmove.running=true;
                     console.log("no valid move for this pawn you dont have a kill yet")
                 }
             }
             if(b1expectedpos>25){
                 image11.opacity=1;
                 cantmove.running=true;
                 console.log("no valid move")
             }
             else{
                 bmove2=1;
             }
             if((bmove1==1)&&(bmove2==1)){
                 if(allowselect==1){

                     diceclick.enabled=false;
                     selectionmove(b1)
                 }
                 else if(specialchance>0){
                     specialfunction(b1);
                 }else

                 {
                     diceclick.enabled=false;
                 bmovepawn=1;
                moveconsent=1;
                 tb1.running=true;
             }
             }
         }


     else if(pw==b2) {
     b2expectedpos=b2curposition+valueselected;
         if(b2expectedpos<=16){
             bmove1=1;
         }
             if(b2expectedpos>=17){
                 if(bkill>=1){
                     bmove1=1;
                 }
                 else{
                     image11.opacity=1;
                     cantmove.running=true;
                     console.log("no valid move for this pawn you dont have a kill yet")
                 }
             }
             if(b2expectedpos>25){
                 image11.opacity=1;
                 cantmove.running=true;
                 console.log("novalid move")
             }
             else{
                 bmove2=1;
             }
             if((bmove1==1)&&(bmove2==1)){
                 if(allowselect==1){
                     diceclick.enabled=false;
                     selectionmove(b2)
                 }
                 else if(specialchance>0){
                     specialfunction(b2);}
         else{   diceclick.enabled=false;
                 bmovepawn=2;
                  moveconsent=1;
                 tb1.running=true;
             }
             }
 }
     else  if(pw==b3) {
         b3expectedpos=b3curposition+valueselected;
         if(b3expectedpos<=16){
             bmove1=1;
         }
             if(b3expectedpos>=17){
                 if(bkill>=1){
                     bmove1=1;
                 }
                 else{
                     image11.opacity=1;
                     cantmove.running=true;
                     console.log("no valid move for this pawn you dont have a kill yet")
                 }
             }
             if(b3expectedpos>25){
                 image11.opacity=1;
                 cantmove.running=true;
                 console.log("no valid move")
             }
             else{
                 bmove2=1;
             }
             if((bmove1==1)&&(bmove2==1)){
                 if(allowselect==1){
                     diceclick.enabled=false;
                     selectionmove(b3)
                 }
                 else if(specialchance>0){
                     specialfunction(b3);}
                 else{   diceclick.enabled=false;
                     bmovepawn=3;
                     moveconsent=1;
                     tb1.running=true;
                 }
             }
     }
     else  if(pw==b4) {
         b4expectedpos=b4curposition+valueselected;
         if(b4expectedpos<=16){
             bmove1=1;
         }
             if(b4expectedpos>=17){
                 if(bkill>=1){
                     bmove1=1;
                 }
                 else{
                     image11.opacity=1;
                     cantmove.running=true;
                     console.log("no valid move for this pawn you dont have a kill yet")
                 }
             }
             if(b4expectedpos>25){
                 image11.opacity=1;
                 cantmove.running=true;
                 console.log("no valid move")
             }
             else{
                 bmove2=1;
             }
             if((bmove1==1)&&(bmove2==1)){
                 if(allowselect==1){
                     diceclick.enabled=false;
                     selectionmove(b4)
                 }
                 else if(specialchance>0){
                     specialfunction(b4);}
         else{   diceclick.enabled=false;
                 bmovepawn=4;
                  moveconsent=1;
                 tb1.running=true;
             }
             }

     }
 }

 }

 }

function redmovevalidation(pw){
     if(allowselect!=1){
    console.log("redvalidation called")
    r1expectedpos=r1curposition+dicevalue;
    r2expectedpos=r2curposition+dicevalue;
    r3expectedpos=r3curposition+dicevalue;
    r4expectedpos=r4curposition+dicevalue;
    console.log("r1expectedpos"+r1expectedpos)
    console.log("r2expectedpos"+r2expectedpos)
    console.log("r3expectedpos"+r3expectedpos)
    console.log("r4expectedpos"+r4expectedpos)
    if((r1expectedpos>25)&&(r2expectedpos>25)&&(r3expectedpos>25)&&(r4expectedpos>25)){
        console.log("no valid moves for rlue");
        turnchange();
    }

  else{  if(pw==r1)  {
        console.log("redmovevalidationcalled")
    r1expectedpos=r1curposition+dicevalue;
        if(r1expectedpos<=16){
            rmove1=1;
        }
            if(r1expectedpos>=17){
                if(rkill>=1){
                    rmove1=1;
                }
                else{
                    image11.opacity=1;
                    cantmove.running=true;
                    console.log("no valid move for this pawn you dont have a kill yet")
                }
            }
            if(r1expectedpos>25){
                image11.opacity=1;
                cantmove.running=true;
                console.log("no valid move")
            }
            else{
                rmove2=1;
            }
            if((rmove1==1)&&(rmove2==1)){
                if(allowselect==1){

                    diceclick.enabled=false;
                    selectionmove(r1)
                }
                else if(specialchance>0){
                    specialfunction(r1);
                }else

                {
                    diceclick.enabled=false;
                rmovepawn=1;
               moveconsent=1;
                tr1.running=true;
            }
            }
        }


    else if(pw==r2) {
    r2expectedpos=r2curposition+dicevalue;
        if(r2expectedpos<=16){
            rmove1=1;
        }
            if(r2expectedpos>=17){
                if(rkill>=1){
                    rmove1=1;
                }
                else{
                    image11.opacity=1;
                    cantmove.running=true;
                    console.log("no valid move for this pawn you dont have a kill yet")
                }
            }
            if(r2expectedpos>25){
                image11.opacity=1;
                cantmove.running=true;
                console.log("novalid move")
            }
            else{
                rmove2=1;
            }
            if((rmove1==1)&&(rmove2==1)){
                if(allowselect==1){
                    diceclick.enabled=false;
                    selectionmove(r2)
                }
                else if(specialchance>0){
                    specialfunction(r2);}
        else{   diceclick.enabled=false;
                rmovepawn=2;
                 moveconsent=1;
                tr1.running=true;
            }
            }
}
    else  if(pw==r3) {
        r3expectedpos=r3curposition+dicevalue;
        if(r3expectedpos<=16){
            rmove1=1;
        }
            if(r3expectedpos>=17){
                if(rkill>=1){
                    rmove1=1;
                }
                else{
                    image11.opacity=1;
                    cantmove.running=true;
                    console.log("no valid move for this pawn you dont have a kill yet")
                }
            }
            if(r3expectedpos>25){
                image11.opacity=1;
                cantmove.running=true;
                console.log("no valid move")
            }
            else{
                rmove2=1;
            }
            if((rmove1==1)&&(rmove2==1)){
                if(allowselect==1){
                    diceclick.enabled=false;
                    selectionmove(r3)
                }
                else if(specialchance>0){
                    specialfunction(r3);}
                else{   diceclick.enabled=false;
                    rmovepawn=3;
                    moveconsent=1;
                    tr1.running=true;
                }
            }
    }
    else  if(pw==r4) {
        r4expectedpos=r4curposition+dicevalue;
        if(r4expectedpos<=16){
            rmove1=1;
        }
            if(r4expectedpos>=17){
                if(rkill>=1){
                    rmove1=1;
                }
                else{
                    image11.opacity=1;
                    cantmove.running=true;
                    console.log("no valid move for this pawn you dont have a kill yet")
                }
            }
            if(r4expectedpos>25){
                image11.opacity=1;
                cantmove.running=true;
                console.log("no valid move")
            }
            else{
                rmove2=1;
            }
            if((rmove1==1)&&(rmove2==1)){
                if(allowselect==1){
                    diceclick.enabled=false;
                    selectionmove(r4)
                }
                else if(specialchance>0){
                    specialfunction(r4);}
        else{   diceclick.enabled=false;
                rmovepawn=4;
                 moveconsent=1;
                tr1.running=true;
            }
            }

    }
}
}
     else if(allowselect==1){
         console.log("redvalidation called")
         r1expectedpos=r1curposition+valueselected;
         r2expectedpos=r2curposition+valueselected;
         r3expectedpos=r3curposition+valueselected;
         r4expectedpos=r4curposition+valueselected;
         console.log("r1expectedpos"+r1expectedpos)
         console.log("r2expectedpos"+r2expectedpos)
         console.log("r3expectedpos"+r3expectedpos)
         console.log("r4expectedpos"+r4expectedpos)
         if((r1expectedpos>25)&&(r2expectedpos>25)&&(r3expectedpos>25)&&(r4expectedpos>25)){
             console.log("no valid moves for rlue");
             turnchange();
         }

       else{  if(pw==r1)  {
             console.log("redmovevalidationcalled")
         r1expectedpos=r1curposition+valueselected;
             if(r1expectedpos<=16){
                 rmove1=1;
             }
                 if(r1expectedpos>=17){
                     if(rkill>=1){
                         rmove1=1;
                     }
                     else{
                         image11.opacity=1;
                         cantmove.running=true;
                         console.log("no valid move for this pawn you dont have a kill yet")
                     }
                 }
                 if(r1expectedpos>25){
                     image11.opacity=1;
                     cantmove.running=true;
                     console.log("no valid move")
                 }
                 else{
                     rmove2=1;
                 }
                 if((rmove1==1)&&(rmove2==1)){
                     if(allowselect==1){

                         diceclick.enabled=false;
                         selectionmove(r1)
                     }
                     else if(specialchance>0){
                         specialfunction(r1);
                     }else

                     {
                         diceclick.enabled=false;
                     rmovepawn=1;
                    moveconsent=1;
                     tr1.running=true;
                 }
                 }
             }


         else if(pw==r2) {
         r2expectedpos=r2curposition+valueselected;
             if(r2expectedpos<=16){
                 rmove1=1;
             }
                 if(r2expectedpos>=17){
                     if(rkill>=1){
                         rmove1=1;
                     }
                     else{
                         image11.opacity=1;
                         cantmove.running=true;
                         console.log("no valid move for this pawn you dont have a kill yet")
                     }
                 }
                 if(r2expectedpos>25){
                     image11.opacity=1;
                     cantmove.running=true;
                     console.log("novalid move")
                 }
                 else{
                     rmove2=1;
                 }
                 if((rmove1==1)&&(rmove2==1)){
                     if(allowselect==1){
                         diceclick.enabled=false;
                         selectionmove(r2)
                     }
                     else if(specialchance>0){
                         specialfunction(r2);}
             else{   diceclick.enabled=false;
                     rmovepawn=2;
                      moveconsent=1;
                     tr1.running=true;
                 }
                 }
     }
         else  if(pw==r3) {
             r3expectedpos=r3curposition+valueselected;
             if(r3expectedpos<=16){
                 rmove1=1;
             }
                 if(r3expectedpos>=17){
                     if(rkill>=1){
                         rmove1=1;
                     }
                     else{
                         image11.opacity=1;
                         cantmove.running=true;
                         console.log("no valid move for this pawn you dont have a kill yet")
                     }
                 }
                 if(r3expectedpos>25){
                     image11.opacity=1;
                     cantmove.running=true;
                     console.log("no valid move")
                 }
                 else{
                     rmove2=1;
                 }
                 if((rmove1==1)&&(rmove2==1)){
                     if(allowselect==1){
                         diceclick.enabled=false;
                         selectionmove(r3)
                     }
                     else if(specialchance>0){
                         specialfunction(r3);}
                     else{   diceclick.enabled=false;
                         rmovepawn=3;
                         moveconsent=1;
                         tr1.running=true;
                     }
                 }
         }
         else  if(pw==r4) {
             r4expectedpos=r4curposition+valueselected;
             if(r4expectedpos<=16){
                 rmove1=1;
             }
                 if(r4expectedpos>=17){
                     if(rkill>=1){
                         rmove1=1;
                     }
                     else{
                         image11.opacity=1;
                         cantmove.running=true;
                         console.log("no valid move for this pawn you dont have a kill yet")
                     }
                 }
                 if(r4expectedpos>25){
                     image11.opacity=1;
                     cantmove.running=true;
                     console.log("no valid move")
                 }
                 else{
                     rmove2=1;
                 }
                 if((rmove1==1)&&(rmove2==1)){
                     if(allowselect==1){
                         diceclick.enabled=false;
                         selectionmove(r4)
                     }
                     else if(specialchance>0){
                         specialfunction(r4);}
             else{   diceclick.enabled=false;
                     rmovepawn=4;
                      moveconsent=1;
                     tr1.running=true;
                 }
                 }

         }
     }
     }
     }

function yellowmovevalidation(pw){
     if(allowselect!=1){
    y1expectedpos=y1curposition+dicevalue;
    y2expectedpos=y2curposition+dicevalue;
    y3expectedpos=y3curposition+dicevalue;
    y4expectedpos=y4curposition+dicevalue;
    if((y1expectedpos>25)&&(y2expectedpos>25)&&(y3expectedpos>25)&&(y4expectedpos>25)){
        console.log("no valid moves for rlue");
        turnchange();
    }

  else{  if(pw==y1)  {
        console.log("bluemovevalidationcalled")
    y1expectedpos=y1curposition+dicevalue;
        if(y1expectedpos<=16){
            ymove1=1;
        }
            if(y1expectedpos>=17){
                if(ykill>=1){
                    ymove1=1;
                }
                else{
                    image11.opacity=1;
                    cantmove.running=true;
                    console.log("no valid move for this pawn you dont have a kill yet")
                }
            }
            if(y1expectedpos>25){
                image11.opacity=1;
                cantmove.running=true;
                console.log("no valid move")
            }
            else{
                ymove2=1;
            }
            if((ymove1==1)&&(ymove2==1)){
                if(allowselect==1){

                    diceclick.enabled=false;
                    selectionmove(y1)
                }
                else if(specialchance>0){
                    specialfunction(y1);
                }else

                {
                    diceclick.enabled=false;
                ymovepawn=1;
               moveconsent=1;
                ty1.running=true;
            }
            }
        }


    else if(pw==y2) {
    y2expectedpos=y2curposition+dicevalue;
        if(y2expectedpos<=16){
            ymove1=1;
        }
            if(y2expectedpos>=17){
                if(ykill>=1){
                    ymove1=1;
                }
                else{
                    image11.opacity=1;
                    cantmove.running=true;
                    console.log("no valid move for this pawn you dont have a kill yet")
                }
            }
            if(y2expectedpos>25){
                image11.opacity=1;
                cantmove.running=true;
                console.log("novalid move")
            }
            else{
                ymove2=1;
            }
            if((ymove1==1)&&(ymove2==1)){
                if(allowselect==1){
                    diceclick.enabled=false;
                    selectionmove(y2)
                }
                else if(specialchance>0){
                    specialfunction(y2);}
        else{   diceclick.enabled=false;
                ymovepawn=2;
                 moveconsent=1;
                ty1.running=true;
            }
            }
}
    else  if(pw==y3) {
        y3expectedpos=y3curposition+dicevalue;
        if(y3expectedpos<=16){
            ymove1=1;
        }
            if(y3expectedpos>=17){
                if(ykill>=1){
                    ymove1=1;
                }
                else{
                    image11.opacity=1;
                    cantmove.running=true;
                    console.log("no valid move for this pawn you dont have a kill yet")
                }
            }
            if(y3expectedpos>25){
                image11.opacity=1;
                cantmove.running=true;
                console.log("no valid move")
            }
            else{
                ymove2=1;
            }
            if((ymove1==1)&&(ymove2==1)){
                if(allowselect==1){
                    diceclick.enabled=false;
                    selectionmove(y3)
                }
                else if(specialchance>0){
                    specialfunction(y3);}
                else{   diceclick.enabled=false;
                    ymovepawn=3;
                    moveconsent=1;
                    ty1.running=true;
                }
            }
    }
    else  if(pw==y4) {
        y4expectedpos=y4curposition+dicevalue;
        if(y4expectedpos<=16){
            ymove1=1;
        }
            if(y4expectedpos>=17){
                if(ykill>=1){
                    ymove1=1;
                }
                else{
                    image11.opacity=1;
                    cantmove.running=true;
                    console.log("no valid move for this pawn you dont have a kill yet")
                }
            }
            if(y4expectedpos>25){
                image11.opacity=1;
                cantmove.running=true;
                console.log("no valid move")
            }
            else{
                ymove2=1;
            }
            if((ymove1==1)&&(ymove2==1)){
                if(allowselect==1){
                    diceclick.enabled=false;
                    selectionmove(y4)
                }
                else if(specialchance>0){
                    specialfunction(y4);}
        else{   diceclick.enabled=false;
                ymovepawn=4;
                 moveconsent=1;
                ty1.running=true;
            }
            }

    }
}
}
     else if(allowselect==1){
         y1expectedpos=y1curposition+valueselected;
         y2expectedpos=y2curposition+valueselected;
         y3expectedpos=y3curposition+valueselected;
         y4expectedpos=y4curposition+valueselected;
         if((y1expectedpos>25)&&(y2expectedpos>25)&&(y3expectedpos>25)&&(y4expectedpos>25)){
             console.log("no valid moves for rlue");
             turnchange();
         }

       else{  if(pw==y1)  {
             console.log("bluemovevalidationcalled")
         y1expectedpos=y1curposition+valueselected;
             if(y1expectedpos<=16){
                 ymove1=1;
             }
                 if(y1expectedpos>=17){
                     if(ykill>=1){
                         ymove1=1;
                     }
                     else{
                         image11.opacity=1;
                         cantmove.running=true;
                         console.log("no valid move for this pawn you dont have a kill yet")
                     }
                 }
                 if(y1expectedpos>25){
                     image11.opacity=1;
                     cantmove.running=true;
                     console.log("no valid move")
                 }
                 else{
                     ymove2=1;
                 }
                 if((ymove1==1)&&(ymove2==1)){
                     if(allowselect==1){

                         diceclick.enabled=false;
                         selectionmove(y1)
                     }
                     else if(specialchance>0){
                         specialfunction(y1);
                     }else

                     {
                         diceclick.enabled=false;
                     ymovepawn=1;
                    moveconsent=1;
                     ty1.running=true;
                 }
                 }
             }


         else if(pw==y2) {
         y2expectedpos=y2curposition+valueselected;
             if(y2expectedpos<=16){
                 ymove1=1;
             }
                 if(y2expectedpos>=17){
                     if(ykill>=1){
                         ymove1=1;
                     }
                     else{
                         image11.opacity=1;
                         cantmove.running=true;
                         console.log("no valid move for this pawn you dont have a kill yet")
                     }
                 }
                 if(y2expectedpos>25){
                     image11.opacity=1;
                     cantmove.running=true;
                     console.log("novalid move")
                 }
                 else{
                     ymove2=1;
                 }
                 if((ymove1==1)&&(ymove2==1)){
                     if(allowselect==1){
                         diceclick.enabled=false;
                         selectionmove(y2)
                     }
                     else if(specialchance>0){
                         specialfunction(y2);}
             else{   diceclick.enabled=false;
                     ymovepawn=2;
                      moveconsent=1;
                     ty1.running=true;
                 }
                 }
     }
         else  if(pw==y3) {
             y3expectedpos=y3curposition+valueselected;
             if(y3expectedpos<=16){
                 ymove1=1;
             }
                 if(y3expectedpos>=17){
                     if(ykill>=1){
                         ymove1=1;
                     }
                     else{
                         image11.opacity=1;
                         cantmove.running=true;
                         console.log("no valid move for this pawn you dont have a kill yet")
                     }
                 }
                 if(y3expectedpos>25){
                     image11.opacity=1;
                     cantmove.running=true;
                     console.log("no valid move")
                 }
                 else{
                     ymove2=1;
                 }
                 if((ymove1==1)&&(ymove2==1)){
                     if(allowselect==1){
                         diceclick.enabled=false;
                         selectionmove(y3)
                     }
                     else if(specialchance>0){
                         specialfunction(y3);}
                     else{   diceclick.enabled=false;
                         ymovepawn=3;
                         moveconsent=1;
                         ty1.running=true;
                     }
                 }
         }
         else  if(pw==y4) {
             y4expectedpos=y4curposition+valueselected;
             if(y4expectedpos<=16){
                 ymove1=1;
             }
                 if(y4expectedpos>=17){
                     if(ykill>=1){
                         ymove1=1;
                     }
                     else{
                         image11.opacity=1;
                         cantmove.running=true;
                         console.log("no valid move for this pawn you dont have a kill yet")
                     }
                 }
                 if(y4expectedpos>25){
                     image11.opacity=1;
                     cantmove.running=true;
                     console.log("no valid move")
                 }
                 else{
                     ymove2=1;
                 }
                 if((ymove1==1)&&(ymove2==1)){
                     if(allowselect==1){
                         diceclick.enabled=false;
                         selectionmove(y4)
                     }
                     else if(specialchance>0){
                         specialfunction(y4);}
             else{   diceclick.enabled=false;
                     ymovepawn=4;
                      moveconsent=1;
                     ty1.running=true;
                 }
                 }

         }
     }
     }
     }

function movegreen1(){

    if(moveconsent==1){
    if(gfinalmovevalue){
       // console.log("executing for loop"+i++)
        if((g1.y==290)&&(g1.x<=302)&&(gmovedirection[1]==0))
        {

            g1.x=g1.x+2;

            //console.log("g1.x"+g1.x )
            if(g1.x==302){
                gmovedirection[1]=1
            }
        }

        else if((gmovedirection[1]==1)&&(g1.y>=18)){
            g1.y=g1.y-2;
            if(g1.y==18){
                gmovedirection[1]=2
            }
        }

        else if((gmovedirection[1]==2)&&(g1.x>=30)){
            g1.x=g1.x-2;
            if(g1.x==30){
                gmovedirection[1]=3
            }
        }

        else if((gmovedirection[1]==3)&&(g1.y<=290)){
            g1.y=g1.y+2
            if(g1.y==290){
                gmovedirection[1]=4;
            }
        }

        else if((gmovedirection[1]==4)&&(g1.x<=98)){

                g1.x=g1.x+2

            console.log(g1.x)
            if(g1.x==98){

            gmovedirection[1]=5}
        }
        else if((gmovedirection[1]==5)&&(g1.y>=86)){

             g1.y=g1.y-2;
            console.log(g1.y)
            if(g1.y==86){
                gmovedirection[1]=6;
            }
        }
        else if((gmovedirection[1]==6)&&(g1.x<=234)){
            g1.x=g1.x+2;
            if(g1.x==234){
                gmovedirection[1]=7;
            }
        }
        else if((gmovedirection[1]==7)&&(g1.y<=222)){
                g1.y=g1.y+2;
            if(g1.y==222){
                gmovedirection[1]=8;
            }
    }
        else if((gmovedirection[1]==8)&&(g1.x>=166)){
                g1.x=g1.x-2;
            if(g1.x==166){
            gmovedirection[1]=9;
                console.log("gmovedirection[1]=9")
            }
        }
        else if((gmovedirection[1]==9)&&(g1.y>=154)){

            g1.y=g1.y-2;
            if(g1.y==154){
                movevalue=0;
            }


        }
        gfinalmovevalue=gfinalmovevalue-2;



if(gfinalmovevalue==0){
    gmove1=0;
    gmove2=0;
    text9.text="0";


     if((g1.x==234)&&(g1.y==290)){
        g1curposition=2;
    }
    else if((g1.x==302)&&(g1.y==290)){
        g1curposition=3;
    }
    else if((g1.x==302)&&(g1.y==222)){
        g1curposition=4;
    }
    else if((g1.x==302)&&(g1.y==154)){
        g1curposition=5;
    }
    else if((g1.x==302)&&(g1.y==86)){
        g1curposition=6;
    }
    else if((g1.x==302)&&(g1.y==18)){
        g1curposition=7;
    }
    else if((g1.x==234)&&(g1.y==18)){
        g1curposition=8;
    }
    else if((g1.x==166)&&(g1.y==18)){
        g1curposition=9;
    }
    else if((g1.x==98)&&(g1.y==18)){
        g1curposition=10;
    }
    else if((g1.x==30)&&(g1.y==18)){
        g1curposition=11;
    }
    else if((g1.x==30)&&(g1.y==86)){
        g1curposition=12;
    }
    else if((g1.x==30)&&(g1.y==154)){
        g1curposition=13;
    }
    else if((g1.x==30)&&(g1.y==222)){
        g1curposition=14;
    }
    else if((g1.x==30)&&(g1.y==290)){
        g1curposition=15;
    }
    else if((g1.x==98)&&(g1.y==290)){
        g1curposition=16;
    }
    else if((g1.x==98)&&(g1.y==222)){
        g1curposition=17;
    }
    else if((g1.x==98)&&(g1.y==154)){
        g1curposition=18;
    }
    else if((g1.x==98)&&(g1.y==86)){
        g1curposition=19;
    }
    else if((g1.x==166)&&(g1.y==86)){
        g1curposition=20;
    }
    else if((g1.x==234)&&(g1.y==86)){
        g1curposition=21;
    }
    else if((g1.x==234)&&(g1.y==154)){
        g1curposition=22;
    }
    else if((g1.x==234)&&(g1.y==222)){
        g1curposition=23;
    }
    else if((g1.x==166)&&(g1.y==222)){
        g1curposition=24;
    }
    else if((g1.x==166)&&(g1.y==154)){
        g1curposition=25;
    }
    console.log("g1curposition"+g1curposition)
    console.log("g2curposition"+g2curposition)
    console.log("g3curposition"+g3curposition)
    console.log("g4curposition"+g4curposition)
    console.log("b1curposition"+b1curposition)
    console.log("b2curposition"+b2curposition)
    console.log("b3curposition"+b3curposition)
    console.log("b4curposition"+b4curposition)
    console.log("r1curposition"+r1curposition)
    console.log("r2curposition"+r2curposition)
    console.log("r3curposition"+r3curposition)
    console.log("r4curposition"+r4curposition)
    console.log("y1curposition"+y1curposition)
    console.log("y2curposition"+y2curposition)
    console.log("y3curposition"+y3curposition)
    console.log("y4curposition"+y4curposition)

        gkillcheck(g1);

    }}
    }}
function movegreen2(){
    if(moveconsent==1){
    //console.log("move g2 called");
    if(gfinalmovevalue){
       // console.log("executing for loop"+i++)
        if((g2.y==300)&&(g2.x<=334)&&(gmovedirection[2]==0))
        {
            console.log("IST COND IS TRUE")
            g2.x=g2.x+2;

            console.log("g2.x"+g2.x )
            if(g2.x==334){
                gmovedirection[2]=1
            }
        }

        else if((gmovedirection[2]==1)&&(g2.y>=28)){
            g2.y=g2.y-2;
            if(g2.y==28){
                gmovedirection[2]=2
            }
        }

        else if((gmovedirection[2]==2)&&(g2.x>=62)){
            g2.x=g2.x-2;
            if(g2.x==62){
                gmovedirection[2]=3
            }
        }

        else if((gmovedirection[2]==3)&&(g2.y<=300)){
            g2.y=g2.y+2
            if(g2.y==300){
                gmovedirection[2]=4;
            }
        }

        else if((gmovedirection[2]==4)&&(g2.x<=130)){

                g2.x=g2.x+2

            console.log(g2.x)
            if(g2.x==130){

            gmovedirection[2]=5}
        }
        else if((gmovedirection[2]==5)&&(g2.y>=96)){

             g2.y=g2.y-2;
            console.log(g2.y)
            if(g2.y==96){
                gmovedirection[2]=6;
            }
        }
        else if((gmovedirection[2]==6)&&(g2.x<=266)){
            g2.x=g2.x+2;
            if(g2.x==266){
                gmovedirection[2]=7;
            }
        }
        else if((gmovedirection[2]==7)&&(g2.y<=232)){
                g2.y=g2.y+2;
            if(g2.y==232){
                gmovedirection[2]=8;
            }
    }
        else if((gmovedirection[2]==8)&&(g2.x>=198)){
                g2.x=g2.x-2;
            if(g2.x==198){
            gmovedirection[2]=9;
                console.log("gmovedirection[2]=9")
            }
        }
        else if((gmovedirection[2]==9)&&(g2.y>=164)){

            g2.y=g2.y-2;
            if(g2.y==164){
                gfinalmovevalue[2]=0;
            }
        }
        gfinalmovevalue=gfinalmovevalue-2;


   if(gfinalmovevalue==0){
       gmove1=0;
       gmove2=0;
        text9.text="0";

     if((g2.x==266)&&(g2.y==300)){
        g2curposition=2;
    }
    else if((g2.x==334)&&(g2.y==300)){
        g2curposition=3;
    }
    else if((g2.x==334)&&(g2.y==232)){
        g2curposition=4;
    }
    else if((g2.x==334)&&(g2.y==164)){
        g2curposition=5;
    }
    else if((g2.x==334)&&(g2.y==96)){
        g2curposition=6;
    }
    else if((g2.x==334)&&(g2.y==28)){
        g2curposition=7;
    }
    else if((g2.x==266)&&(g2.y==28)){
        g2curposition=8;
    }
    else if((g2.x==198)&&(g2.y==28)){
        g2curposition=9;
    }
    else if((g2.x==130)&&(g2.y==28)){
        g2curposition=10;
    }
    else if((g2.x==62)&&(g2.y==28)){
        g2curposition=11;
    }
    else if((g2.x==62)&&(g2.y==96)){
        g2curposition=12;
    }
    else if((g2.x==62)&&(g2.y==164)){
        g2curposition=13;
    }
    else if((g2.x==62)&&(g2.y==232)){
        g2curposition=14;
    }
    else if((g2.x==62)&&(g2.y==300)){
        g2curposition=15;
    }
    else if((g2.x==130)&&(g2.y==300)){
        g2curposition=16;
    }
    else if((g2.x==130)&&(g2.y==232)){
        g2curposition=17;
    }
    else if((g2.x==130)&&(g2.y==164)){
        g2curposition=18;
    }
    else if((g2.x==130)&&(g2.y==96)){
        g2curposition=19;
    }
    else if((g2.x==198)&&(g2.y==96)){
        g2curposition=20;
    }
    else if((g2.x==266)&&(g2.y==96)){
        g2curposition=21;
    }
    else if((g2.x==266)&&(g2.y==164)){
        g2curposition=22;
    }
    else if((g2.x==266)&&(g2.y==232)){
        g2curposition=23;
    }
    else if((g2.x==198)&&(g2.y==232)){
        g2curposition=24;
    }
    else if((g2.x==198)&&(g2.y==164)){
        g2curposition=25;
    }

    console.log("g1curposition"+g1curposition)
    console.log("g2curposition"+g2curposition)
    console.log("g3curposition"+g3curposition)
    console.log("g4curposition"+g4curposition)
    console.log("b1curposition"+b1curposition)
    console.log("b2curposition"+b2curposition)
    console.log("b3curposition"+b3curposition)
    console.log("b4curposition"+b4curposition)
    console.log("r1curposition"+r1curposition)
    console.log("r2curposition"+r2curposition)
    console.log("r3curposition"+r3curposition)
    console.log("r4curposition"+r4curposition)
    console.log("y1curposition"+y1curposition)
    console.log("y2curposition"+y2curposition)
    console.log("y3curposition"+y3curposition)
    console.log("y4curposition"+y4curposition)

        gkillcheck(g2);

    }
    }}}
function movegreen3(){
    if(moveconsent==1){
   // console.log("move g3 called");
    if(gfinalmovevalue){
       // console.log("executing for loop"+i++)
        if((g3.y==328)&&(g3.x<=320)&&(gmovedirection[3]==0))
        {
            console.log("IST COND IS TRUE")
            g3.x=g3.x+2;

            console.log("g3.x"+g3.x )
            if(g3.x==320){
                gmovedirection[3]=1
            }
        }

        else if((gmovedirection[3]==1)&&(g3.y>=56)){
            g3.y=g3.y-2;
            if(g3.y==56){
                gmovedirection[3]=2
            }
        }

        else if((gmovedirection[3]==2)&&(g3.x>=48)){
            g3.x=g3.x-2;
            if(g3.x==48){
                gmovedirection[3]=3
            }
        }

        else if((gmovedirection[3]==3)&&(g3.y<=328)){
            g3.y=g3.y+2
            if(g3.y==328){
                gmovedirection[3]=4;
            }
        }

        else if((gmovedirection[3]==4)&&(g3.x<=116)){

                g3.x=g3.x+2

            console.log(g3.x)
            if(g3.x==116){

            gmovedirection[3]=5}
        }
        else if((gmovedirection[3]==5)&&(g3.y>=124)){

             g3.y=g3.y-2;
            console.log(g3.y)
            if(g3.y==124){
                gmovedirection[3]=6;
            }
        }
        else if((gmovedirection[3]==6)&&(g3.x<=252)){
            g3.x=g3.x+2;
            if(g3.x==252){
                gmovedirection[3]=7;
            }
        }
        else if((gmovedirection[3]==7)&&(g3.y<=260)){
                g3.y=g3.y+2;
            if(g3.y==260){
                gmovedirection[3]=8;
            }
    }
        else if((gmovedirection[3]==8)&&(g3.x>=184)){
                g3.x=g3.x-2;
            if(g3.x==184){
            gmovedirection[3]=9;
                console.log("gmovedirection[2]=9")
            }
        }
        else if((gmovedirection[3]==9)&&(g3.y>=192)){

            g3.y=g3.y-2;
            if(g3.y==192){
                gfinalmovevalue[3]=0;
            }


        }
        gfinalmovevalue=gfinalmovevalue-2;


    if(gfinalmovevalue==0){
        gmove1=0;
        gmove2=0;
            text9.text="0";

     if((g3.x==252)&&(g3.y==328)){
        g3curposition=2;
    }
    else if((g3.x==320)&&(g3.y==328)){
        g3curposition=3;
    }
    else if((g3.x==320)&&(g3.y==268)){
        g3curposition=4;
    }
    else if((g3.x==320)&&(g3.y==192)){
        g3curposition=5;
    }
    else if((g3.x==320)&&(g3.y==124)){
        g3curposition=6;
    }
    else if((g3.x==320)&&(g3.y==56)){
        g3curposition=7;
    }
    else if((g3.x==252)&&(g3.y==56)){
        g3curposition=8;
    }
    else if((g3.x==184)&&(g3.y==56)){
        g3curposition=9;
    }
    else if((g3.x==116)&&(g3.y==56)){
        g3curposition=10;
    }
    else if((g3.x==48)&&(g3.y==56)){
        g3curposition=11;
    }
    else if((g3.x==48)&&(g3.y==124)){
        g3curposition=12;
    }
    else if((g3.x==48)&&(g3.y==192)){
        g3curposition=13;
    }
    else if((g3.x==48)&&(g3.y==260)){
        g3curposition=14;
    }
    else if((g3.x==48)&&(g3.y==328)){
        g3curposition=15;
    }
    else if((g3.x==116)&&(g3.y==328)){
        g3curposition=16;
    }
    else if((g3.x==116)&&(g3.y==260)){
        g3curposition=17;
    }
    else if((g3.x==116)&&(g3.y==192)){
        g3curposition=18;
    }
    else if((g3.x==116)&&(g3.y==124)){
        g3curposition=19;
    }
    else if((g3.x==184)&&(g3.y==124)){
        g3curposition=20;
    }
    else if((g3.x==252)&&(g3.y==124)){
        g3curposition=21;
    }
    else if((g3.x==252)&&(g3.y==192)){
        g3curposition=22;
    }
    else if((g3.x==252)&&(g3.y==260)){
        g3curposition=23;
    }
    else if((g3.x==184)&&(g3.y==260)){
        g3curposition=24;
    }
    else if((g3.x==184)&&(g3.y==192)){
        g3curposition=25;
    }
    console.log("g1curposition"+g1curposition)
    console.log("g2curposition"+g2curposition)
    console.log("g3curposition"+g3curposition)
    console.log("g4curposition"+g4curposition)
    console.log("b1curposition"+b1curposition)
    console.log("b2curposition"+b2curposition)
    console.log("b3curposition"+b3curposition)
    console.log("b4curposition"+b4curposition)
    console.log("r1curposition"+r1curposition)
    console.log("r2curposition"+r2curposition)
    console.log("r3curposition"+r3curposition)
    console.log("r4curposition"+r4curposition)
    console.log("y1curposition"+y1curposition)
    console.log("y2curposition"+y2curposition)
    console.log("y3curposition"+y3curposition)
    console.log("y4curposition"+y4curposition)
        gkillcheck(g3);

    }
    }}}
function movegreen4(){
    if(moveconsent==1){
        //console.log("move g4 called");
        if(gfinalmovevalue){
           // console.log("executing for loop"+i++)
            if((g4.y==320)&&(g4.x<=286)&&(gmovedirection[4]==0))
            {
                console.log("IST COND IS TRUE")
                g4.x=g4.x+2;

                console.log("g4.x"+g4.x )
                if(g4.x==286){
                    gmovedirection[4]=1
                }
            }

            else if((gmovedirection[4]==1)&&(g4.y>=48)){
                g4.y=g4.y-2;
                if(g4.y==48){
                    gmovedirection[4]=2
                }
            }

            else if((gmovedirection[4]==2)&&(g4.x>=14)){
                g4.x=g4.x-2;
                if(g4.x==14){
                    gmovedirection[4]=3
                }
            }

            else if((gmovedirection[4]==3)&&(g4.y<=320)){
                g4.y=g4.y+2
                if(g4.y==320){
                    gmovedirection[4]=4;
                }
            }

            else if((gmovedirection[4]==4)&&(g4.x<=82)){

                    g4.x=g4.x+2

                console.log(g4.x)
                if(g4.x==82){

                gmovedirection[4]=5}
            }
            else if((gmovedirection[4]==5)&&(g4.y>=116)){

                 g4.y=g4.y-2;
                console.log(g4.y)
                if(g4.y==116){
                    gmovedirection[4]=6;
                }
            }
            else if((gmovedirection[4]==6)&&(g4.x<=218)){
                g4.x=g4.x+2;
                if(g4.x==218){
                    gmovedirection[4]=7;
                }
            }
            else if((gmovedirection[4]==7)&&(g4.y<=252)){
                    g4.y=g4.y+2;
                if(g4.y==252){
                    gmovedirection[4]=8;
                }
        }
            else if((gmovedirection[4]==8)&&(g4.x>=150)){
                    g4.x=g4.x-2;
                if(g4.x==150){
                gmovedirection[4]=9;
                    console.log("gmovedirection[2]=9")
                }
            }
            else if((gmovedirection[4]==9)&&(g4.y>=184)){

                g4.y=g4.y-2;
                if(g4.y==184){
                    gfinalmovevalue[4]=0;
                }


            }
            gfinalmovevalue=gfinalmovevalue-2;


        if(gfinalmovevalue==0){
            gmove1=0;
            gmove2=0;
             text9.text="0";

     if((g4.x==218)&&(g4.y==320)){
        g4curposition=2;
    }
    else if((g4.x==286)&&(g4.y==320)){
        g4curposition=3;
    }
    else if((g4.x==286)&&(g4.y==252)){
        g4curposition=4;
    }
    else if((g4.x==286)&&(g4.y==184)){
        g4curposition=5;
    }
    else if((g4.x==286)&&(g4.y==116)){
        g4curposition=6;
    }
    else if((g4.x==286)&&(g4.y==48)){
        g4curposition=7;
    }
    else if((g4.x==218)&&(g4.y==48)){
        g4curposition=8;
    }
    else if((g4.x==150)&&(g4.y==48)){
        g4curposition=9;
    }
    else if((g4.x==82)&&(g4.y==48)){
        g4curposition=10;
    }
    else if((g4.x==14)&&(g4.y==48)){
        g4curposition=11;
    }
    else if((g4.x==14)&&(g4.y==116)){
        g4curposition=12;
    }
    else if((g4.x==14)&&(g4.y==184)){
        g4curposition=13;
    }
    else if((g4.x==14)&&(g4.y==252)){
        g4curposition=14;
    }
    else if((g4.x==14)&&(g4.y==320)){
        g4curposition=15;
    }
    else if((g4.x==82)&&(g4.y==320)){
        g4curposition=16;
    }
    else if((g4.x==82)&&(g4.y==252)){
        g4curposition=17;
    }
    else if((g4.x==82)&&(g4.y==184)){
        g4curposition=18;
    }
    else if((g4.x==82)&&(g4.y==116)){
        g4curposition=19;
    }
    else if((g4.x==150)&&(g4.y==116)){
        g4curposition=20;
    }
    else if((g4.x==218)&&(g4.y==116)){
        g4curposition=21;
    }
    else if((g4.x==218)&&(g4.y==184)){
        g4curposition=22;
    }
    else if((g4.x==218)&&(g4.y==252)){
        g4curposition=23;
    }
    else if((g4.x==150)&&(g4.y==252)){
        g4curposition=24;
    }
    else if((g4.x==150)&&(g4.y==184)){
        g4curposition=25;
    }

    console.log("g1curposition"+g1curposition)
    console.log("g2curposition"+g2curposition)
    console.log("g3curposition"+g3curposition)
    console.log("g4curposition"+g4curposition)
    console.log("b1curposition"+b1curposition)
    console.log("b2curposition"+b2curposition)
    console.log("b3curposition"+b3curposition)
    console.log("b4curposition"+b4curposition)
    console.log("r1curposition"+r1curposition)
    console.log("r2curposition"+r2curposition)
    console.log("r3curposition"+r3curposition)
    console.log("r4curposition"+r4curposition)
    console.log("y1curposition"+y1curposition)
    console.log("y2curposition"+y2curposition)
    console.log("y3curposition"+y3curposition)
    console.log("y4curposition"+y4curposition)
            gkillcheck(g4);


        }
    }}}
function moveblue1(){
   //console.log("moveblue1 called")
    if(moveconsent==1){
        //console.log("moveconsent"+moveconsent)
    if(bfinalmovevalue){
       // console.log("1st cond is true")
            if((b1.x==290)&&(b1.y>=22)&&(bmovedirection[1]==0))
            {

                b1.y=b1.y-2;
                if(b1.y==22){
                    bmovedirection[1]=1
                }
            }

            else if((bmovedirection[1]==1)&&(b1.x>=18)){
                b1.x=b1.x-2;
                if(b1.x==18){
                    bmovedirection[1]=2
                }
            }

            else if((bmovedirection[1]==2)&&(b1.y<=294)){
                b1.y=b1.y+2;
                if(b1.y==294){
                    bmovedirection[1]=3
                }
            }

            else if((bmovedirection[1]==3)&&(b1.x<=290)){
                b1.x=b1.x+2
                if(b1.x==290){
                    bmovedirection[1]=4;
                }
            }

            else if((bmovedirection[1]==4)&&(b1.y>=226)){

                    b1.y=b1.y-2

                  if(b1.y==226){

                bmovedirection[1]=5}
            }
            else if((bmovedirection[1]==5)&&(b1.x>=86)){

                 b1.x=b1.x-2;
                  if(b1.x==86){
                    bmovedirection[1]=6;
                }
            }
            else if((bmovedirection[1]==6)&&(b1.y>=90)){
                b1.y=b1.y-2;
                if(b1.y==90){
                    bmovedirection[1]=7;
                }
            }
            else if((bmovedirection[1]==7)&&(b1.x<=222)){
                    b1.x=b1.x+2;
                if(b1.x==222){
                    bmovedirection[1]=8;
                }
        }
            else if((bmovedirection[1]==8)&&(b1.y<=158)){
                    b1.y=b1.y+2;
                if(b1.y==158){
                bmovedirection[1]=9;
                    console.log("gmovedirection[1]=9")
                }
            }
            else if((bmovedirection[1]==9)&&(b1.x>=154)){

                b1.x=b1.x-2;
                if(b1.x==154){
                  //  bfinalmovevalue[1]=0;
                }


            }
            bfinalmovevalue=bfinalmovevalue-2;


    if(bfinalmovevalue==0){
        bmove1=0;
        bmove2=0;
        text9.text="0";
        console.log("executing bfinalmovevalue")

     if((b1.x==290)&&(b1.y==90)){
         console.log("executing")
        b1curposition=2;
    }
    else if((b1.x==290)&&(b1.y==22)){
         console.log("executing")
        b1curposition=3;
    }
    else if((b1.x==222)&&(b1.y==22)){
         console.log("executing")
        b1curposition=4;
    }
    else if((b1.x==154)&&(b1.y==22)){
         console.log("executing")
        b1curposition=5;
    }
    else if((b1.x==86)&&(b1.y==22)){
         console.log("executing")
        b1curposition=6;
    }
    else if((b1.x==18)&&(b1.y==22)){
         console.log("executing")
        b1curposition=7;
    }
    else if((b1.x==18)&&(b1.y==90)){
         console.log("executing")
        b1curposition=8;
    }
    else if((b1.x==18)&&(b1.y==158)){
         console.log("executing")
        b1curposition=9;
    }
    else if((b1.x==18)&&(b1.y==226)){
         console.log("executing")
        b1curposition=10;
    }
    else if((b1.x==18)&&(b1.y==294)){
         console.log("executing")
        b1curposition=11;
    }
    else if((b1.x==86)&&(b1.y==294)){
         console.log("executing")
        b1curposition=12;
    }
    else if((b1.x==154)&&(b1.y==294)){
         console.log("executing")
        b1curposition=13;
    }
    else if((b1.x==222)&&(b1.y==294)){
         console.log("executing")
        b1curposition=14;
    }
    else if((b1.x==290)&&(b1.y==294)){
         console.log("executing")
        b1curposition=15;
    }
    else if((b1.x==290)&&(b1.y==226)){
         console.log("executing")
        b1curposition=16;
    }
    else if((b1.x==222)&&(b1.y==226)){
         console.log("executing")
        b1curposition=17;
    }
    else if((b1.x==154)&&(b1.y==226)){
         console.log("executing")
        b1curposition=18;
    }
    else if((b1.x==86)&&(b1.y==226)){
         console.log("executing")
        b1curposition=19;
    }
    else if((b1.x==86)&&(b1.y==158)){
         console.log("executing")
        b1curposition=20;
    }
    else if((b1.x==86)&&(b1.y==90)){
         console.log("executing")
        b1curposition=21;
    }
    else if((b1.x==154)&&(b1.y==90)){
         console.log("executing")
        b1curposition=22;
    }
    else if((b1.x==222)&&(b1.y==90)){
         console.log("executing")
        b1curposition=23;
    }
    else if((b1.x==222)&&(b1.y==158)){
         console.log("executing")
        b1curposition=24;
    }
    else if((b1.x==154)&&(b1.y==158)){
         console.log("executing")
        b1curposition=25;
    }
    console.log("g1curposition"+g1curposition)
    console.log("g2curposition"+g2curposition)
    console.log("g3curposition"+g3curposition)
    console.log("g4curposition"+g4curposition)
    console.log("b1curposition"+b1curposition)
    console.log("b2curposition"+b2curposition)
    console.log("b3curposition"+b3curposition)
    console.log("b4curposition"+b4curposition)
    console.log("r1curposition"+r1curposition)
    console.log("r2curposition"+r2curposition)
    console.log("r3curposition"+r3curposition)
    console.log("r4curposition"+r4curposition)
    console.log("y1curposition"+y1curposition)
    console.log("y2curposition"+y2curposition)
    console.log("y3curposition"+y3curposition)
    console.log("y4curposition"+y4curposition)
        bkillcheck(b1);

    }
    }}}
function moveblue2(){
    //console.log("moveblue2 called")
    if(moveconsent==1){
    if(bfinalmovevalue){
           // console.log("executing for loop")
            if((b2.x==320)&&(b2.y>=14)&&(bmovedirection[2]==0))
            {

                b2.y=b2.y-2;
                if(b2.y==14){
                    bmovedirection[2]=1
                }
            }

            else if((bmovedirection[2]==1)&&(b2.x>=48)){
                b2.x=b2.x-2;
                if(b2.x==48){
                    bmovedirection[2]=2
                }
            }

            else if((bmovedirection[2]==2)&&(b2.y<=286)){
                b2.y=b2.y+2;
                if(b2.y==286){
                    bmovedirection[2]=3
                }
            }

            else if((bmovedirection[2]==3)&&(b2.x<=320)){
                b2.x=b2.x+2
                if(b2.x==320){
                    bmovedirection[2]=4;
                }
            }

            else if((bmovedirection[2]==4)&&(b2.y>=218)){

                    b2.y=b2.y-2

                  if(b2.y==218){

                bmovedirection[2]=5}
            }
            else if((bmovedirection[2]==5)&&(b2.x>=116)){

                 b2.x=b2.x-2;
                  if(b2.x==116){
                    bmovedirection[2]=6;
                }
            }
            else if((bmovedirection[2]==6)&&(b2.y>=82)){
                b2.y=b2.y-2;
                if(b2.y==82){
                    bmovedirection[2]=7;
                }
            }
            else if((bmovedirection[2]==7)&&(b2.x<=252)){
                    b2.x=b2.x+2;
                if(b2.x==252){
                    bmovedirection[2]=8;
                }
        }
            else if((bmovedirection[2]==8)&&(b2.y<=150)){
                    b2.y=b2.y+2;
                if(b2.y==150){
                bmovedirection[2]=9;
                    console.log("gmovedirection[1]=9")
                }
            }
            else if((bmovedirection[2]==9)&&(b2.x>=184)){

                b2.x=b2.x-2;
                if(b2.x==184){
                   // bfinalmovevalue[2]=0;
                }


            }
            bfinalmovevalue=bfinalmovevalue-2;


    if(bfinalmovevalue==0){
        bmove1=0;
        bmove2=0;
         text9.text="0";

    if((b2.x==320)&&(b2.y==82)){
        b2curposition=2;
    }
    else if((b2.x==320)&&(b2.y==14)){
        b2curposition=3;
    }
    else if((b2.x==252)&&(b2.y==14)){
        b2curposition=4;
    }
    else if((b2.x==184)&&(b2.y==14)){
        b2curposition=5;
    }
    else if((b2.x==116)&&(b2.y==14)){
        b2curposition=6;
    }
    else if((b2.x==48)&&(b2.y==14)){
        b2curposition=7;
    }
    else if((b2.x==48)&&(b2.y==82)){
        b2curposition=8;
    }
    else if((b2.x==48)&&(b2.y==150)){
        b2curposition=9;
    }
    else if((b2.x==48)&&(b2.y==218)){
        b2curposition=10;
    }
    else if((b2.x==48)&&(b2.y==286)){
        b2curposition=11;
    }
    else if((b2.x==116)&&(b2.y==286)){
        b2curposition=12;
    }
    else if((b2.x==184)&&(b2.y==286)){
        b2curposition=13;
    }
    else if((b2.x==252)&&(b2.y==286)){
        b2curposition=14;
    }
    else if((b2.x==320)&&(b2.y==286)){
        b2curposition=15;
    }
    else if((b2.x==320)&&(b2.y==218)){
        b2curposition=16;
    }
    else if((b2.x==252)&&(b2.y==218)){
        b2curposition=17;
    }
    else if((b2.x==184)&&(b2.y==218)){
        b2curposition=18;
    }
    else if((b2.x==46)&&(b2.y==218)){
        b2curposition=19;
    }
    else if((b2.x==46)&&(b2.y==150)){
        b2curposition=20;
    }
    else if((b2.x==116)&&(b2.y==82)){
        b2curposition=21;
    }
    else if((b2.x==184)&&(b2.y==82)){
        b2curposition=22;
    }
    else if((b2.x==252)&&(b2.y==82)){
        b2curposition=23;
    }
    else if((b2.x==252)&&(b2.y==150)){
        b2curposition=24;
    }
    else if((b2.x==184)&&(b2.y==150)){
        b2curposition=25;
    }
    console.log("g1curposition"+g1curposition)
    console.log("g2curposition"+g2curposition)
    console.log("g3curposition"+g3curposition)
    console.log("g4curposition"+g4curposition)
    console.log("b1curposition"+b1curposition)
    console.log("b2curposition"+b2curposition)
    console.log("b3curposition"+b3curposition)
    console.log("b4curposition"+b4curposition)
    console.log("r1curposition"+r1curposition)
    console.log("r2curposition"+r2curposition)
    console.log("r3curposition"+r3curposition)
    console.log("r4curposition"+r4curposition)
    console.log("y1curposition"+y1curposition)
    console.log("y2curposition"+y2curposition)
    console.log("y3curposition"+y3curposition)
    console.log("y4curposition"+y4curposition)
        bkillcheck(b2);

    }
    }}}
function moveblue3(){
    //console.log("moveblue3 called")
    if(moveconsent==1){
    if(bfinalmovevalue){
           // console.log("executing for loop")
            if((b3.x==336)&&(b3.y>=46)&&(bmovedirection[3]==0))
            {

                b3.y=b3.y-2;
                if(b3.y==46){
                    bmovedirection[3]=1
                }
            }

            else if((bmovedirection[3]==1)&&(b3.x>=64)){
                b3.x=b3.x-2;
                if(b3.x==64){
                    bmovedirection[3]=2
                }
            }

            else if((bmovedirection[3]==2)&&(b3.y<=318)){
                b3.y=b3.y+2;
                if(b3.y==318){
                    bmovedirection[3]=3
                }
            }

            else if((bmovedirection[3]==3)&&(b3.x<=336)){
                b3.x=b3.x+2
                if(b3.x==336){
                    bmovedirection[3]=4;
                }
            }

            else if((bmovedirection[3]==4)&&(b3.y>=250)){

                    b3.y=b3.y-2

                  if(b3.y==250){

                bmovedirection[3]=5}
            }
            else if((bmovedirection[3]==5)&&(b3.x>=132)){

                 b3.x=b3.x-2;
                  if(b3.x==132){
                    bmovedirection[3]=6;
                }
            }
            else if((bmovedirection[3]==6)&&(b3.y>=114)){
                b3.y=b3.y-2;
                if(b3.y==114){
                    bmovedirection[3]=7;
                }
            }
            else if((bmovedirection[3]==7)&&(b3.x<=268)){
                    b3.x=b3.x+2;
                if(b3.x==268){
                    bmovedirection[3]=8;
                }
        }
            else if((bmovedirection[3]==8)&&(b3.y<=182)){
                    b3.y=b3.y+2;
                if(b3.y==182){
                bmovedirection[3]=9;
                    console.log("gmovedirection[3]=9")
                }
            }
            else if((bmovedirection[3]==9)&&(b3.x>=200)){

                b3.x=b3.x-2;
                if(b3.x==200){
                    bfinalmovevalue[3]=0;
                }


            }
            bfinalmovevalue=bfinalmovevalue-2;


    if(bfinalmovevalue==0){
        bmove1=0;
        bmove2=0;
                text9.text="0";

    if((b3.x==336)&&(b3.y==114)){
        b3curposition=2;
    }
    else if((b3.x==336)&&(b3.y==46)){
        b3curposition=3;
    }
    else if((b3.x==268)&&(b3.y==46)){
        b3curposition=4;
    }
    else if((b3.x==200)&&(b3.y==46)){
        b3curposition=5;
    }
    else if((b3.x==132)&&(b3.y==46)){
        b3curposition=6;
    }
    else if((b3.x==64)&&(b3.y==46)){
        b3curposition=7;
    }
    else if((b3.x==64)&&(b3.y==114)){
        b3curposition=8;
    }
    else if((b3.x==64)&&(b3.y==182)){
        b3curposition=9;
    }
    else if((b3.x==64)&&(b3.y==250)){
        b3curposition=10;
    }
    else if((b3.x==64)&&(b3.y==318)){
        b3curposition=11;
    }
    else if((b3.x==132)&&(b3.y==318)){
        b3curposition=12;
    }
    else if((b3.x==200)&&(b3.y==318)){
        b3curposition=13;
    }
    else if((b3.x==268)&&(b3.y==318)){
        b3curposition=14;
    }
    else if((b3.x==336)&&(b3.y==318)){
        b3curposition=15;
    }
    else if((b3.x==336)&&(b3.y==250)){
        b3curposition=16;
    }
    else if((b3.x==268)&&(b3.y==250)){
        b3curposition=17;
    }
    else if((b3.x==200)&&(b3.y==250)){
        b3curposition=18;
    }
    else if((b3.x==132)&&(b3.y==250)){
        b3curposition=19;
    }
    else if((b3.x==132)&&(b3.y==182)){
        b3curposition=20;
    }
    else if((b3.x==132)&&(b3.y==114)){
        b3curposition=21;
    }
    else if((b3.x==200)&&(b3.y==114)){
        b3curposition=22;
    }
    else if((b3.x==268)&&(b3.y==114)){
        b3curposition=23;
    }
    else if((b3.x==268)&&(b3.y==182)){
        b3curposition=24;
    }
    else if((b3.x==200)&&(b3.y==182)){
        b3curposition=25;
    }
    console.log("g1curposition"+g1curposition)
    console.log("g2curposition"+g2curposition)
    console.log("g3curposition"+g3curposition)
    console.log("g4curposition"+g4curposition)
    console.log("b1curposition"+b1curposition)
    console.log("b2curposition"+b2curposition)
    console.log("b3curposition"+b3curposition)
    console.log("b4curposition"+b4curposition)
    console.log("r1curposition"+r1curposition)
    console.log("r2curposition"+r2curposition)
    console.log("r3curposition"+r3curposition)
    console.log("r4curposition"+r4curposition)
    console.log("y1curposition"+y1curposition)
    console.log("y2curposition"+y2curposition)
    console.log("y3curposition"+y3curposition)
    console.log("y4curposition"+y4curposition)
        bkillcheck(b3);


    }
    }}}
function moveblue4(){
   // console.log("moveblue1 called")
    if(moveconsent==1){

    if(bfinalmovevalue){
            //console.log("executing for loop")
            if((b4.x==300)&&(b4.y>=56)&&(bmovedirection[4]==0))
            {
                console.log("bmovdir[4]"+bmovedirection[4])
                b4.y=b4.y-2;
                if(b4.y==56){
                    bmovedirection[4]=1
                    console.log("bmovdir[4]"+bmovedirection[4])
                }
            }

            else if((bmovedirection[4]==1)&&(b4.x>=28)){
                console.log("bmovdir[4]"+bmovedirection[4])
                b4.x=b4.x-2;
                if(b4.x==28){
                    bmovedirection[4]=2
                }
            }

            else if((bmovedirection[4]==2)&&(b4.y<=328)){
                b4.y=b4.y+2;
                if(b4.y==328){
                    bmovedirection[4]=3
                }
            }

            else if((bmovedirection[4]==3)&&(b4.x<=300)){
                b4.x=b4.x+2
                if(b4.x==300){
                    bmovedirection[4]=4;
                }
            }

            else if((bmovedirection[4]==4)&&(b4.y>=260)){

                    b4.y=b4.y-2

                  if(b4.y==260){

                bmovedirection[4]=5}
            }
            else if((bmovedirection[4]==5)&&(b4.x>=96)){

                 b4.x=b4.x-2;
                  if(b4.x==96){
                    bmovedirection[4]=6;
                }
            }
            else if((bmovedirection[4]==6)&&(b4.y>=124)){
                b4.y=b4.y-2;
                if(b4.y==124){
                    bmovedirection[4]=7;
                }
            }
            else if((bmovedirection[4]==7)&&(b4.x<=232)){
                    b4.x=b4.x+2;
                if(b4.x==232){
                    bmovedirection[4]=8;
                }
        }
            else if((bmovedirection[4]==8)&&(b4.y<=192)){
                    b4.y=b4.y+2;
                if(b4.y==192){
                bmovedirection[4]=9;
                    console.log("gmovedirection[4]=9")
                }
            }
            else if((bmovedirection[4]==9)&&(b4.x>=164)){

                b4.x=b4.x-2;
                if(b4.x==164){
                    bfinalmovevalue[4]=0;
                }


            }
            bfinalmovevalue=bfinalmovevalue-2;


    if(bfinalmovevalue==0){
        bmove1=0;
        bmove2=0;
           text9.text="0";

    if((b4.x==300)&&(b4.y==124)){
        b4curposition=2;
    }
    else if((b4.x==300)&&(b4.y==56)){
        b4curposition=3;
    }
    else if((b4.x==232)&&(b4.y==56)){
        b4curposition=4;
    }
    else if((b4.x==164)&&(b4.y==56)){
        b4curposition=5;
    }
    else if((b4.x==96)&&(b4.y==56)){
        b4curposition=6;
    }
    else if((b4.x==28)&&(b4.y==56)){
        b4curposition=7;
    }
    else if((b4.x==28)&&(b4.y==124)){
        b4curposition=8;
    }
    else if((b4.x==28)&&(b4.y==192)){
        b4curposition=9;
    }
    else if((b4.x==28)&&(b4.y==260)){
        b4curposition=10;
    }
    else if((b4.x==28)&&(b4.y==328)){
        b4curposition=11;
    }
    else if((b4.x==96)&&(b4.y==328)){
        b4curposition=12;
    }
    else if((b4.x==164)&&(b4.y==328)){
        b4curposition=13;
    }
    else if((b4.x==232)&&(b4.y==328)){
        b4curposition=14;
    }
    else if((b4.x==300)&&(b4.y==328)){
        b4curposition=15;
    }
    else if((b4.x==300)&&(b4.y==260)){
        b4curposition=16;
    }
    else if((b4.x==232)&&(b4.y==260)){
        b4curposition=17;
    }
    else if((b4.x==164)&&(b4.y==260)){
        b4curposition=18;
    }
    else if((b4.x==96)&&(b4.y==260)){
        b4curposition=19;
    }
    else if((b4.x==96)&&(b4.y==192)){
        b4curposition=20;
    }
    else if((b4.x==96)&&(b4.y==124)){
        b4curposition=21;
    }
    else if((b4.x==164)&&(b4.y==124)){
        b4curposition=22;
    }
    else if((b4.x==232)&&(b4.y==124)){
        b4curposition=23;
    }
    else if((b4.x==232)&&(b4.y==192)){
        b4curposition=24;
    }
    else if((b4.x==164)&&(b4.y==192)){
        b4curposition=25;
    }
    console.log("g1curposition"+g1curposition)
    console.log("g2curposition"+g2curposition)
    console.log("g3curposition"+g3curposition)
    console.log("g4curposition"+g4curposition)
    console.log("b1curposition"+b1curposition)
    console.log("b2curposition"+b2curposition)
    console.log("b3curposition"+b3curposition)
    console.log("b4curposition"+b4curposition)
    console.log("r1curposition"+r1curposition)
    console.log("r2curposition"+r2curposition)
    console.log("r3curposition"+r3curposition)
    console.log("r4curposition"+r4curposition)
    console.log("y1curposition"+y1curposition)
    console.log("y2curposition"+y2curposition)
    console.log("y3curposition"+y3curposition)
    console.log("y4curposition"+y4curposition)
        bkillcheck(b4);

    }}}}

function movered1(){
   //console.log("moveblue1 called")
    if(moveconsent==1){
        //console.log("moveconsent"+moveconsent)
    if(rfinalmovevalue){
       // console.log("1st cond is true")
            if((r1.x<=174)&&(r1.y==16)&&(rmovedirection[1]==0))
            {

                r1.x=r1.x-2;
                if(r1.x==38){
                    rmovedirection[1]=1
                }
            }

            else if((rmovedirection[1]==1)&&(r1.y<=288)){
                r1.y=r1.y+2;
                if(r1.y==288){
                    rmovedirection[1]=2
                }
            }

            else if((rmovedirection[1]==2)&&(r1.x<=310)){
                r1.x=r1.x+2;
                if(r1.x==310){
                    rmovedirection[1]=3
                }
            }

            else if((rmovedirection[1]==3)&&(r1.y>=16)){
                r1.y=r1.y-2
                if(r1.y==16){
                    rmovedirection[1]=4;
                }
            }

            else if((rmovedirection[1]==4)&&(r1.x>=242)){

                    r1.x=r1.x-2

                  if(r1.x==242){

                rmovedirection[1]=5}
            }
            else if((rmovedirection[1]==5)&&(r1.y<=220)){

                 r1.y=r1.y+2;
                  if(r1.y==220){
                    rmovedirection[1]=6;
                }
            }
            else if((rmovedirection[1]==6)&&(r1.x>=106)){
                r1.x=r1.x-2;
                if(r1.x==106){
                    rmovedirection[1]=7;
                }
            }
            else if((rmovedirection[1]==7)&&(r1.y>=84)){
                    r1.y=r1.y-2;
                if(r1.y==84){
                    rmovedirection[1]=8;
                }
        }
            else if((rmovedirection[1]==8)&&(r1.x<=174)){
                    r1.x=r1.x+2;
                if(r1.x==174){
                rmovedirection[1]=9;
                    console.log("gmovedirection[1]=9")
                }
            }
            else if((rmovedirection[1]==9)&&(r1.y<=152)){

                r1.y=r1.y+2;
                if(r1.y==152){
                  //  bfinalmovevalue[1]=0;
                }
            }
            rfinalmovevalue=rfinalmovevalue-2;


    if(rfinalmovevalue==0){
        rmove1=0;
        rmove2=0;
                 text9.text="0";
        console.log("r1.x="+r1.x)
        console.log("r1.y="+r1.y)

    if((r1.x==106)&&(r1.y==16)){
        r1curposition=2;
    }
    else if((r1.x==38)&&(r1.y==16)){
        r1curposition=3;
    }
    else if((r1.x==38)&&(r1.y==84)){
        r1curposition=4;
    }
    else if((r1.x==38)&&(r1.y==152)){
        r1curposition=5;
    }
    else if((r1.x==38)&&(r1.y==220)){
        r1curposition=6;
    }
    else if((r1.x==38)&&(r1.y==288)){
        r1curposition=7;
    }
    else if((r1.x==106)&&(r1.y==288)){
        r1curposition=8;
    }
    else if((r1.x==174)&&(r1.y==288)){
        r1curposition=9;
    }
    else if((r1.x==242)&&(r1.y==288)){
        r1curposition=10;
    }
    else if((r1.x==310)&&(r1.y==288)){
        r1curposition=11;
    }
    else if((r1.x==310)&&(r1.y==220)){
        r1curposition=12;
    }
    else if((r1.x==310)&&(r1.y==152)){
        r1curposition=13;
    }
    else if((r1.x==310)&&(r1.y==84)){
        r1curposition=14;
    }
    else if((r1.x==310)&&(r1.y==16)){
        r1curposition=15;
    }
    else if((r1.x==242)&&(r1.y==16)){
        r1curposition=16;
    }
    else if((r1.x==242)&&(r1.y==84)){
        r1curposition=17;
    }
    else if((r1.x==242)&&(r1.y==152)){
        r1curposition=18;
    }
    else if((r1.x==242)&&(r1.y==220)){
        r1curposition=19;
    }
    else if((r1.x==174)&&(r1.y==220)){
        r1curposition=20;
    }
    else if((r1.x==106)&&(r1.y==220)){
        r1curposition=21;
    }
    else if((r1.x==106)&&(r1.y==152)){
        r1curposition=22;
    }
    else if((r1.x==106)&&(r1.y==84)){
        r1curposition=23;
    }
    else if((r1.x==174)&&(r1.y==84)){
        r1curposition=24;
    }
    else if((r1.x==174)&&(r1.y==152)){
        r1curposition=25;
    }
    console.log("g1curposition"+g1curposition)
    console.log("g2curposition"+g2curposition)
    console.log("g3curposition"+g3curposition)
    console.log("g4curposition"+g4curposition)
    console.log("b1curposition"+b1curposition)
    console.log("b2curposition"+b2curposition)
    console.log("b3curposition"+b3curposition)
    console.log("b4curposition"+b4curposition)
    console.log("r1curposition"+r1curposition)
    console.log("r2curposition"+r2curposition)
    console.log("r3curposition"+r3curposition)
    console.log("r4curposition"+r4curposition)
    console.log("y1curposition"+y1curposition)
    console.log("y2curposition"+y2curposition)
    console.log("y3curposition"+y3curposition)
    console.log("y4curposition"+y4curposition)
        rkillcheck(r1);

    }
    }}}

function movered2(){
   //console.log("moveblue1 called")
    if(moveconsent==1){
        //console.log("moveconsent"+moveconsent)
    if(rfinalmovevalue){
       // console.log("1st cond is true")
            if((r2.x<=188)&&(r2.y==30)&&(rmovedirection[2]==0))
            {

                r2.x=r2.x-2;
                if(r2.x==52){
                    rmovedirection[2]=1
                }
            }

            else if((rmovedirection[2]==1)&&(r2.y<=302)){
                r2.y=r2.y+2;
                if(r2.y==302){
                    rmovedirection[2]=2
                }
            }

            else if((rmovedirection[2]==2)&&(r2.x<=324)){
                r2.x=r2.x+2;
                if(r2.x==324){
                    rmovedirection[2]=3
                }
            }

            else if((rmovedirection[2]==3)&&(r2.y>=30)){
                r2.y=r2.y-2
                if(r2.y==30){
                    rmovedirection[2]=4;
                }
            }

            else if((rmovedirection[2]==4)&&(r2.x>=256)){

                    r2.x=r2.x-2

                  if(r2.x==256){

                rmovedirection[2]=5}
            }
            else if((rmovedirection[2]==5)&&(r2.y<=234)){

                 r2.y=r2.y+2;
                  if(r2.y==234){
                    rmovedirection[2]=6;
                }
            }
            else if((rmovedirection[2]==6)&&(r2.x>=120)){
                r2.x=r2.x-2;
                if(r2.x==120){
                    rmovedirection[2]=7;
                }
            }
            else if((rmovedirection[2]==7)&&(r2.y>=98)){
                    r2.y=r2.y-2;
                if(r2.y==98){
                    rmovedirection[2]=8;
                }
        }
            else if((rmovedirection[2]==8)&&(r2.x<=188)){
                    r2.x=r2.x+2;
                if(r2.x==188){
                rmovedirection[2]=9;
                    console.log("gmovedirection[1]=9")
                }
            }
            else if((rmovedirection[2]==9)&&(r2.y<=166)){

                r2.y=r2.y+2;
                if(r2.y==166){
                  //  bfinalmovevalue[1]=0;
                }
            }
            rfinalmovevalue=rfinalmovevalue-2;


    if(rfinalmovevalue==0){
        rmove1=0;
        rmove2=0;
               text9.text="0";

    if((r2.x==120)&&(r2.y==30)){
        r2curposition=2;
    }
    else if((r2.x==52)&&(r2.y==30)){
        r2curposition=3;
    }
    else if((r2.x==52)&&(r2.y==98)){
        r2curposition=4;
    }
    else if((r2.x==52)&&(r2.y==166)){
        r2curposition=5;
    }
    else if((r2.x==52)&&(r2.y==234)){
        r2curposition=6;
    }
    else if((r2.x==52)&&(r2.y==302)){
        r2curposition=7;
    }
    else if((r2.x==120)&&(r2.y==302)){
        r2curposition=8;
    }
    else if((r2.x==188)&&(r2.y==302)){
        r2curposition=9;
    }
    else if((r2.x==256)&&(r2.y==302)){
        r2curposition=10;
    }
    else if((r2.x==324)&&(r2.y==302)){
        r2curposition=11;
    }
    else if((r2.x==324)&&(r2.y==234)){
        r2curposition=12;
    }
    else if((r2.x==324)&&(r2.y==166)){
        r2curposition=13;
    }
    else if((r2.x==324)&&(r2.y==98)){
        r2curposition=14;
    }
    else if((r2.x==324)&&(r2.y==30)){
        r2curposition=15;
    }
    else if((r2.x==256)&&(r2.y==30)){
        r2curposition=16;
    }
    else if((r2.x==256)&&(r2.y==98)){
        r2curposition=17;
    }
    else if((r2.x==256)&&(r2.y==166)){
        r2curposition=18;
    }
    else if((r2.x==256)&&(r2.y==234)){
        r2curposition=19;
    }
    else if((r2.x==188)&&(r2.y==234)){
        r2curposition=20;
    }
    else if((r2.x==120)&&(r2.y==234)){
        r2curposition=21;
    }
    else if((r2.x==120)&&(r2.y==166)){
        r2curposition=22;
    }
    else if((r2.x==120)&&(r2.y==98)){
        r2curposition=23;
    }
    else if((r2.x==188)&&(r2.y==98)){
        r2curposition=24;
    }
    else if((r2.x==188)&&(r2.y==166)){
        r2curposition=25;
    }
    console.log("g1curposition"+g1curposition)
    console.log("g2curposition"+g2curposition)
    console.log("g3curposition"+g3curposition)
    console.log("g4curposition"+g4curposition)
    console.log("b1curposition"+b1curposition)
    console.log("b2curposition"+b2curposition)
    console.log("b3curposition"+b3curposition)
    console.log("b4curposition"+b4curposition)
    console.log("r1curposition"+r1curposition)
    console.log("r2curposition"+r2curposition)
    console.log("r3curposition"+r3curposition)
    console.log("r4curposition"+r4curposition)
    console.log("y1curposition"+y1curposition)
    console.log("y2curposition"+y2curposition)
    console.log("y3curposition"+y3curposition)
    console.log("y4curposition"+y4curposition)
        rkillcheck(r2);

    }
    }}}

function movered3(){
   //console.log("moveblue1 called")
    if(moveconsent==1){
        //console.log("moveconsent"+moveconsent)
    if(rfinalmovevalue){
       // console.log("1st cond is true")
            if((r3.x<=174)&&(r3.y==42)&&(rmovedirection[3]==0))
            {

                r3.x=r3.x-2;
                if(r3.x==38){
                    rmovedirection[3]=1
                }
            }

            else if((rmovedirection[3]==1)&&(r3.y<=314)){
                r3.y=r3.y+2;
                if(r3.y==314){
                    rmovedirection[3]=2
                }
            }

            else if((rmovedirection[3]==2)&&(r3.x<=310)){
                r3.x=r3.x+2;
                if(r3.x==310){
                    rmovedirection[3]=3
                }
            }

            else if((rmovedirection[3]==3)&&(r3.y>=42)){
                r3.y=r3.y-2
                if(r3.y==42){
                    rmovedirection[3]=4;
                }
            }

            else if((rmovedirection[3]==4)&&(r3.x>=242)){

                    r3.x=r3.x-2

                  if(r3.x==242){

                rmovedirection[3]=5}
            }
            else if((rmovedirection[3]==5)&&(r3.y<=246)){

                 r3.y=r3.y+2;
                  if(r3.y==246){
                    rmovedirection[3]=6;
                }
            }
            else if((rmovedirection[3]==6)&&(r3.x>=106)){
                r3.x=r3.x-2;
                if(r3.x==106){
                    rmovedirection[3]=7;
                }
            }
            else if((rmovedirection[3]==7)&&(r3.y>=110)){
                    r3.y=r3.y-2;
                if(r3.y==110){
                    rmovedirection[3]=8;
                }
        }
            else if((rmovedirection[3]==8)&&(r3.x<=174)){
                    r3.x=r3.x+2;
                if(r3.x==174){
                rmovedirection[3]=9;
                    console.log("gmovedirection[1]=9")
                }
            }
            else if((rmovedirection[3]==9)&&(r3.y<=178)){

                r3.y=r3.y+2;
                if(r3.y==152){
                  //  bfinalmovevalue[1]=0;
                }
            }
            rfinalmovevalue=rfinalmovevalue-2;


    if(rfinalmovevalue==0){
        rmove1=0;
        rmove2=0;
          text9.text="0";

    if((r3.x==106)&&(r3.y==42)){
        r3curposition=2;
    }
    else if((r3.x==38)&&(r3.y==42)){
        r3curposition=3;
    }
    else if((r3.x==38)&&(r3.y==110)){
        r3curposition=4;
    }
    else if((r3.x==38)&&(r3.y==178)){
        r3curposition=5;
    }
    else if((r3.x==38)&&(r3.y==246)){
        r3curposition=6;
    }
    else if((r3.x==38)&&(r3.y==314)){
        r3curposition=7;
    }
    else if((r3.x==106)&&(r3.y==314)){
        r3curposition=8;
    }
    else if((r3.x==174)&&(r3.y==314)){
        r3curposition=9;
    }
    else if((r3.x==242)&&(r3.y==314)){
        r3curposition=10;
    }
    else if((r3.x==310)&&(r3.y==314)){
        r3curposition=11;
    }
    else if((r3.x==310)&&(r3.y==246)){
        r3curposition=12;
    }
    else if((r3.x==310)&&(r3.y==178)){
        r3curposition=13;
    }
    else if((r3.x==310)&&(r3.y==110)){
        r3curposition=14;
    }
    else if((r3.x==310)&&(r3.y==42)){
        r3curposition=15;
    }
    else if((r3.x==242)&&(r3.y==42)){
        r3curposition=16;
    }
    else if((r3.x==242)&&(r3.y==110)){
        r3curposition=17;
    }
    else if((r3.x==242)&&(r3.y==178)){
        r3curposition=18;
    }
    else if((r3.x==242)&&(r3.y==246)){
        r3curposition=19;
    }
    else if((r3.x==174)&&(r3.y==246)){
        r3curposition=20;
    }
    else if((r3.x==106)&&(r3.y==246)){
        r3curposition=21;
    }
    else if((r3.x==106)&&(r3.y==178)){
        r3curposition=22;
    }
    else if((r3.x==106)&&(r3.y==110)){
        r3curposition=23;
    }
    else if((r3.x==174)&&(r3.y==110)){
        r3curposition=24;
    }
    else if((r3.x==174)&&(r3.y==178)){
        r3curposition=25;
    }
    console.log("g1curposition"+g1curposition)
    console.log("g2curposition"+g2curposition)
    console.log("g3curposition"+g3curposition)
    console.log("g4curposition"+g4curposition)
    console.log("b1curposition"+b1curposition)
    console.log("b2curposition"+b2curposition)
    console.log("b3curposition"+b3curposition)
    console.log("b4curposition"+b4curposition)
    console.log("r1curposition"+r1curposition)
    console.log("r2curposition"+r2curposition)
    console.log("r3curposition"+r3curposition)
    console.log("r4curposition"+r4curposition)
    console.log("y1curposition"+y1curposition)
    console.log("y2curposition"+y2curposition)
    console.log("y3curposition"+y3curposition)
    console.log("y4curposition"+y4curposition)
        rkillcheck(r3);

    }
    }}}

function movered4(){
   //console.log("moveblue1 called")
    if(moveconsent==1){
        //console.log("moveconsent"+moveconsent)
    if(rfinalmovevalue){
       // console.log("1st cond is true")
            if((r4.x<=160)&&(r4.y==30)&&(rmovedirection[4]==0))
            {

                r4.x=r4.x-2;
                if(r4.x==24){
                    rmovedirection[4]=1
                }
            }

            else if((rmovedirection[4]==1)&&(r4.y<=302)){
                r4.y=r4.y+2;
                if(r4.y==302){
                    rmovedirection[4]=2
                }
            }

            else if((rmovedirection[4]==2)&&(r4.x<=296)){
                r4.x=r4.x+2;
                if(r4.x==296){
                    rmovedirection[4]=3
                }
            }

            else if((rmovedirection[4]==3)&&(r4.y>=30)){
                r4.y=r4.y-2
                if(r4.y==30){
                    rmovedirection[4]=4;
                }
            }

            else if((rmovedirection[4]==4)&&(r4.x>=228)){

                    r4.x=r4.x-2

                  if(r4.x==228){

                rmovedirection[4]=5}
            }
            else if((rmovedirection[4]==5)&&(r4.y<=234)){

                 r4.y=r4.y+2;
                  if(r4.y==234){
                    rmovedirection[4]=6;
                }
            }
            else if((rmovedirection[4]==6)&&(r4.x>=92)){
                r4.x=r4.x-2;
                if(r4.x==92){
                    rmovedirection[4]=7;
                }
            }
            else if((rmovedirection[4]==7)&&(r4.y>=98)){
                    r4.y=r4.y-2;
                if(r4.y==98){
                    rmovedirection[4]=8;
                }
        }
            else if((rmovedirection[4]==8)&&(r4.x<=160)){
                    r4.x=r4.x+2;
                if(r4.x==160){
                rmovedirection[4]=9;
                    console.log("gmovedirection[1]=9")
                }
            }
            else if((rmovedirection[4]==9)&&(r4.y<=166)){

                r4.y=r4.y+2;
                if(r4.y==166){
                  //  bfinalmovevalue[1]=0;
                }
            }
            rfinalmovevalue=rfinalmovevalue-2;


    if(rfinalmovevalue==0){
        rmove1=0;
        rmove2=0;
              text9.text="0";

    if((r4.x==98)&&(r4.y==30)){
        r4curposition=2;
    }
    else if((r4.x==24)&&(r4.y==30)){
        r4curposition=3;
    }
    else if((r4.x==24)&&(r4.y==98)){
        r4curposition=4;
    }
    else if((r4.x==24)&&(r4.y==166)){
        r4curposition=5;
    }
    else if((r4.x==24)&&(r4.y==234)){
        r4curposition=6;
    }
    else if((r4.x==24)&&(r4.y==302)){
        r4curposition=7;
    }
    else if((r4.x==92)&&(r4.y==302)){
        r4curposition=8;
    }
    else if((r4.x==160)&&(r4.y==302)){
        r4curposition=9;
    }
    else if((r4.x==228)&&(r4.y==302)){
        r4curposition=10;
    }
    else if((r4.x==296)&&(r4.y==302)){
        r4curposition=11;
    }
    else if((r4.x==296)&&(r4.y==234)){
        r4curposition=12;
    }
    else if((r4.x==296)&&(r4.y==166)){
        r4curposition=13;
    }
    else if((r4.x==296)&&(r4.y==98)){
        r4curposition=14;
    }
    else if((r4.x==296)&&(r4.y==30)){
        r4curposition=15;
    }
    else if((r4.x==228)&&(r4.y==30)){
        r4curposition=16;
    }
    else if((r4.x==228)&&(r4.y==98)){
        r4curposition=17;
    }
    else if((r4.x==228)&&(r4.y==166)){
        r4curposition=18;
    }
    else if((r4.x==228)&&(r4.y==234)){
        r4curposition=19;
    }
    else if((r4.x==160)&&(r4.y==234)){
        r4curposition=20;
    }
    else if((r4.x==92)&&(r4.y==234)){
        r4curposition=21;
    }
    else if((r4.x==92)&&(r4.y==166)){
        r4curposition=22;
    }
    else if((r4.x==92)&&(r4.y==98)){
        r4curposition=23;
    }
    else if((r4.x==160)&&(r4.y==98)){
        r4curposition=24;
    }
    else if((r4.x==160)&&(r4.y==166)){
        r4curposition=25;
    }
    console.log("g1curposition"+g1curposition)
    console.log("g2curposition"+g2curposition)
    console.log("g3curposition"+g3curposition)
    console.log("g4curposition"+g4curposition)
    console.log("b1curposition"+b1curposition)
    console.log("b2curposition"+b2curposition)
    console.log("b3curposition"+b3curposition)
    console.log("b4curposition"+b4curposition)
    console.log("r1curposition"+r1curposition)
    console.log("r2curposition"+r2curposition)
    console.log("r3curposition"+r3curposition)
    console.log("r4curposition"+r4curposition)
    console.log("y1curposition"+y1curposition)
    console.log("y2curposition"+y2curposition)
    console.log("y3curposition"+y3curposition)
    console.log("y4curposition"+y4curposition)
        rkillcheck(r4);

    }
    }}}

function moveyellow1(){
   //console.log("moveblue1 called")
    if(moveconsent==1){
        //console.log("moveconsent"+moveconsent)
    if(yfinalmovevalue){
       // console.log("1st cond is true")
            if((y1.x==24)&&(y1.y>=160)&&(ymovedirection[1]==0))
            {

                y1.y=y1.y+2;
                if(y1.y==296){
                    ymovedirection[1]=1
                }
            }

            else if((ymovedirection[1]==1)&&(y1.x<=296)){
                y1.x=y1.x+2;
                if(y1.x==296){
                    ymovedirection[1]=2
                }
            }

            else if((ymovedirection[1]==2)&&(y1.y>=24)){
                y1.y=y1.y-2;
                if(y1.y==24){
                    ymovedirection[1]=3
                }
            }

            else if((ymovedirection[1]==3)&&(y1.x>=24)){
                y1.x=y1.x-2
                if(y1.x==24){
                    ymovedirection[1]=4;
                }
            }

            else if((ymovedirection[1]==4)&&(y1.y<=92)){

                    y1.y=y1.y+2

                  if(y1.y==92){

                ymovedirection[1]=5}
            }
            else if((ymovedirection[1]==5)&&(y1.x<=228)){

                 y1.x=y1.x+2;
                  if(y1.x==228){
                    ymovedirection[1]=6;
                }
            }
            else if((ymovedirection[1]==6)&&(y1.y<=228)){
                y1.y=y1.y+2;
                if(y1.y==228){
                    ymovedirection[1]=7;
                }
            }
            else if((ymovedirection[1]==7)&&(y1.x>=92)){
                    y1.x=y1.x-2;
                if(y1.x==92){
                    ymovedirection[1]=8;
                }
        }
            else if((ymovedirection[1]==8)&&(y1.y>=160)){
                    y1.y=y1.y-2;
                if(y1.y==160){
                ymovedirection[1]=9;
                    console.log("gmovedirection[1]=9")
                }
            }
            else if((ymovedirection[1]==9)&&(y1.x<=160)){

                y1.x=y1.x+2;
                if(y1.x==160){
                  //  bfinalmovevalue[1]=0;
                }


            }
            yfinalmovevalue=yfinalmovevalue-2;


    if(yfinalmovevalue==0){
        ymove1=0;
        ymove2=0;
          text9.text="0";

    if((y1.x==24)&&(y1.y==228)){
        y1curposition=2;
    }
    else if((y1.x==24)&&(y1.y==296)){
        y1curposition=3;
    }
    else if((y1.x==92)&&(y1.y==296)){
        y1curposition=4;
    }
    else if((y1.x==160)&&(y1.y==296)){
        y1curposition=5;
    }
    else if((y1.x==228)&&(y1.y==296)){
        y1curposition=6;
    }
    else if((y1.x==296)&&(y1.y==296)){
        y1curposition=7;
    }
    else if((y1.x==296)&&(y1.y==228)){
        y1curposition=8;
    }
    else if((y1.x==296)&&(y1.y==160)){
        y1curposition=9;
    }
    else if((y1.x==296)&&(y1.y==92)){
        y1curposition=10;
    }
    else if((y1.x==296)&&(y1.y==24)){
        y1curposition=11;
    }
    else if((y1.x==228)&&(y1.y==24)){
        y1curposition=12;
    }
    else if((y1.x==160)&&(y1.y==24)){
        y1curposition=13;
    }
    else if((y1.x==92)&&(y1.y==24)){
        y1curposition=14;
    }
    else if((y1.x==24)&&(y1.y==24)){
        y1curposition=15;
    }
    else if((y1.x==24)&&(y1.y==92)){
        y1curposition=16;
    }
    else if((y1.x==92)&&(y1.y==92)){
        y1curposition=17;
    }
    else if((y1.x==160)&&(y1.y==92)){
        y1curposition=18;
    }
    else if((y1.x==228)&&(y1.y==92)){
        y1curposition=19;
    }
    else if((y1.x==228)&&(y1.y==160)){
        y1curposition=20;
    }
    else if((y1.x==228)&&(y1.y==228)){
        y1curposition=21;
    }
    else if((y1.x==160)&&(y1.y==228)){
        y1curposition=22;
    }
    else if((y1.x==92)&&(y1.y==228)){
        y1curposition=23;
    }
    else if((y1.x==92)&&(y1.y==160)){
        y1curposition=24;
    }
    else if((y1.x==160)&&(y1.y==160)){
        y1curposition=25;
    }
    console.log("g1curposition"+g1curposition)
    console.log("g2curposition"+g2curposition)
    console.log("g3curposition"+g3curposition)
    console.log("g4curposition"+g4curposition)
    console.log("b1curposition"+b1curposition)
    console.log("b2curposition"+b2curposition)
    console.log("b3curposition"+b3curposition)
    console.log("b4curposition"+b4curposition)
    console.log("r1curposition"+r1curposition)
    console.log("r2curposition"+r2curposition)
    console.log("r3curposition"+r3curposition)
    console.log("r4curposition"+r4curposition)
    console.log("y1curposition"+y1curposition)
    console.log("y2curposition"+y2curposition)
    console.log("y3curposition"+y3curposition)
    console.log("y4curposition"+y4curposition)
        ykillcheck(y1);

    }
    }}}

function moveyellow2(){
   //console.log("moveblue1 called")
    if(moveconsent==1){
        //console.log("moveconsent"+moveconsent)
    if(yfinalmovevalue){
       // console.log("1st cond is true")
            if((y2.x==48)&&(y2.y>=160)&&(ymovedirection[2]==0))
            {

                y2.y=y2.y+2;
                if(y2.y==296){
                    ymovedirection[2]=1
                }
            }

            else if((ymovedirection[2]==1)&&(y2.x<=320)){
                y2.x=y2.x+2;
                if(y2.x==320){
                    ymovedirection[2]=2
                }
            }

            else if((ymovedirection[2]==2)&&(y2.y>=24)){
                y2.y=y2.y-2;
                if(y2.y==24){
                    ymovedirection[2]=3
                }
            }

            else if((ymovedirection[2]==3)&&(y2.x>=48)){
                y2.x=y2.x-2
                if(y2.x==48){
                    ymovedirection[2]=4;
                }
            }

            else if((ymovedirection[2]==4)&&(y2.y<=92)){

                    y2.y=y2.y+2

                  if(y2.y==92){

                ymovedirection[2]=5}
            }
            else if((ymovedirection[2]==5)&&(y2.x<=252)){

                 y2.x=y2.x+2;
                  if(y2.x==252){
                    ymovedirection[2]=6;
                }
            }
            else if((ymovedirection[2]==6)&&(y2.y<=228)){
                y2.y=y2.y+2;
                if(y2.y==228){
                    ymovedirection[2]=7;
                }
            }
            else if((ymovedirection[2]==7)&&(y2.x>=116)){
                    y2.x=y2.x-2;
                if(y2.x==116){
                    ymovedirection[2]=8;
                }
        }
            else if((ymovedirection[2]==8)&&(y2.y>=160)){
                    y2.y=y2.y-2;
                if(y2.y==160){
                ymovedirection[2]=9;
                    console.log("gmovedirection[1]=9")
                }
            }
            else if((ymovedirection[2]==9)&&(y2.x<=184)){

                y2.x=y2.x+2;
                if(y2.x==160){
                  //  bfinalmovevalue[1]=0;
                }


            }
            yfinalmovevalue=yfinalmovevalue-2;


    if(yfinalmovevalue==0){
        ymove1=0;
        ymove2=0;
               text9.text="0";

    if((y2.x==48)&&(y2.y==228)){
        y2curposition=2;
    }
    else if((y2.x==48)&&(y2.y==296)){
        y2curposition=3;
    }
    else if((y2.x==116)&&(y2.y==296)){
        y2curposition=4;
    }
    else if((y2.x==184)&&(y2.y==296)){
        y2curposition=5;
    }
    else if((y2.x==252)&&(y2.y==296)){
        y2curposition=6;
    }
    else if((y2.x==320)&&(y2.y==296)){
        y2curposition=7;
    }
    else if((y2.x==320)&&(y2.y==228)){
        y2curposition=8;
    }
    else if((y2.x==320)&&(y2.y==160)){
        y2curposition=9;
    }
    else if((y2.x==320)&&(y2.y==92)){
        y2curposition=10;
    }
    else if((y2.x==320)&&(y2.y==24)){
        y2curposition=11;
    }
    else if((y2.x==252)&&(y2.y==24)){
        y2curposition=12;
    }
    else if((y2.x==184)&&(y2.y==24)){
        y2curposition=13;
    }
    else if((y2.x==116)&&(y2.y==24)){
        y2curposition=14;
    }
    else if((y2.x==48)&&(y2.y==24)){
        y2curposition=15;
    }
    else if((y2.x==48)&&(y2.y==92)){
        y2curposition=16;
    }
    else if((y2.x==116)&&(y2.y==92)){
        y2curposition=17;
    }
    else if((y2.x==184)&&(y2.y==92)){
        y2curposition=18;
    }
    else if((y2.x==252)&&(y2.y==92)){
        y2curposition=19;
    }
    else if((y2.x==252)&&(y2.y==160)){
        y2curposition=20;
    }
    else if((y2.x==252)&&(y2.y==228)){
        y2curposition=21;
    }
    else if((y2.x==184)&&(y2.y==228)){
        y2curposition=22;
    }
    else if((y2.x==116)&&(y2.y==228)){
        y2curposition=23;
    }
    else if((y2.x==116)&&(y2.y==160)){
        y2curposition=24;
    }
    else if((y2.x==184)&&(y2.y==160)){
        y2curposition=25;
    }
    console.log("g1curposition"+g1curposition)
    console.log("g2curposition"+g2curposition)
    console.log("g3curposition"+g3curposition)
    console.log("g4curposition"+g4curposition)
    console.log("b1curposition"+b1curposition)
    console.log("b2curposition"+b2curposition)
    console.log("b3curposition"+b3curposition)
    console.log("b4curposition"+b4curposition)
    console.log("r1curposition"+r1curposition)
    console.log("r2curposition"+r2curposition)
    console.log("r3curposition"+r3curposition)
    console.log("r4curposition"+r4curposition)
    console.log("y1curposition"+y1curposition)
    console.log("y2curposition"+y2curposition)
    console.log("y3curposition"+y3curposition)
    console.log("y4curposition"+y4curposition)
        ykillcheck(y2);

    }
    }}}


function moveyellow3(){
   //console.log("moveblue1 called")
    if(moveconsent==1){
        //console.log("moveconsent"+moveconsent)
    if(yfinalmovevalue){
       // console.log("1st cond is true")
            if((y3.x==48)&&(y3.y>=184)&&(ymovedirection[3]==0))
            {

                y3.y=y3.y+2;
                if(y3.y==320){
                    ymovedirection[3]=1
                }
            }

            else if((ymovedirection[3]==1)&&(y3.x<=320)){
                y3.x=y3.x+2;
                if(y3.x==320){
                    ymovedirection[3]=2
                }
            }

            else if((ymovedirection[3]==2)&&(y3.y>=48)){
                y3.y=y3.y-2;
                if(y3.y==48){
                    ymovedirection[3]=3
                }
            }

            else if((ymovedirection[3]==3)&&(y3.x>=48)){
                y3.x=y3.x-2
                if(y3.x==48){
                    ymovedirection[3]=4;
                }
            }

            else if((ymovedirection[3]==4)&&(y3.y<=116)){

                    y3.y=y3.y+2

                  if(y3.y==116){

                ymovedirection[3]=5}
            }
            else if((ymovedirection[3]==5)&&(y3.x<=252)){

                 y3.x=y3.x+2;
                  if(y3.x==252){
                    ymovedirection[3]=6;
                }
            }
            else if((ymovedirection[3]==6)&&(y3.y<=252)){
                y3.y=y3.y+2;
                if(y3.y==252){
                    ymovedirection[3]=7;
                }
            }
            else if((ymovedirection[3]==7)&&(y3.x>=116)){
                    y3.x=y3.x-2;
                if(y3.x==116){
                    ymovedirection[3]=8;
                }
        }
            else if((ymovedirection[3]==8)&&(y3.y>=184)){
                    y3.y=y3.y-2;
                if(y3.y==184){
                ymovedirection[3]=9;
                    console.log("gmovedirection[1]=9")
                }
            }
            else if((ymovedirection[3]==9)&&(y3.x<=184)){

                y3.x=y3.x+2;
                if(y3.x==184){
                  //  bfinalmovevalue[1]=0;
                }


            }
            yfinalmovevalue=yfinalmovevalue-2;


    if(yfinalmovevalue==0){
        ymove1=0;
        ymove2=0;
          text9.text="0";

    if((y3.x==48)&&(y3.y==252)){
        y3curposition=2;
    }
    else if((y3.x==48)&&(y3.y==320)){
        y3curposition=3;
    }
    else if((y3.x==116)&&(y3.y==320)){
        y3curposition=4;
    }
    else if((y3.x==184)&&(y3.y==320)){
        y3curposition=5;
    }
    else if((y3.x==252)&&(y3.y==320)){
        y3curposition=6;
    }
    else if((y3.x==320)&&(y3.y==320)){
        y3curposition=7;
    }
    else if((y3.x==320)&&(y3.y==252)){
        y3curposition=8;
    }
    else if((y3.x==320)&&(y3.y==184)){
        y3curposition=9;
    }
    else if((y3.x==320)&&(y3.y==116)){
        y3curposition=10;
    }
    else if((y3.x==320)&&(y3.y==48)){
        y3curposition=11;
    }
    else if((y3.x==252)&&(y3.y==48)){
        y3curposition=12;
    }
    else if((y3.x==184)&&(y3.y==48)){
        y3curposition=13;
    }
    else if((y3.x==116)&&(y3.y==48)){
        y3curposition=14;
    }
    else if((y3.x==48)&&(y3.y==48)){
        y3curposition=15;
    }
    else if((y3.x==48)&&(y3.y==116)){
        y3curposition=16;
    }
    else if((y3.x==116)&&(y3.y==116)){
        y3curposition=17;
    }
    else if((y3.x==184)&&(y3.y==116)){
        y3curposition=18;
    }
    else if((y3.x==252)&&(y3.y==116)){
        y3curposition=19;
    }
    else if((y3.x==252)&&(y3.y==184)){
        y3curposition=20;
    }
    else if((y3.x==252)&&(y3.y==252)){
        y3curposition=21;
    }
    else if((y3.x==184)&&(y3.y==252)){
        y3curposition=22;
    }
    else if((y3.x==116)&&(y3.y==252)){
        y3curposition=23;
    }
    else if((y3.x==116)&&(y3.y==184)){
        y3curposition=24;
    }
    else if((y3.x==184)&&(y3.y==184)){
        y3curposition=25;
    }
    console.log("g1curposition"+g1curposition)
    console.log("g2curposition"+g2curposition)
    console.log("g3curposition"+g3curposition)
    console.log("g4curposition"+g4curposition)
    console.log("b1curposition"+b1curposition)
    console.log("b2curposition"+b2curposition)
    console.log("b3curposition"+b3curposition)
    console.log("b4curposition"+b4curposition)
    console.log("r1curposition"+r1curposition)
    console.log("r2curposition"+r2curposition)
    console.log("r3curposition"+r3curposition)
    console.log("r4curposition"+r4curposition)
    console.log("y1curposition"+y1curposition)
    console.log("y2curposition"+y2curposition)
    console.log("y3curposition"+y3curposition)
    console.log("y4curposition"+y4curposition)
        ykillcheck(y3);

    }
    }}}

function moveyellow4(){
   //console.log("moveblue1 called")
    if(moveconsent==1){
        //console.log("moveconsent"+moveconsent)
    if(yfinalmovevalue){
       // console.log("1st cond is true")
            if((y4.x==24)&&(y4.y>=184)&&(ymovedirection[4]==0))
            {

                y4.y=y4.y+2;
                if(y4.y==320){
                    ymovedirection[4]=1
                }
            }

            else if((ymovedirection[4]==1)&&(y4.x<=296)){
                y4.x=y4.x+2;
                if(y4.x==296){
                    ymovedirection[4]=2
                }
            }

            else if((ymovedirection[4]==2)&&(y4.y>=48)){
                y4.y=y4.y-2;
                if(y4.y==48){
                    ymovedirection[4]=3
                }
            }

            else if((ymovedirection[4]==3)&&(y4.x>=24)){
                y4.x=y4.x-2
                if(y4.x==24){
                    ymovedirection[4]=4;
                }
            }

            else if((ymovedirection[4]==4)&&(y4.y<=116)){

                    y4.y=y4.y+2

                  if(y4.y==116){

                ymovedirection[4]=5}
            }
            else if((ymovedirection[4]==5)&&(y4.x<=228)){

                 y4.x=y4.x+2;
                  if(y4.x==228){
                    ymovedirection[4]=6;
                }
            }
            else if((ymovedirection[4]==6)&&(y4.y<=252)){
                y4.y=y4.y+2;
                if(y4.y==252){
                    ymovedirection[4]=7;
                }
            }
            else if((ymovedirection[4]==7)&&(y4.x>=92)){
                    y4.x=y4.x-2;
                if(y4.x==92){
                    ymovedirection[4]=8;
                }
        }
            else if((ymovedirection[4]==8)&&(y4.y>=184)){
                    y4.y=y4.y-2;
                if(y4.y==184){
                ymovedirection[4]=9;
                    console.log("gmovedirection[1]=9")
                }
            }
            else if((ymovedirection[4]==9)&&(y4.x<=160)){

                y4.x=y4.x+2;
                if(y4.x==160){
                  //  bfinalmovevalue[1]=0;
                }


            }
            yfinalmovevalue=yfinalmovevalue-2;


    if(yfinalmovevalue==0){
        ymove1=0;
        ymove2=0;
             text9.text="0";

    if((y4.x==24)&&(y4.y==252)){
        y4curposition=2;
    }
    else if((y4.x==24)&&(y4.y==320)){
        y4curposition=3;
    }
    else if((y4.x==92)&&(y4.y==320)){
        y4curposition=4;
    }
    else if((y4.x==160)&&(y4.y==320)){
        y4curposition=5;
    }
    else if((y4.x==228)&&(y4.y==320)){
        y4curposition=6;
    }
    else if((y4.x==296)&&(y4.y==320)){
        y4curposition=7;
    }
    else if((y4.x==296)&&(y4.y==252)){
        y4curposition=8;
    }
    else if((y4.x==296)&&(y4.y==184)){
        y4curposition=9;
    }
    else if((y4.x==296)&&(y4.y==116)){
        y4curposition=10;
    }
    else if((y4.x==296)&&(y4.y==48)){
        y4curposition=11;
    }
    else if((y4.x==228)&&(y4.y==48)){
        y4curposition=12;
    }
    else if((y4.x==160)&&(y4.y==48)){
        y4curposition=13;
    }
    else if((y4.x==92)&&(y4.y==48)){
        y4curposition=14;
    }
    else if((y4.x==24)&&(y4.y==48)){
        y4curposition=15;
    }
    else if((y4.x==24)&&(y4.y==116)){
        y4curposition=16;
    }
    else if((y4.x==92)&&(y4.y==116)){
        y4curposition=17;
    }
    else if((y4.x==160)&&(y4.y==116)){
        y4curposition=18;
    }
    else if((y4.x==228)&&(y4.y==116)){
        y4curposition=19;
    }
    else if((y4.x==228)&&(y4.y==184)){
        y4curposition=20;
    }
    else if((y4.x==228)&&(y4.y==252)){
        y4curposition=21;
    }
    else if((y4.x==160)&&(y4.y==252)){
        y4curposition=22;
    }
    else if((y4.x==92)&&(y4.y==252)){
        y4curposition=23;
    }
    else if((y4.x==92)&&(y4.y==184)){
        y4curposition=24;
    }
    else if((y4.x==160)&&(y4.y==184)){
        y4curposition=25;
    }
    console.log("g1curposition"+g1curposition)
    console.log("g2curposition"+g2curposition)
    console.log("g3curposition"+g3curposition)
    console.log("g4curposition"+g4curposition)
    console.log("b1curposition"+b1curposition)
    console.log("b2curposition"+b2curposition)
    console.log("b3curposition"+b3curposition)
    console.log("b4curposition"+b4curposition)
    console.log("r1curposition"+r1curposition)
    console.log("r2curposition"+r2curposition)
    console.log("r3curposition"+r3curposition)
    console.log("r4curposition"+r4curposition)
    console.log("y1curposition"+y1curposition)
    console.log("y2curposition"+y2curposition)
    console.log("y3curposition"+y3curposition)
    console.log("y4curposition"+y4curposition)
        ykillcheck(y4);

    }
    }}}

function movedecide(){
    dice=rolldice();
    movevalue=(dice*68)
    console.log(movevalue)
    return movevalue;

}
function rolldice() {
    if(b==0)
{
        console.log("\nfunction rollDice():Number \nGenerate random number from 0-4, if generatedNumber == 0 then consider it as 8");
        var value = (Math.random()*4);
        //console.log("Dice rolled: " + value);

        if (value < 0.2) {
                value = 4;
        }
        else if (value >= 0.2 && value < 1) {
            value = Math.random()*2 + 1;
            //console.log("Dice rolled Again: " + value);
        }
        else if (value > 3.7) {
            value = 8;
        }
        dicevalue = Math.floor(value);
        console.log("diceValue: " + dicevalue);
        console.log("Player" +t+ "'s turn");
        if(dicevalue==1){
            rect1.state="cowrie1"
            treturn.running=true
        }
        else if(dicevalue==2){
            rect1.state="cowrie2"
            treturn.running=true
        }
        else if(dicevalue==3){
            rect1.state="cowrie3"
            treturn.running=true
        }
        else if(dicevalue==4){
            rect1.state="cowrie4"
            treturn.running=true
        }
        else if(dicevalue==8){
            rect1.state="cowrie8"
            treturn.running=true
        }

       /* if((dicevalue==4)||(dicevalue==8))
        {

            specialmove(dicevalue);
        }
        else{
        if(t==1)
        {
       gfinalmovevalue=(dicevalue*68);
        }
        if(t==2)
        {
        bfinalmovevalue=(dicevalue*68);
        }
        if(t==3)
        {
       rfinalmovevalue=(dicevalue*68);
        }
        if(t==4)
        {
        yfinalmovevalue=(dicevalue*68);

        }
        moveconsent=0;
        displaycowrie(dicevalue);*/
        return;
 }
    else if(b>0){
    value = (Math.random()*4);
            //console.log("Dice rolled: " + value);

            if (value < 0.2) {
                    value = 4;
            }
            else if (value >= 0.2 && value < 1) {
                value = Math.random()*2 + 1;
                //console.log("Dice rolled Again: " + value);
            }
            else if (value > 3.7) {
                value = 8;
            }
            dicevalue = Math.floor(value);
            //specialmove(dicevalue)
            if(dicevalue==1){
                rect1.state="cowrie1"
                treturn.running=true
            }
            else if(dicevalue==2){
                rect1.state="cowrie2"
                treturn.running=true
            }
            else if(dicevalue==3){
                rect1.state="cowrie3"
                treturn.running=true
            }
            else if(dicevalue==4){
                rect1.state="cowrie4"
                treturn.running=true
            }
            else if(dicevalue==8){
                rect1.state="cowrie8"
                treturn.running=true
            }

}}
function aftercowrie(dicevalue){
     image1.z=-50;
    if(b>0){

        specialmove(dicevalue)
    }
    else if(b==0){

        if((dicevalue==4)||(dicevalue==8))
        {

            specialmove(dicevalue);
        }
        else{
        if(t==1)
        {
            text6.color="#719500"
            text6.text=n1
            greenturn.opacity=1;
            blueturn.opacity=0;
            redturn.opacity=0;
            yellowturn.opacity=0;
       gfinalmovevalue=(dicevalue*68);
        }
        if(t==2)
        {
            text6.color="#0059BA"
            text6.text=n2
            blueturn.opacity=1;
            redturn.opacity=0;
            greenturn.opacity=0;
            yellowturn.opacity=0;
        bfinalmovevalue=(dicevalue*68);
        }
        if(t==3)
        {
            text6.color="#F6121B"
            text6.text=n3
            redturn.opacity=1;
            blueturn.opacity=0;
            greenturn.opacity=0;
            yellowturn.opacity=0;
       rfinalmovevalue=(dicevalue*68);
        }
        if(t==4)
        {
            text6.color="#FEE000"
            text6.text=n4
            yellowturn.opacity=1;
            redturn.opacity=0;
            blueturn.opacity=0;
            greenturn.opacity=0;
            diceclick.enabled=true;
        yfinalmovevalue=(dicevalue*68);

        }
        moveconsent=0;

        return;
    }
}
}
function turnchange(){
    if((gwin==1)&&(bwin==1)&&(rwin==1)){
        lost.opacity=1;
        tlost.running=true;
        console.log("########## yellow lost ##########")
        console.log("review request")
        console.log("menu should move in")
    }
   else  if((ywin==1)&&(bwin==1)&&(rwin==1)){
        lost.opacity=1;
        tlost.running=true;
        console.log("########## green lost ##########")
        console.log("review request")
        console.log("menu should move in")
    }
    else  if((gwin==1)&&(ywin==1)&&(rwin==1)){
        lost.opacity=1;
        tlost.running=true;
        console.log("########## blue lost ##########")
        console.log("review request")
        console.log("menu should move in")
    }
   else if((gwin==1)&&(bwin==1)){
        if(t==1){
            t=3;
            text6.color="#F6121B"
            text6.text=n3
            redturn.opacity=1;
            blueturn.opacity=0;
            greenturn.opacity=0;
            yellowturn.opacity=0;
            diceclick.enabled=true;
             console.log("turn"+t)
        }
        else if(t==2){

                t=3;
                text6.color="#F6121B"
                text6.text=n3
                redturn.opacity=1;
                blueturn.opacity=0;
                greenturn.opacity=0;
                yellowturn.opacity=0;
                diceclick.enabled=true;
                 console.log("turn"+t)

        }
        else if(t==3){
            t=4;
            text6.color="#FEE000"
            text6.text=n4
            yellowturn.opacity=1;
            redturn.opacity=0;
            blueturn.opacity=0;
            greenturn.opacity=0;
            diceclick.enabled=true;
             console.log("turn"+t)
        }
        else if(t==4){
            t=3;
            text6.color="#F6121B"
            text6.text=n3
            redturn.opacity=1;
            blueturn.opacity=0;
            greenturn.opacity=0;
            yellowturn.opacity=0;
            diceclick.enabled=true;
             console.log("turn"+t)
        }
    }
    else if((gwin==1)&&(rwin==1)){
        if(t==1){
            t=2;
            text6.color="#0059BA"
            text6.text=n2
            blueturn.opacity=1;
            redturn.opacity=0;
            greenturn.opacity=0;
            yellowturn.opacity=0;
            diceclick.enabled=true;
            console.log("turn"+t)
        }
        else if(t==2){
            t=4;
            text6.color="#FEE000"
            text6.text=n4
            yellowturn.opacity=1;
            redturn.opacity=0;
            blueturn.opacity=0;
            greenturn.opacity=0;
            diceclick.enabled=true;
             console.log("turn"+t)
        }
        else if(t==3){
            t=4;
            text6.color="#FEE000"
            text6.text=n4
            yellowturn.opacity=1;
            redturn.opacity=0;
            blueturn.opacity=0;
            greenturn.opacity=0;
            diceclick.enabled=true;
             console.log("turn"+t)
        }
        else if(t==4){
            t=2;
            text6.color="#0059BA"
            text6.text=n2
            blueturn.opacity=1;
            redturn.opacity=0;
            greenturn.opacity=0;
            yellowturn.opacity=0;
            diceclick.enabled=true;
            console.log("turn"+t)
        }
    }
    else if((gwin==1)&&(ywin==1)){
        if(t==1){
            t=2;
            text6.color="#0059BA"
            text6.text=n2
            blueturn.opacity=1;
            redturn.opacity=0;
            greenturn.opacity=0;
            yellowturn.opacity=0;
            diceclick.enabled=true;
            console.log("turn"+t)
        }
        else if(t==2){
            t=3;
            text6.color="#F6121B"
            text6.text=n3
            redturn.opacity=1;
            blueturn.opacity=0;
            greenturn.opacity=0;
            yellowturn.opacity=0;
            diceclick.enabled=true;
             console.log("turn"+t)
        }
        else if(t==3){
            t=2;
            text6.color="#0059BA"
            text6.text=n2
            blueturn.opacity=1;
            redturn.opacity=0;
            greenturn.opacity=0;
            yellowturn.opacity=0;
            diceclick.enabled=true;
            console.log("turn"+t)
        }
        else if(t==4){
            t=2;
            text6.color="#0059BA"
            text6.text=n2
            blueturn.opacity=1;
            redturn.opacity=0;
            greenturn.opacity=0;
            yellowturn.opacity=0;
            diceclick.enabled=true;
            console.log("turn"+t)
        }
    }
    else if((bwin==1)&&(rwin==1)){
        if(t==1){
            t=4;
            text6.color="#FEE000"
            text6.text=n4
            yellowturn.opacity=1;
            redturn.opacity=0;
            blueturn.opacity=0;
            greenturn.opacity=0;
            diceclick.enabled=true;
             console.log("turn"+t)
        }
        else if(t==2){
            t=4;
            text6.color="#FEE000"
            text6.text=n4
            yellowturn.opacity=1;
            redturn.opacity=0;
            blueturn.opacity=0;
            greenturn.opacity=0;
            diceclick.enabled=true;
             console.log("turn"+t)
        }
        else if(t==3){
            t=4;
            text6.color="#FEE000"
            text6.text=n4
            yellowturn.opacity=1;
            redturn.opacity=0;
            blueturn.opacity=0;
            greenturn.opacity=0;
            diceclick.enabled=true;
             console.log("turn"+t)
        }
        else if(t==4){
            t=1;
            text6.color="#719500"
            text6.text=n1
            greenturn.opacity=1;
            blueturn.opacity=0;
            redturn.opacity=0;
            yellowturn.opacity=0;
            diceclick.enabled=true;
             console.log("turn"+t)
        }
    }
    else if((bwin==1)&&(ywin==1)){
        if(t==1){
            t=3;
            text6.color="#F6121B"
            text6.text=n3
            redturn.opacity=1;
            blueturn.opacity=0;
            greenturn.opacity=0;
            yellowturn.opacity=0;
            diceclick.enabled=true;
             console.log("turn"+t)
        }
        else if(t==2){
            t=3;
            text6.color="#F6121B"
            text6.text=n3
            redturn.opacity=1;
            blueturn.opacity=0;
            greenturn.opacity=0;
            yellowturn.opacity=0;
            diceclick.enabled=true;
             console.log("turn"+t)
        }
        else if(t==3){
            t=1;
            text6.color="#719500"
            text6.text=n1
            greenturn.opacity=1;
            blueturn.opacity=0;
            redturn.opacity=0;
            yellowturn.opacity=0;
            diceclick.enabled=true;
             console.log("turn"+t)
        }
        else if(t==4){
            t=1;
            text6.color="#719500"
            text6.text=n1
            greenturn.opacity=1;
            blueturn.opacity=0;
            redturn.opacity=0;
            yellowturn.opacity=0;
            diceclick.enabled=true;
             console.log("turn"+t)
        }
    }
    else if((rwin==1)&&(ywin==1)){
        if(t==1){
            t=2;
            text6.color="#0059BA"
            text6.text=n2
            blueturn.opacity=1;
            redturn.opacity=0;
            greenturn.opacity=0;
            yellowturn.opacity=0;
            diceclick.enabled=true;
            console.log("turn"+t)
        }
        else if(t==2){
            t=1;
            text6.color="#719500"
            text6.text=n1
            greenturn.opacity=1;
            blueturn.opacity=0;
            redturn.opacity=0;
            yellowturn.opacity=0;
            diceclick.enabled=true;
             console.log("turn"+t)
        }
        else if(t==3){
            t=1;
            text6.color="#719500"
            text6.text=n1
            greenturn.opacity=1;
            blueturn.opacity=0;
            redturn.opacity=0;
            yellowturn.opacity=0;
            diceclick.enabled=true;
             console.log("turn"+t)
        }
        else if(t==4){
            t=1;
            text6.color="#719500"
            text6.text=n1
            greenturn.opacity=1;
            blueturn.opacity=0;
            redturn.opacity=0;
            yellowturn.opacity=0;
            diceclick.enabled=true;
             console.log("turn"+t)
        }
    }

   else if(gwin==1){
        if(t==1){
            t=2;
            text6.color="#0059BA"
            text6.text=n2
            blueturn.opacity=1;
            redturn.opacity=0;
            greenturn.opacity=0;
            yellowturn.opacity=0;
            diceclick.enabled=true;
            console.log("turn"+t)
        }
        else if(t==2){
            t=3;
            text6.color="#F6121B"
            text6.text=n3
            redturn.opacity=1;
            blueturn.opacity=0;
            greenturn.opacity=0;
            yellowturn.opacity=0;
            diceclick.enabled=true;
             console.log("turn"+t)
        }
        else if(t==3){
            t=4;
            text6.color="#FEE000"
            text6.text=n4
            yellowturn.opacity=1;
            redturn.opacity=0;
            blueturn.opacity=0;
            greenturn.opacity=0;
            diceclick.enabled=true;
             console.log("turn"+t)
        }
        else if(t==4){
            t=2;
            text6.color="#0059BA"
            text6.text=n2
            greenturn.opacity=0;
            blueturn.opacity=1;
            redturn.opacity=0;
            yellowturn.opacity=0;
            diceclick.enabled=true;
             console.log("turn"+t)
        }
    }
    else if(bwin==1){
         if(t==2){
            t=3;
            text6.color="#F6121B"
            text6.text=n3
            redturn.opacity=1;
            blueturn.opacity=0;
            greenturn.opacity=0;
            yellowturn.opacity=0;
            diceclick.enabled=true;
             console.log("turn"+t)
        }


        else if(t==3){
            t=4;
            text6.color="#FEE000"
            text6.text=n4
            yellowturn.opacity=1;
            redturn.opacity=0;
            blueturn.opacity=0;
            greenturn.opacity=0;
            diceclick.enabled=true;
             console.log("turn"+t)
        }
        else if(t==4){
            t=1;
            text6.color="#719500"
            text6.text=n1
            greenturn.opacity=1;
            blueturn.opacity=0;
            redturn.opacity=0;
            yellowturn.opacity=0;
            diceclick.enabled=true;
             console.log("turn"+t)
        }
         else if(t==1){
             t=3;
             text6.color="#F6121B"
             text6.text=n3
             blueturn.opacity=0;
             redturn.opacity=1;
             greenturn.opacity=0;
             yellowturn.opacity=0;
             diceclick.enabled=true;
             console.log("turn"+t)
         }
    }
    else if(rwin==1){
        if(t==1){
            t=2;
            text6.color="#0059BA"
            text6.text=n2
            blueturn.opacity=1;
            redturn.opacity=0;
            greenturn.opacity=0;
            yellowturn.opacity=0;
            diceclick.enabled=true;
            console.log("turn"+t)
        }
        else if(t==2){
            t=4;
            text6.color="#FEE000"
            text6.text=n4
            redturn.opacity=0;
            blueturn.opacity=0;
            greenturn.opacity=0;
            yellowturn.opacity=1;
            diceclick.enabled=true;
             console.log("turn"+t)
        }
        else if(t==3){
            t=4;
            text6.color="#FEE000"
            text6.text=n4
            yellowturn.opacity=1;
            redturn.opacity=0;
            blueturn.opacity=0;
            greenturn.opacity=0;
            diceclick.enabled=true;
             console.log("turn"+t)
        }
        else if(t==4){
            t=1;
            text6.color="#719500"
            text6.text=n1
            greenturn.opacity=1;
            blueturn.opacity=0;
            redturn.opacity=0;
            yellowturn.opacity=0;
            diceclick.enabled=true;
             console.log("turn"+t)
        }
    }
    else if(ywin==1){
        if(t==1){
            t=2;
            text6.color="#0059BA"
            text6.text=n2
            blueturn.opacity=1;
            redturn.opacity=0;
            greenturn.opacity=0;
            yellowturn.opacity=0;
            diceclick.enabled=true;
            console.log("turn"+t)
        }
        else if(t==2){
            t=3;
            text6.color="#F6121B"
            text6.text=n3
            redturn.opacity=1;
            blueturn.opacity=0;
            greenturn.opacity=0;
            yellowturn.opacity=0;
            diceclick.enabled=true;
             console.log("turn"+t)
        }
        else if(t==3){
            t=1;
            text6.color="#719500"
            text6.text=n1
            yellowturn.opacity=0;
            redturn.opacity=0;
            blueturn.opacity=0;
            greenturn.opacity=1;
            diceclick.enabled=true;
             console.log("turn"+t)
        }
        else if(t==4){
            t=1;
            text6.color="#719500"
            text6.text=n1
            greenturn.opacity=1;
            blueturn.opacity=0;
            redturn.opacity=0;
            yellowturn.opacity=0;
            diceclick.enabled=true;
             console.log("turn"+t)
        }
    }
    else{

    if(t==1){
        t=2;
        text6.color="#0059BA"
        text6.text=n2
        blueturn.opacity=1;
        redturn.opacity=0;
        greenturn.opacity=0;
        yellowturn.opacity=0;
        diceclick.enabled=true;
        console.log("turn"+t)
    }
    else if(t==2){
        t=3;
        text6.color="#F6121B"
        text6.text=n3
        redturn.opacity=1;
        blueturn.opacity=0;
        greenturn.opacity=0;
        yellowturn.opacity=0;
        diceclick.enabled=true;
         console.log("turn"+t)
    }
    else if(t==3){
        t=4;
        text6.color="#FEE000"
        text6.text=n4
        yellowturn.opacity=1;
        redturn.opacity=0;
        blueturn.opacity=0;
        greenturn.opacity=0;
        diceclick.enabled=true;
         console.log("turn"+t)
    }
    else if(t==4){
        t=1;
        text6.color="#719500"
        text6.text=n1
        greenturn.opacity=1;
        blueturn.opacity=0;
        redturn.opacity=0;
        yellowturn.opacity=0;
        diceclick.enabled=true;
         console.log("turn"+t)
    }
}
}
function bkillcheck(p){
    if((b1curposition==25)&&(b2curposition==25)&&(b3curposition==25)&&(b4curposition==25)){

        console.log("$$$$$$$$$$ blue survived $$$$$$$$$")
        bwin=1;
        won.opacity=1;
        twon.running=true;
        console.log("you cant play anymore!!!!")
        console.log("changing turn.....")
        //turnchange();

    }

else {if(p==b1){
    if((b1curposition!=5)&&(b1curposition!=9)&&(b1curposition!=13)&&(b1curposition!=25))
            {
        if((b1curposition>=1)&&(b1curposition<=12)){
            bgtest=b1curposition+4;
        }
        else if((b1curposition>=13)&&(b1curposition<=16)){
            bgtest=b1curposition-12;
        }
        else if((b1curposition>=17)&&(b1curposition<=18)){
            bgtest=b1curposition+6;
        }
        else if((b1curposition>=19)&&(b1curposition<=24)){
            bgtest=b1curposition-2;
        }
        if((b1curposition>=1)&&(b1curposition<=4)){
            brtest=b1curposition+12;
        }
        else if((b1curposition>=5)&&(b1curposition<=16)){
            brtest=b1curposition-4;
        }
        else if((b1curposition>=17)&&(b1curposition<=22)){
            brtest=b1curposition+2;
        }
        else if((b1curposition>=23)&&(b1curposition<=24)){
            brtest=b1curposition-6;
        }
        if((b1curposition>=1)&&(b1curposition<=8)){
            bytest=b1curposition+8;
        }
        else if((b1curposition>=9)&&(b1curposition<=16)){
            bytest=b1curposition-8;
        }
        else if((b1curposition>=17)&&(b1curposition<=20)){
            bytest=b1curposition+4;
        }
        else if((b1curposition>=21)&&(b1curposition<=24)){
            bytest=b1curposition-4;
        }

    if(bgtest==g1curposition){

        bkill=bkill+1;
        bkillchance=bkillchance+1;
        kb=1;

    }
    else if(bgtest==g2curposition){

         bkill=bkill+1;
        bkillchance=bkillchance+1;
        kb=2;

    }
    else if(bgtest==g3curposition){

         bkill=bkill+1;
        bkillchance=bkillchance+1;
        kb=3;

    }
    else if(bgtest==g4curposition){

         bkill=bkill+1;
        bkillchance=bkillchance+1;
        kb=4;

    }
   else if(brtest==r1curposition){

        bkill=bkill+1;
        bkillchance=bkillchance+1;
        kb=5;

    }
    else if(brtest==r2curposition){

         bkill=bkill+1;
        bkillchance=bkillchance+1;
        kb=6;

    }
    else if(brtest==r3curposition){

         bkill=bkill+1;
        bkillchance=bkillchance+1;
        kb=7;

    }
    else if(brtest==r4curposition){

         bkill=bkill+1;
        bkillchance=bkillchance+1;
        kb=8;

    }
   else if(bytest==y1curposition){

        bkill=bkill+1;
        bkillchance=bkillchance+1;
        kb=9;

    }
    else if(bytest==y2curposition){

         bkill=bkill+1;
        bkillchance=bkillchance+1;
        kb=10;

    }
    else if(bytest==y3curposition){

         bkill=bkill+1;
        bkillchance=bkillchance+1;
        kb=11;

    }
    else if(bytest==y4curposition){

         bkill=bkill+1;
        bkillchance=bkillchance+1;
        kb=12;

    }
    else{
        bkillchance=0
    }
           }

            else
            {
                bkillchance=0
              }}

if(p==b2){
      if((b2curposition!=5)&&(b2curposition!=9)&&(b2curposition!=13)&&(b2curposition!=25))
      {
          if((b2curposition>=1)&&(b2curposition<=12)){
              bgtest=b2curposition+4;
          }
          else if((b2curposition>=13)&&(b2curposition<=16)){
              bgtest=b2curposition-12;
          }
          else if((b2curposition>=17)&&(b2curposition<=18)){
              bgtest=b2curposition+6;
          }
          else if((b2curposition>=19)&&(b2curposition<=24)){
              bgtest=b2curposition-2;
          }
          if((b2curposition>=1)&&(b2curposition<=4)){
              brtest=b2curposition+12;
          }
          else if((b2curposition>=5)&&(b2curposition<=16)){
              brtest=b2curposition-4;
          }
          else if((b2curposition>=17)&&(b2curposition<=22)){
              brtest=b2curposition+2;
          }
          else if((b2curposition>=23)&&(b2curposition<=24)){
              brtest=b2curposition-6;
          }
          if((b2curposition>=1)&&(b2curposition<=8)){
              bytest=b2curposition+8;
          }
          else if((b2curposition>=9)&&(b2curposition<=16)){
              bytest=b2curposition-8;
          }
          else if((b2curposition>=17)&&(b2curposition<=20)){
              bytest=b2curposition+4;
          }
          else if((b2curposition>=21)&&(b2curposition<=24)){
              bytest=b2curposition-4;
          }

      if(bgtest==g1curposition){

          bkill=bkill+1;
          bkillchance=bkillchance+1;
          kb=1;

      }
      else if(bgtest==g2curposition){

           bkill=bkill+1;
          bkillchance=bkillchance+1;
          kb=2;

      }
      else if(bgtest==g3curposition){

           bkill=bkill+1;
          bkillchance=bkillchance+1;
          kb=3;

      }
      else if(bgtest==g4curposition){

           bkill=bkill+1;
          bkillchance=bkillchance+1;
          kb=4;

      }
     else if(brtest==r1curposition){

          bkill=bkill+1;
          bkillchance=bkillchance+1;
          kb=5;

      }
      else if(brtest==r2curposition){

           bkill=bkill+1;
          bkillchance=bkillchance+1;
          kb=6;

      }
      else if(brtest==r3curposition){

           bkill=bkill+1;
          bkillchance=bkillchance+1;
          kb=7;

      }
      else if(brtest==r4curposition){

           bkill=bkill+1;
          bkillchance=bkillchance+1;
          kb=8;

      }
     else if(bytest==y1curposition){

          bkill=bkill+1;
          bkillchance=bkillchance+1;
          kb=9;

      }
      else if(bytest==y2curposition){

           bkill=bkill+1;
          bkillchance=bkillchance+1;
          kb=10;

      }
      else if(bytest==y3curposition){

           bkill=bkill+1;
          bkillchance=bkillchance+1;
          kb=11;

      }
      else if(bytest==y4curposition){

           bkill=bkill+1;
          bkillchance=bkillchance+1;
          kb=12;

      }
    else{
        bkillchance=0
    }}
     else {
           bkillchance=0
    }}
if(p==b3){
      if((b3curposition!=5)&&(b3curposition!=9)&&(b3curposition!=13)&&(b3curposition!=25)){


          if((b3curposition>=1)&&(b3curposition<=12)){
              bgtest=b3curposition+4;
          }
          else if((b3curposition>=13)&&(b3curposition<=16)){
              bgtest=b3curposition-12;
          }
          else if((b3curposition>=17)&&(b3curposition<=18)){
              bgtest=b3curposition+6;
          }
          else if((b3curposition>=19)&&(b3curposition<=24)){
              bgtest=b3curposition-2;
          }
          if((b3curposition>=1)&&(b3curposition<=4)){
              brtest=b3curposition+12;
          }
          else if((b3curposition>=5)&&(b3curposition<=16)){
              brtest=b3curposition-4;
          }
          else if((b3curposition>=17)&&(b3curposition<=22)){
              brtest=b3curposition+2;
          }
          else if((b3curposition>=23)&&(b3curposition<=24)){
              brtest=b3curposition-6;
          }
          if((b3curposition>=1)&&(b3curposition<=8)){
              bytest=b3curposition+8;
          }
          else if((b3curposition>=9)&&(b3curposition<=16)){
              bytest=b3curposition-8;
          }
          else if((b3curposition>=17)&&(b3curposition<=20)){
              bytest=b3curposition+4;
          }
          else if((b3curposition>=21)&&(b3curposition<=24)){
              bytest=b3curposition-4;
          }

      if(bgtest==g1curposition){

          bkill=bkill+1;
          bkillchance=bkillchance+1;
          kb=1;

      }
      else if(bgtest==g2curposition){

           bkill=bkill+1;
          bkillchance=bkillchance+1;
          kb=2;

      }
      else if(bgtest==g3curposition){

           bkill=bkill+1;
          bkillchance=bkillchance+1;
          kb=3;

      }
      else if(bgtest==g4curposition){

           bkill=bkill+1;
          bkillchance=bkillchance+1;
          kb=4;

      }
     else if(brtest==r1curposition){

          bkill=bkill+1;
          bkillchance=bkillchance+1;
          kb=5;

      }
      else if(brtest==r2curposition){

           bkill=bkill+1;
          bkillchance=bkillchance+1;
          kb=6;

      }
      else if(brtest==r3curposition){

           bkill=bkill+1;
          bkillchance=bkillchance+1;
          kb=7;

      }
      else if(brtest==r4curposition){

           bkill=bkill+1;
          bkillchance=bkillchance+1;
          kb=8;

      }
     else if(bytest==y1curposition){

          bkill=bkill+1;
          bkillchance=bkillchance+1;
          kb=9;

      }
      else if(bytest==y2curposition){

           bkill=bkill+1;
          bkillchance=bkillchance+1;
          kb=10;

      }
      else if(bytest==y3curposition){

           bkill=bkill+1;
          bkillchance=bkillchance+1;
          kb=11;

      }
      else if(bytest==y4curposition){

           bkill=bkill+1;
          bkillchance=bkillchance+1;
          kb=12;

      }}
    else{
        bkillchance=0
    }

      }
if(p==b4){
      if((b4curposition!=5)&&(b4curposition!=9)&&(b4curposition!=13)&&(b4curposition!=25))
      {
          if((b4curposition>=1)&&(b4curposition<=12)){
              bgtest=b4curposition+4;
          }
          else if((b4curposition>=13)&&(b4curposition<=16)){
              bgtest=b4curposition-12;
          }
          else if((b4curposition>=17)&&(b4curposition<=18)){
              bgtest=b4curposition+6;
          }
          else if((b4curposition>=19)&&(b4curposition<=24)){
              bgtest=b4curposition-2;
          }
          if((b4curposition>=1)&&(b4curposition<=4)){
              brtest=b4curposition+12;
          }
          else if((b4curposition>=5)&&(b4curposition<=16)){
              brtest=b4curposition-4;
          }
          else if((b4curposition>=17)&&(b4curposition<=22)){
              brtest=b4curposition+2;
          }
          else if((b4curposition>=23)&&(b4curposition<=24)){
              brtest=b4curposition-6;
          }
          if((b4curposition>=1)&&(b4curposition<=8)){
              bytest=b4curposition+8;
          }
          else if((b4curposition>=9)&&(b4curposition<=16)){
              bytest=b4curposition-8;
          }
          else if((b4curposition>=17)&&(b4curposition<=20)){
              bytest=b4curposition+4;
          }
          else if((b4curposition>=21)&&(b4curposition<=24)){
              bytest=b4curposition-4;
          }

      if(bgtest==g1curposition){

          bkill=bkill+1;
          bkillchance=bkillchance+1;
          kb=1;

      }
      else if(bgtest==g2curposition){

           bkill=bkill+1;
          bkillchance=bkillchance+1;
          kb=2;

      }
      else if(bgtest==g3curposition){

           bkill=bkill+1;
          bkillchance=bkillchance+1;
          kb=3;

      }
      else if(bgtest==g4curposition){

           bkill=bkill+1;
          bkillchance=bkillchance+1;
          kb=4;

      }
     else if(brtest==r1curposition){

          bkill=bkill+1;
          bkillchance=bkillchance+1;
          kb=5;

      }
      else if(brtest==r2curposition){

           bkill=bkill+1;
          bkillchance=bkillchance+1;
          kb=6;

      }
      else if(brtest==r3curposition){

           bkill=bkill+1;
          bkillchance=bkillchance+1;
          kb=7;

      }
      else if(brtest==r4curposition){

           bkill=bkill+1;
          bkillchance=bkillchance+1;
          kb=8;

      }
     else if(bytest==y1curposition){

          bkill=bkill+1;
          bkillchance=bkillchance+1;
          kb=9;

      }
      else if(bytest==y2curposition){

           bkill=bkill+1;
          bkillchance=bkillchance+1;
          kb=10;

      }
      else if(bytest==y3curposition){

           bkill=bkill+1;
          bkillchance=bkillchance+1;
          kb=11;

      }
      else if(bytest==y4curposition){

           bkill=bkill+1;
          bkillchance=bkillchance+1;
          kb=12;

      }
    else{
        bkillchance=0
    }
   }
else {
    bkillchance=0;

    }}
if((b==0)&&(bkillchance==0)&&(killchance==0))
{
turnchange();
}
console.log("bkillchance"+bkillchance)
console.log("killchance"+killchance)
if(check==0){
    console.log("executing check==0")
    if((bkillchance!=0)){
    diceclick.enabled=true;
    mousearea1.enabled=false;
    extrachance.opacity=1;
    }
}

if(check==1){
    console.log("executing check==1")
if(bkillchance>0){
 killchance=killchance+1}
tdelay.running=true;

}
if(kb==1){
    console.log("killing g1")
    kb=0;
    g1.x=166
    g1.y=290
    g1curposition=1;
    gmovedirection[1]=0
    bkillchance=bkillchance-1;

}
else if(kb==2){
    console.log("killing g2")
    kb=0;
    g2.x=198
    g2.y=300
    g2curposition=1;
    gmovedirection[2]=0
     bkillchance=bkillchance-1;

}
else if(kb==3){
    console.log("killing g3")
    kb=0;
    g3.x=184
    g3.y=328
    g3curposition=1;
    gmovedirection[3]=0
     bkillchance=bkillchance-1;

}
else if(kb==4){
    console.log("killing g4")
    kb=0;
    g4.x=150
    g4.y=320
    g4curposition=1;
    gmovedirection[4]=0
     bkillchance=bkillchance-1;

}
else if(kb==5){
    console.log("killing r1")
    kb=0;
    r1.x=174
    r1.y=16
    r1curposition=1;
    rmovedirection[1]=0
     bkillchance=bkillchance-1;

}
else if(kb==6){
    console.log("killing r2")
    kb=0;
    r2.x=188
    r2.y=30
    r2curposition=1;
    rmovedirection[2]=0
     bkillchance=bkillchance-1;

}
else if(kb==7){
    console.log("killing r3")
    kb=0;
    r3.x=174
    r3.y=42
    r3curposition=1;
    rmovedirection[3]=0
     bkillchance=bkillchance-1;

}
else if(kb==8){
    console.log("killing r4")
    kb=0;
    r4.x=160
    r4.y=30
    r4curposition=1;
    rmovedirection[4]=0
     bkillchance=bkillchance-1;

}
else if(kb==9){
    console.log("killing y1")
    kb=0;
    y1.x=24
    y1.y=160
    y1curposition=1;
    ymovedirection[1]=0
     bkillchance=bkillchance-1;

}
else if(kb==10){
    console.log("killing y2")
    kb=0;
    y2.x=48
    y2.y=160
    y2curposition=1;
    ymovedirection[2]=0
     bkillchance=bkillchance-1;

}
else if(kb==11){
    console.log("killing y3")
    kb=0;
    y3.x=48
    y3.y=184
    y3curposition=1;
    ymovedirection[3]=0
     bkillchance=bkillchance-1;

}
else if(kb==12){
    console.log("killing y4")
    kb=0;
    y4.x=24
    y4.y=184
    y4curposition=1;
    ymovedirection[4]=0
     bkillchance=bkillchance-1;

}
}
}
function gkillcheck(q){
    if((g1curposition==25)&&(g2curposition==25)&&(g3curposition==25)&&(g4curposition==25)){

        console.log("$$$$$$$$$$ green survived $$$$$$$$$")
        gwin=1;
        won.opacity=1;
        twon.running=true;
        console.log("you cant play anymore!!!!")
        console.log("changing turn.....")
        //turnchange();

    }
 else {if(q==g1){
   if((g1curposition!=5)&&(g1curposition!=9)&&(g1curposition!=13)&&(g1curposition!=25))
      {
       if((g1curposition>=1)&&(g1curposition<=4)){
           gbtest=g1curposition+12
       }
       else if((g1curposition>=5)&&(g1curposition<=16)){
           gbtest=g1curposition-4
       }
       else if((g1curposition>=17)&&(g1curposition<=22)){
           gbtest=g1curposition+2
       }
       else if((g1curposition>=23)&&(g1curposition<=24)){
           gbtest=g1curposition-6
       }
       if((g1curposition>=1)&&(g1curposition<=8)){
           grtest=g1curposition+8
       }
       else if((g1curposition>=9)&&(g1curposition<=16)){
           grtest=g1curposition-8
       }
       else if((g1curposition>=17)&&(g1curposition<=20)){
           grtest=g1curposition+4
       }
       else if((g1curposition>=21)&&(g1curposition<=24)){
           grtest=g1curposition-4
       }
       if((g1curposition>=1)&&(g1curposition<=12)){
           gytest=g1curposition+4
       }
       else if((g1curposition>=13)&&(g1curposition<=16)){
           gytest=g1curposition-12
       }
       else if((g1curposition>=17)&&(g1curposition<=18)){
           gytest=g1curposition+6
       }
       else if((g1curposition>=19)&&(g1curposition<=24)){
           gytest=g1curposition-2
       }
       console.log("gbtest="+gbtest)
       console.log("grtest="+grtest)
       console.log("gytest="+gytest)
       console.log(g1curposition)
       console.log(g2curposition)
       console.log(g3curposition)
       console.log(g4curposition)
       console.log(r1curposition)
       console.log(r2curposition)
       console.log(r3curposition)
       console.log(r4curposition)
       console.log(b1curposition)
       console.log(b2curposition)
       console.log(b3curposition)
       console.log(b4curposition)
       console.log(y1curposition)
       console.log(y2curposition)
       console.log(y3curposition)
       console.log(y4curposition)
 if(grtest==r1curposition){
  gkill=gkill+1;
     nkillchance=nkillchance+1
     kg=5;
 }
 else if(grtest==r2curposition){
     gkill=gkill+1;
        nkillchance=nkillchance+1
        kg=6;
    }
 else if(grtest==r3curposition){
     gkill=gkill+1;
        nkillchance=nkillchance+1
        kg=7;
    }
 else if(grtest==r4curposition){
     gkill=gkill+1;
        nkillchance=nkillchance+1
        kg=8;
    }
 else if(gytest==y1curposition){
     gkill=gkill+1;
        nkillchance=nkillchance+1
        kg=9;
    }
 else if(gytest==y2curposition){
     gkill=gkill+1;
        nkillchance=nkillchance+1
        kg=10;
    }
 else if(gytest==y3curposition){
     gkill=gkill+1;
        nkillchance=nkillchance+1
        kg=11;
    }
 else if(gytest==y4curposition){
  gkill=gkill+1;
     nkillchance=nkillchance+1
     kg=12;
 }
  else if(gbtest==b1curposition){
     gkill=gkill+1;
        nkillchance=nkillchance+1
        kg=1;
    }
 else if(gbtest==b2curposition){
     gkill=gkill+1;
        nkillchance=nkillchance+1
        kg=2;
    }
 else if(gbtest==b3curposition){
  gkill=gkill+1;
     nkillchance=nkillchance+1
     kg=3;
 }
 else if(gbtest==b4curposition){
     gkill=gkill+1;
        nkillchance=nkillchance+1
        kg=4;
    }
     else{
         nkillchance=0
 }}
 else {
      nkillchance=0
 }}
 if(q==g2){
     if((g2curposition!=5)&&(g2curposition!=9)&&(g2curposition!=13)&&(g2curposition!=25))
     {

          if((g2curposition>=1)&&(g2curposition<=4)){
              gbtest=g2curposition+12
          }
          else if((g2curposition>=5)&&(g2curposition<=16)){
              gbtest=g2curposition-4
          }
          else if((g2curposition>=17)&&(g2curposition<=22)){
              gbtest=g2curposition+2
          }
          else if((g2curposition>=23)&&(g2curposition<=24)){
              gbtest=g2curposition-6
          }
          if((g2curposition>=1)&&(g2curposition<=8)){
              grtest=g2curposition+8
          }
          else if((g2curposition>=9)&&(g2curposition<=16)){
              grtest=g2curposition-8
          }
          else if((g2curposition>=17)&&(g2curposition<=20)){
              grtest=g2curposition+4
          }
          else if((g2curposition>=21)&&(g2curposition<=24)){
              grtest=g2curposition-4
          }
          if((g2curposition>=1)&&(g2curposition<=12)){
              gytest=g2curposition+4
          }
          else if((g2curposition>=13)&&(g2curposition<=16)){
              gytest=g2curposition-12
          }
          else if((g2curposition>=17)&&(g2curposition<=18)){
              gytest=g2curposition+6
          }
          else if((g2curposition>=19)&&(g2curposition<=24)){
              gytest=g2curposition-2
          }
          console.log("gbtest="+gbtest)
          console.log("grtest="+grtest)
          console.log("gytest="+gytest)
          console.log(g1curposition)
          console.log(g2curposition)
          console.log(g3curposition)
          console.log(g4curposition)
          console.log(r1curposition)
          console.log(r2curposition)
          console.log(r3curposition)
          console.log(r4curposition)
          console.log(b1curposition)
          console.log(b2curposition)
          console.log(b3curposition)
          console.log(b4curposition)
          console.log(y1curposition)
          console.log(y2curposition)
          console.log(y3curposition)
          console.log(y4curposition)

    if(grtest==r1curposition){
     gkill=gkill+1;
        nkillchance=nkillchance+1
        kg=5;
    }
    else if(grtest==r2curposition){
        gkill=gkill+1;
           nkillchance=nkillchance+1
           kg=6;
       }
    else if(grtest==r3curposition){
        gkill=gkill+1;
           nkillchance=nkillchance+1
           kg=7;
       }
    else if(grtest==r4curposition){
        gkill=gkill+1;
           nkillchance=nkillchance+1
           kg=8;
       }
    else if(gytest==y1curposition){
        gkill=gkill+1;
           nkillchance=nkillchance+1
           kg=9;
       }
    else if(gytest==y2curposition){
        gkill=gkill+1;
           nkillchance=nkillchance+1
           kg=10;
       }
    else if(gytest==y3curposition){
        gkill=gkill+1;
           nkillchance=nkillchance+1
           kg=11;
       }
    else if(gytest==y4curposition){
     gkill=gkill+1;
        nkillchance=nkillchance+1
        kg=12;
    }
     else if(gbtest==b1curposition){
        gkill=gkill+1;
           nkillchance=nkillchance+1
           kg=1;
       }
    else if(gbtest==b2curposition){
        gkill=gkill+1;
           nkillchance=nkillchance+1
           kg=2;
       }
    else if(gbtest==b3curposition){
     gkill=gkill+1;
        nkillchance=nkillchance+1
        kg=3;
    }
    else if(gbtest==b4curposition){
        gkill=gkill+1;
           nkillchance=nkillchance+1
           kg=4;
       }
        else{
            nkillchance=0
        }
             }
      else {
           nkillchance=0
          }}

 if(q==g3){
     if((g3curposition!=5)&&(g3curposition!=9)&&(g3curposition!=13)&&(g3curposition!=25))
     {
      if((g3curposition>=1)&&(g3curposition<=4)){
          gbtest=g3curposition+12
      }
      else if((g3curposition>=5)&&(g3curposition<=16)){
          gbtest=g3curposition-4
      }
      else if((g3curposition>=17)&&(g3curposition<=22)){
          gbtest=g3curposition+2
      }
      else if((g3curposition>=23)&&(g3curposition<=24)){
          gbtest=g3curposition-6
      }
      if((g3curposition>=1)&&(g3curposition<=8)){
          grtest=g3curposition+8
      }
      else if((g3curposition>=9)&&(g3curposition<=16)){
          grtest=g3curposition-8
      }
      else if((g3curposition>=17)&&(g3curposition<=20)){
          grtest=g3curposition+4
      }
      else if((g3curposition>=21)&&(g3curposition<=24)){
          grtest=g3curposition-4
      }
      if((g3curposition>=1)&&(g3curposition<=12)){
          gytest=g3curposition+4
      }
      else if((g3curposition>=13)&&(g3curposition<=16)){
          gytest=g3curposition-12
      }
      else if((g3curposition>=17)&&(g3curposition<=18)){
          gytest=g3curposition+6
      }
      else if((g3curposition>=19)&&(g3curposition<=24)){
          gytest=g3curposition-2
      }
      console.log("gbtest="+gbtest)
      console.log("grtest="+grtest)
      console.log("gytest="+gytest)
      console.log(g1curposition)
      console.log(g2curposition)
      console.log(g3curposition)
      console.log(g4curposition)
      console.log(r1curposition)
      console.log(r2curposition)
      console.log(r3curposition)
      console.log(r4curposition)
      console.log(b1curposition)
      console.log(b2curposition)
      console.log(b3curposition)
      console.log(b4curposition)
      console.log(y1curposition)
      console.log(y2curposition)
      console.log(y3curposition)
      console.log(y4curposition)
if(grtest==r1curposition){
 gkill=gkill+1;
    nkillchance=nkillchance+1
    kg=5;
}
else if(grtest==r2curposition){
    gkill=gkill+1;
       nkillchance=nkillchance+1
       kg=6;
   }
else if(grtest==r3curposition){
    gkill=gkill+1;
       nkillchance=nkillchance+1
       kg=7;
   }
else if(grtest==r4curposition){
    gkill=gkill+1;
       nkillchance=nkillchance+1
       kg=8;
   }
else if(gytest==y1curposition){
    gkill=gkill+1;
       nkillchance=nkillchance+1
       kg=9;
   }
else if(gytest==y2curposition){
    gkill=gkill+1;
       nkillchance=nkillchance+1
       kg=10;
   }
else if(gytest==y3curposition){
    gkill=gkill+1;
       nkillchance=nkillchance+1
       kg=11;
   }
else if(gytest==y4curposition){
 gkill=gkill+1;
    nkillchance=nkillchance+1
    kg=12;
}
 else if(gbtest==b1curposition){
    gkill=gkill+1;
       nkillchance=nkillchance+1
       kg=1;
   }
else if(gbtest==b2curposition){
    gkill=gkill+1;
       nkillchance=nkillchance+1
       kg=2;
   }
else if(gbtest==b3curposition){
 gkill=gkill+1;
    nkillchance=nkillchance+1
    kg=3;
}
else if(gbtest==b4curposition){
    gkill=gkill+1;
       nkillchance=nkillchance+1
       kg=4;
   }
     else{
         nkillchance=0
     }
 }
     else{
         nkillchance=0
     }
 }

 if(q==g4){
     if((g4curposition!=5)&&(g4curposition!=9)&&(g4curposition!=13)&&(g4curposition!=25))
     {
      if((g4curposition>=1)&&(g4curposition<=4)){
          gbtest=g4curposition+12
      }
      else if((g4curposition>=5)&&(g4curposition<=16)){
          gbtest=g4curposition-4
      }
      else if((g4curposition>=17)&&(g4curposition<=22)){
          gbtest=g4curposition+2
      }
      else if((g4curposition>=23)&&(g4curposition<=24)){
          gbtest=g4curposition-6
      }
      if((g4curposition>=1)&&(g4curposition<=8)){
          grtest=g4curposition+8
      }
      else if((g4curposition>=9)&&(g4curposition<=16)){
          grtest=g4curposition-8
      }
      else if((g4curposition>=17)&&(g4curposition<=20)){
          grtest=g4curposition+4
      }
      else if((g4curposition>=21)&&(g4curposition<=24)){
          grtest=g4curposition-4
      }
      if((g4curposition>=1)&&(g4curposition<=12)){
          gytest=g4curposition+4
      }
      else if((g4curposition>=13)&&(g4curposition<=16)){
          gytest=g4curposition-12
      }
      else if((g4curposition>=17)&&(g4curposition<=18)){
          gytest=g4curposition+6
      }
      else if((g4curposition>=19)&&(g4curposition<=24)){
          gytest=g4curposition-2
      }
      console.log("gbtest="+gbtest)
      console.log("grtest="+grtest)
      console.log("gytest="+gytest)
      console.log(g1curposition)
      console.log(g2curposition)
      console.log(g3curposition)
      console.log(g4curposition)
      console.log(r1curposition)
      console.log(r2curposition)
      console.log(r3curposition)
      console.log(r4curposition)
      console.log(b1curposition)
      console.log(b2curposition)
      console.log(b3curposition)
      console.log(b4curposition)
      console.log(y1curposition)
      console.log(y2curposition)
      console.log(y3curposition)
      console.log(y4curposition)
if(grtest==r1curposition){
 gkill=gkill+1;
    nkillchance=nkillchance+1
    kg=5;
}
else if(grtest==r2curposition){
    gkill=gkill+1;
       nkillchance=nkillchance+1
       kg=6;
   }
else if(grtest==r3curposition){
    gkill=gkill+1;
       nkillchance=nkillchance+1
       kg=7;
   }
else if(grtest==r4curposition){
    gkill=gkill+1;
       nkillchance=nkillchance+1
       kg=8;
   }
else if(gytest==y1curposition){
    gkill=gkill+1;
       nkillchance=nkillchance+1
       kg=9;
   }
else if(gytest==y2curposition){
    gkill=gkill+1;
       nkillchance=nkillchance+1
       kg=10;
   }
else if(gytest==y3curposition){
    gkill=gkill+1;
       nkillchance=nkillchance+1
       kg=11;
   }
else if(gytest==y4curposition){
 gkill=gkill+1;
    nkillchance=nkillchance+1
    kg=12;
}
 else if(gbtest==b1curposition){
    gkill=gkill+1;
       nkillchance=nkillchance+1
       kg=1;
   }
else if(gbtest==b2curposition){
    gkill=gkill+1;
       nkillchance=nkillchance+1
       kg=2;
   }
else if(gbtest==b3curposition){
 gkill=gkill+1;
    nkillchance=nkillchance+1
    kg=3;
}
else if(gbtest==b4curposition){
    gkill=gkill+1;
       nkillchance=nkillchance+1
       kg=4;
   }
    else{
        nkillchance=0
    }

}
     else{
         nkillchance=0
     }
 }

 if((b==0)&&(nkillchance==0)&&(killchance==0))
     {
     turnchange();
     }
     console.log("nkillchance"+nkillchance)

 if(check==0){
     if((nkillchance!=0)){
         diceclick.enabled=true;
         mousearea1.enabled=false;
         extrachance.opacity=1;
         }
}

 if(check==1){
     if(nkillchance>0){
      killchance=killchance+1}
     tdelay.running=true;

  }
 console.log("killchance"+killchance)
 if(kg==1){
     console.log("killing b1")
     kg=0;
     b1.x=290
     b1.y=158
     b1curposition=1;
     bmovedirection[1]=0
      nkillchance=nkillchance-1;

 }
 else if(kg==2){
     console.log("killing b2")
     kg=0;
     b2.x=320
     b2.y=150
     b2curposition=1;
     bmovedirection[2]=0
      nkillchance=nkillchance-1;

 }
 else if(kg==3){
     console.log("killing b3")
     kg=0;
     b3.x=336
     b3.y=182
     b3curposition=1;
     bmovedirection[3]=0
      nkillchance=nkillchance-1;


 }
 else if(kg==4){
     console.log("killing b4")
     kg=0;
     b4.x=300
     b4.y=192
     b4curposition=1;
     bmovedirection[4]=0
      nkillchance=nkillchance-1;
 }
 else if(kg==5){
     console.log("killing r1")
     kg=0;
     r1.x=174
     r1.y=16
     r1curposition=1;
     rmovedirection[1]=0
      nkillchance=nkillchance-1;
 }
 else if(kg==6){
     console.log("killing r2")
     kg=0;
     r2.x=188
     r2.y=30
      r2curposition=1;
     rmovedirection[2]=0
      nkillchance=nkillchance-1;
 }
 else if(kg==7){
     console.log("killing r3")
     kg=0;
     r3.x=174
     r3.y=42
      r3curposition=1;
     rmovedirection[3]=0
      nkillchance=nkillchance-1;
 }
 else if(kg==8){
     console.log("killing r4")
     kg=0;
     r4.x=160
     r4.y=30
      r4curposition=1;
     rmovedirection[4]=0
      nkillchance=nkillchance-1;
 }
 else if(kg==9){
     console.log("killing y1")
     kg=0;
     y1.x=24
     y1.y=160
      y1curposition=1;
     ymovedirection[1]=0
      nkillchance=nkillchance-1;
 }
 else if(kg==10){
     console.log("killing y2")
     kg=0;
     y2.x=48
     y2.y=160
      y2curposition=1;
     ymovedirection[2]=0
      nkillchance=nkillchance-1;
 }
 else if(kg==11){
     console.log("killing y3")
     kg=0;
     y3.x=48
     y3.y=184
      y3curposition=1;
     ymovedirection[3]=0
      nkillchance=nkillchance-1;
 }
 else if(kg==12){
     console.log("killing y4")
     kg=0;
     y4.x=24
     y4.y=184
      y4curposition=1;
     ymovedirection[4]=0
      nkillchance=nkillchance-1;
 }
 }
}
function rkillcheck(r){
    if((r1curposition==25)&&(r2curposition==25)&&(r3curposition==25)&&(r4curposition==25)){
        console.log("$$$$$$$$$$ red survived $$$$$$$$$")
        rwin=1;
        won.opacity=1;
        twon.running=true;
        console.log("you cant play anymore!!!!")
        console.log("changing turn.....")
       // turnchange();

    }

else{  if(r==r1){
    if((r1curposition!=13)&&(r1curposition!=9)&&(r1curposition!=5)&&(r1curposition!=25))
    {
        if((r1curposition>=1)&&(r1curposition<=8)){
            rgtest=r1curposition+8;
        }
        else if((r1curposition>=9)&&(r1curposition<=16)){
            rgtest=r1curposition-8;
        }
        else if((r1curposition>=17)&&(r1curposition<=20)){
            rgtest=r1curposition+4;
        }
        else if((r1curposition>=21)&&(r1curposition<=24)){
            rgtest=r1curposition-4;
        }
        if((r1curposition>=1)&&(r1curposition<=12)){
            rbtest=r1curposition+4
        }
        else if((r1curposition>=13)&&(r1curposition<=16)){
            rbtest=r1curposition-12
        }
        else if((r1curposition>=17)&&(r1curposition<=18)){
            rbtest=r1curposition+6
        }
        else if((r1curposition>=19)&&(r1curposition<=24)){
            rbtest=r1curposition-2
        }
        if((r1curposition>=1)&&(r1curposition<=4)){
            rytest=r1curposition+12
        }
        else if((r1curposition>=5)&&(r1curposition<=16)){
            rytest=r1curposition-4
        }
        else if((r1curposition>=17)&&(r1curposition<=22)){
            rytest=r1curposition+2
        }
        else if((r1curposition>=23)&&(r1curposition<=24)){
            rytest=r1curposition-6
        }
        console.log("rbtest="+rbtest)
        console.log("rgtest="+rgtest)
        console.log("rytest="+rytest)
        console.log("g1curposition"+g1curposition)
        console.log("g2curposition"+g2curposition)
        console.log("g3curposition"+g3curposition)
        console.log("g4curposition"+g4curposition)
        console.log("r1curposition"+r1curposition)
        console.log("r2curposition"+r2curposition)
        console.log("r3curposition"+r3curposition)
        console.log("r4curposition"+r4curposition)
        console.log("b1curposition"+b1curposition)
        console.log("b2curposition"+b2curposition)
        console.log("b3curposition"+b3curposition)
        console.log("b4curposition"+b4curposition)
        console.log("y1curposition"+y1curposition)
        console.log("y2curposition"+y2curposition)
        console.log("y3curposition"+y3curposition)
        console.log("y4curposition"+y4curposition)

    if(rytest==y1curposition){

        rkill=rkill+1;
        rkillchance=rkillchance+1;
        kr=1;

    }
    else if(rytest==y2curposition){

        rkill=rkill+1;
        rkillchance=rkillchance+1;
        kr=2;

    }
    else if(rytest==y3curposition){

        rkill=rkill+1;
        rkillchance=rkillchance+1;
        kr=3;

    }
    else if(rytest==y4curposition){

        rkill=rkill+1;
        rkillchance=rkillchance+1;
        kr=4;

    }
   else if(rgtest==g1curposition){

        rkill=rkill+1;
        rkillchance=rkillchance+1;
        kr=5;

    }
    else if(rgtest==g2curposition){

        rkill=rkill+1;
        rkillchance=rkillchance+1;
        kr=6;

    }
    else if(rgtest==g3curposition){

        rkill=rkill+1;
        rkillchance=rkillchance+1;
        kr=7;

    }
    else if(rgtest==g4curposition){

        rkill=rkill+1;
        rkillchance=rkillchance+1;
        kr=8;

    }
   else if(rbtest==b1curposition){

        rkill=rkill+1;
        rkillchance=rkillchance+1;
        kr=9;

    }
    else if(rbtest==b2curposition){

        rkill=rkill+1;
        rkillchance=rkillchance+1;
        kr=10;

    }
    else if(rbtest==b3curposition){

        rkill=rkill+1;
        rkillchance=rkillchance+1;
        kr=11;

    }
    else if(rbtest==b4curposition){

        rkill=rkill+1;
        rkillchance=rkillchance+1;
        kr=12;

    }


    else{
        rkillchance=0
    }}
else{
     rkillchance=0
}
           }
if(r==r2){
    if((r2curposition!=13)&&(r2curposition!=9)&&(r2curposition!=5)&&(r2curposition!=25))
    {

            if((r2curposition>=1)&&(r2curposition<=8)){
                rgtest=r2curposition+8;
            }
            else if((r2curposition>=9)&&(r2curposition<=16)){
                rgtest=r2curposition-8;
            }
            else if((r2curposition>=17)&&(r2curposition<=20)){
                rgtest=r2curposition+4;
            }
            else if((r2curposition>=21)&&(r2curposition<=24)){
                rgtest=r2curposition-4;
            }
            if((r2curposition>=1)&&(r2curposition<=12)){
                rbtest=r2curposition+4
            }
            else if((r2curposition>=13)&&(r2curposition<=16)){
                rbtest=r2curposition-12
            }
            else if((r2curposition>=17)&&(r2curposition<=18)){
                rbtest=r2curposition+6
            }
            else if((r2curposition>=19)&&(r2curposition<=24)){
                rbtest=r2curposition-2
            }
            if((r2curposition>=1)&&(r2curposition<=4)){
                rytest=r2curposition+12
            }
            else if((r2curposition>=5)&&(r2curposition<=16)){
                rytest=r2curposition-4
            }
            else if((r2curposition>=17)&&(r2curposition<=22)){
                rytest=r2curposition+2
            }
            else if((r2curposition>=23)&&(r2curposition<=24)){
                rytest=r2curposition-6
            }
            console.log("rbtest="+rbtest)
            console.log("rgtest="+rgtest)
            console.log("rytest="+rytest)
            console.log("g1curposition"+g1curposition)
            console.log("g2curposition"+g2curposition)
            console.log("g3curposition"+g3curposition)
            console.log("g4curposition"+g4curposition)
            console.log("r1curposition"+r1curposition)
            console.log("r2curposition"+r2curposition)
            console.log("r3curposition"+r3curposition)
            console.log("r4curposition"+r4curposition)
            console.log("b1curposition"+b1curposition)
            console.log("b2curposition"+b2curposition)
            console.log("b3curposition"+b3curposition)
            console.log("b4curposition"+b4curposition)
            console.log("y1curposition"+y1curposition)
            console.log("y2curposition"+y2curposition)
            console.log("y3curposition"+y3curposition)
            console.log("y4curposition"+y4curposition)

        if(rytest==y1curposition){

            rkill=rkill+1;
            rkillchance=rkillchance+1;
            kr=1;

        }
        else if(rytest==y2curposition){

            rkill=rkill+1;
            rkillchance=rkillchance+1;
            kr=2;

        }
        else if(rytest==y3curposition){

            rkill=rkill+1;
            rkillchance=rkillchance+1;
            kr=3;

        }
        else if(rytest==y4curposition){

            rkill=rkill+1;
            rkillchance=rkillchance+1;
            kr=4;

        }
       else if(rgtest==g1curposition){

            rkill=rkill+1;
            rkillchance=rkillchance+1;
            kr=5;

        }
        else if(rgtest==g2curposition){

            rkill=rkill+1;
            rkillchance=rkillchance+1;
            kr=6;

        }
        else if(rgtest==g3curposition){

            rkill=rkill+1;
            rkillchance=rkillchance+1;
            kr=7;

        }
        else if(rgtest==g4curposition){

            rkill=rkill+1;
            rkillchance=rkillchance+1;
            kr=8;

        }
       else if(rbtest==b1curposition){

            rkill=rkill+1;
            rkillchance=rkillchance+1;
            kr=9;

        }
        else if(rbtest==b2curposition){

            rkill=rkill+1;
            rkillchance=rkillchance+1;
            kr=10;

        }
        else if(rbtest==b3curposition){

            rkill=rkill+1;
            rkillchance=rkillchance+1;
            kr=11;

        }
        else if(rbtest==b4curposition){

            rkill=rkill+1;
            rkillchance=rkillchance+1;
            kr=12;

        }


    else{
        rkillchance=0
    }
}
    else{
        rkillchance=0;
    }
}
if(r==r3){
    if((r3curposition!=13)&&(r3curposition!=9)&&(r3curposition!=5)&&(r3curposition!=25))
    {
        if((r3curposition>=1)&&(r3curposition<=8)){
            rgtest=r3curposition+8;
        }
        else if((r3curposition>=9)&&(r3curposition<=16)){
            rgtest=r3curposition-8;
        }
        else if((r3curposition>=17)&&(r3curposition<=20)){
            rgtest=r3curposition+4;
        }
        else if((r3curposition>=21)&&(r3curposition<=24)){
            rgtest=r3curposition-4;
        }
        if((r3curposition>=1)&&(r3curposition<=12)){
            rbtest=r3curposition+4
        }
        else if((r3curposition>=13)&&(r3curposition<=16)){
            rbtest=r3curposition-12
        }
        else if((r3curposition>=17)&&(r3curposition<=18)){
            rbtest=r3curposition+6
        }
        else if((r3curposition>=19)&&(r3curposition<=24)){
            rbtest=r3curposition-2
        }
        if((r3curposition>=1)&&(r3curposition<=4)){
            rytest=r3curposition+12
        }
        else if((r3curposition>=5)&&(r3curposition<=16)){
            rytest=r3curposition-4
        }
        else if((r3curposition>=17)&&(r3curposition<=22)){
            rytest=r3curposition+2
        }
        else if((r3curposition>=23)&&(r3curposition<=24)){
            rytest=r3curposition-6
        }
        console.log("rbtest="+rbtest)
        console.log("rgtest="+rgtest)
        console.log("rytest="+rytest)
        console.log("g1curposition"+g1curposition)
        console.log("g2curposition"+g2curposition)
        console.log("g3curposition"+g3curposition)
        console.log("g4curposition"+g4curposition)
        console.log("r1curposition"+r1curposition)
        console.log("r2curposition"+r2curposition)
        console.log("r3curposition"+r3curposition)
        console.log("r4curposition"+r4curposition)
        console.log("b1curposition"+b1curposition)
        console.log("b2curposition"+b2curposition)
        console.log("b3curposition"+b3curposition)
        console.log("b4curposition"+b4curposition)
        console.log("y1curposition"+y1curposition)
        console.log("y2curposition"+y2curposition)
        console.log("y3curposition"+y3curposition)
        console.log("y4curposition"+y4curposition)

    if(rytest==y1curposition){

        rkill=rkill+1;
        rkillchance=rkillchance+1;
        kr=1;

    }
    else if(rytest==y2curposition){

        rkill=rkill+1;
        rkillchance=rkillchance+1;
        kr=2;

    }
    else if(rytest==y3curposition){

        rkill=rkill+1;
        rkillchance=rkillchance+1;
        kr=3;

    }
    else if(rytest==y4curposition){

        rkill=rkill+1;
        rkillchance=rkillchance+1;
        kr=4;

    }
   else if(rgtest==g1curposition){

        rkill=rkill+1;
        rkillchance=rkillchance+1;
        kr=5;

    }
    else if(rgtest==g2curposition){

        rkill=rkill+1;
        rkillchance=rkillchance+1;
        kr=6;

    }
    else if(rgtest==g3curposition){

        rkill=rkill+1;
        rkillchance=rkillchance+1;
        kr=7;

    }
    else if(rgtest==g4curposition){

        rkill=rkill+1;
        rkillchance=rkillchance+1;
        kr=8;

    }
   else if(rbtest==b1curposition){

        rkill=rkill+1;
        rkillchance=rkillchance+1;
        kr=9;

    }
    else if(rbtest==b2curposition){

        rkill=rkill+1;
        rkillchance=rkillchance+1;
        kr=10;

    }
    else if(rbtest==b3curposition){

        rkill=rkill+1;
        rkillchance=rkillchance+1;
        kr=11;

    }
    else if(rbtest==b4curposition){

        rkill=rkill+1;
        rkillchance=rkillchance+1;
        kr=12;

    }


    else{
        rkillchance=0
    }

    }
    else{
        rkillchance=0;

    }
}
if(r==r4){
    if((r4curposition!=13)&&(r4curposition!=9)&&(r4curposition!=5)&&(r4curposition!=25))
    {
        if((r4curposition>=1)&&(r4curposition<=8)){
            rgtest=r4curposition+8;
        }
        else if((r4curposition>=9)&&(r4curposition<=16)){
            rgtest=r4curposition-8;
        }
        else if((r4curposition>=17)&&(r4curposition<=20)){
            rgtest=r4curposition+4;
        }
        else if((r4curposition>=21)&&(r4curposition<=24)){
            rgtest=r4curposition-4;
        }
        if((r4curposition>=1)&&(r4curposition<=12)){
            rbtest=r4curposition+4
        }
        else if((r4curposition>=13)&&(r4curposition<=16)){
            rbtest=r4curposition-12
        }
        else if((r4curposition>=17)&&(r4curposition<=18)){
            rbtest=r4curposition+6
        }
        else if((r4curposition>=19)&&(r4curposition<=24)){
            rbtest=r4curposition-2
        }
        if((r4curposition>=1)&&(r4curposition<=4)){
            rytest=r4curposition+12
        }
        else if((r4curposition>=5)&&(r4curposition<=16)){
            rytest=r4curposition-4
        }
        else if((r4curposition>=17)&&(r4curposition<=22)){
            rytest=r4curposition+2
        }
        else if((r4curposition>=23)&&(r4curposition<=24)){
            rytest=r4curposition-6
        }
        console.log("rbtest="+rbtest)
        console.log("rgtest="+rgtest)
        console.log("rytest="+rytest)
        console.log("g1curposition"+g1curposition)
        console.log("g2curposition"+g2curposition)
        console.log("g3curposition"+g3curposition)
        console.log("g4curposition"+g4curposition)
        console.log("r1curposition"+r1curposition)
        console.log("r2curposition"+r2curposition)
        console.log("r3curposition"+r3curposition)
        console.log("r4curposition"+r4curposition)
        console.log("b1curposition"+b1curposition)
        console.log("b2curposition"+b2curposition)
        console.log("b3curposition"+b3curposition)
        console.log("b4curposition"+b4curposition)
        console.log("y1curposition"+y1curposition)
        console.log("y2curposition"+y2curposition)
        console.log("y3curposition"+y3curposition)
        console.log("y4curposition"+y4curposition)


    if(rytest==y1curposition){

        rkill=rkill+1;
        rkillchance=rkillchance+1;
        kr=1;

    }
    else if(rytest==y2curposition){

        rkill=rkill+1;
        rkillchance=rkillchance+1;
        kr=2;

    }
    else if(rytest==y3curposition){

        rkill=rkill+1;
        rkillchance=rkillchance+1;
        kr=3;

    }
    else if(rytest==y4curposition){

        rkill=rkill+1;
        rkillchance=rkillchance+1;
        kr=4;

    }
   else if(rgtest==g1curposition){

        rkill=rkill+1;
        rkillchance=rkillchance+1;
        kr=5;

    }
    else if(rgtest==g2curposition){

        rkill=rkill+1;
        rkillchance=rkillchance+1;
        kr=6;

    }
    else if(rgtest==g3curposition){

        rkill=rkill+1;
        rkillchance=rkillchance+1;
        kr=7;

    }
    else if(rgtest==g4curposition){

        rkill=rkill+1;
        rkillchance=rkillchance+1;
        kr=8;

    }
   else if(rbtest==b1curposition){

        rkill=rkill+1;
        rkillchance=rkillchance+1;
        kr=9;

    }
    else if(rbtest==b2curposition){

        rkill=rkill+1;
        rkillchance=rkillchance+1;
        kr=10;

    }
    else if(rbtest==b3curposition){

        rkill=rkill+1;
        rkillchance=rkillchance+1;
        kr=11;

    }
    else if(rbtest==b4curposition){

        rkill=rkill+1;
        rkillchance=rkillchance+1;
        kr=12;

    }


    else{
        rkillchance=0
    }

    }
    else{
        rkillchance=0
    }
}
if((b==0)&&(rkillchance==0)&&(killchance==0))
{
turnchange();
}
console.log("rkillchance"+rkillchance)
console.log("killchance"+killchance)
if(check==0){
    console.log("executing check==0")
    if((rkillchance!=0)){
    diceclick.enabled=true;
    mousearea1.enabled=false;
    extrachance.opacity=1;
    }
}

if(check==1){
    console.log("executing check==1")
if(rkillchance>0){
 killchance=killchance+1}
tdelay.running=true;

}
if(kr==1){
    console.log("killing y1")
    kr=0;
    y1.x=24
    y1.y=160
    y1curposition=1;
    ymovedirection[1]=0
    rkillchance=rkillchance-1;

}
else if(kr==2){
    console.log("killing y2")
    kr=0;
    y2.x=48
    y2.y=160
    y2curposition=1;
    ymovedirection[2]=0
     rkillchance=rkillchance-1;

}
else if(kr==3){
    console.log("killing y3")
    kr=0;
    y3.x=48
    y3.y=184
    y3curposition=1;
    ymovedirection[3]=0
     rkillchance=rkillchance-1;

}
else if(kr==4){
    console.log("killing y4")
    kr=0;
    y4.x=24
    y4.y=184
    y4curposition=1;
    ymovedirection[4]=0
     rkillchance=rkillchance-1;

}
else if(kr==5){
    console.log("killing g1")
    kr=0;
    g1.x=166
    g1.y=290
    g1curposition=1;
    gmovedirection[1]=0
    rkillchance=rkillchance-1;

}
else if(kr==6){
    console.log("killing g2")
    kr=0;
    g2.x=198
    g2.y=300
     g2curposition=1;
    gmovedirection[2]=0
     rkillchance=rkillchance-1;

}
else if(kr==7){
    console.log("killing g3")
    kr=0;
    g3.x=184
    g3.y=328
     g3curposition=1;
    gmovedirection[3]=0
     rkillchance=rkillchance-1;

}
else if(kr==8){
    console.log("killing g4")
    kr=0;
    g4.x=150
    g4.y=320
     g4curposition=1;
    gmovedirection[4]=0
     rkillchance=rkillchance-1;

}
else if(kr==9){
    console.log("killing b1")
    kr=0;
    b1.x=290
    b1.y=158
     b1curposition=1;
    bmovedirection[1]=0
    rkillchance=rkillchance-1;

}
else if(kr==10){
    console.log("killing b2")
    kr=0;
    b2.x=320
    b2.y=150
     b2curposition=1;
    bmovedirection[2]=0
     rkillchance=rkillchance-1;

}
else if(kr==11){
    console.log("killing b3")
    kr=0;
    b3.x=336
    b3.y=182
     b3curposition=1;
    bmovedirection[3]=0
     rkillchance=rkillchance-1;

}
else if(kr==12){
    console.log("killing b4")
    kr=0;
    b4.x=300
    b4.y=192
     b4curposition=1;
    bmovedirection[4]=0
     rkillchance=rkillchance-1;

}
}
}
function ykillcheck(s){
    if((y1curposition==25)&&(y2curposition==25)&&(y3curposition==25)&&(y4curposition==25)){
        console.log("$$$$$$$$$$ yellow survived $$$$$$$$$")
        ywin=1;
        won.opacity=1;
        twon.running=true;
        console.log("you cant play anymore!!!!")
        console.log("changing turn.....")
        //turnchange();

    }
else{  if(s==y1){
    if((y1curposition!=13)&&(y1curposition!=5)&&(y1curposition!=9)&&(y1curposition!=25))
    {
        if((y1curposition>=1)&&(y1curposition<=4)){
            ygtest=y1curposition+12
        }
        else if((y1curposition>=5)&&(y1curposition<=16)){
            ygtest=y1curposition-4
        }
        else if((y1curposition>=17)&&(y1curposition<=22)){
            ygtest=y1curposition+2

        }
        else if((y1curposition>=23)&&(y1curposition<=24)){
            ygtest=y1curposition-6
        }
        if((y1curposition>=1)&&(y1curposition<=12)){
            yrtest=y1curposition+4
        }
        else if((y1curposition>=13)&&(y1curposition<=16)){
            yrtest=y1curposition-12
        }
        else if((y1curposition>=17)&&(y1curposition<=18)){
            yrtest=y1curposition+6
        }
        else if((y1curposition>=19)&&(y1curposition<=24)){
            yrtest=y1curposition-2
        }
        if((y1curposition>=1)&&(y1curposition<=8)){
            ybtest=y1curposition+8
        }
        else if((y1curposition>=9)&&(y1curposition<=16)){
            ybtest=y1curposition-8
        }
        else if((y1curposition>=17)&&(y1curposition<=20)){
            ybtest=y1curposition+4
        }
        else if((y1curposition>=21)&&(y1curposition<=24)){
            ybtest=y1curposition-4
        }
        console.log("ybtest="+ybtest)
        console.log("yrtest="+yrtest)
        console.log("ygtest="+ygtest)
        console.log(g1curposition)
        console.log(g2curposition)
        console.log(g3curposition)
        console.log(g4curposition)
        console.log(r1curposition)
        console.log(r2curposition)
        console.log(r3curposition)
        console.log(r4curposition)
        console.log(b1curposition)
        console.log(b2curposition)
        console.log(b3curposition)
        console.log(b4curposition)
        console.log(y1curposition)
        console.log(y2curposition)
        console.log(y3curposition)
        console.log(y4curposition)

    if(ygtest==g1curposition){

        ykill=ykill+1;
        ykillchance=ykillchance+1;
        ky=1;

    }
    else  if(ygtest==g2curposition){

        ykill=ykill+1;
        ykillchance=ykillchance+1;
        ky=2;

    }
    else  if(ygtest==g3curposition){

        ykill=ykill+1;
        ykillchance=ykillchance+1;
        ky=3;

    }

    else  if(ygtest==g4curposition){

        ykill=ykill+1;
        ykillchance=ykillchance+1;
        ky=4;

    }
    else if(ybtest==b1curposition){

        ykill=ykill+1;
        ykillchance=ykillchance+1;
        ky=5;

    }
    else  if(ybtest==b2curposition){

        ykill=ykill+1;
        ykillchance=ykillchance+1;
        ky=6;

    }
    else  if(ybtest==b3curposition){

        ykill=ykill+1;
        ykillchance=ykillchance+1;
        ky=7;

    }

    else  if(ybtest==b4curposition){

        ykill=ykill+1;
        ykillchance=ykillchance+1;
        ky=8;

    }
   else if(yrtest==r1curposition){

        ykill=ykill+1;
        ykillchance=ykillchance+1;
        ky=9;

    }
    else if(yrtest==r2curposition){

        ykill=ykill+1;
        ykillchance=ykillchance+1;
        ky=10;

    }
    else if(yrtest==r3curposition){

        ykill=ykill+1;
        ykillchance=ykillchance+1;
        ky=11;

    }
    else if(yrtest==r4curposition){

        ykill=ykill+1;
        ykillchance=ykillchance+1;
        ky=12;

    }

    else{
        ykillchance=0
    }
           }
    else{
        ykillchance=0
    }}

if(s==y2){
    if((y2curposition!=13)&&(y2curposition!=5)&&(y2curposition!=9)&&(y2curposition!=25))
    {
        if((y2curposition>=1)&&(y2curposition<=4)){
            ygtest=y2curposition+12
        }
        else if((y2curposition>=5)&&(y2curposition<=16)){
            ygtest=y2curposition-4
        }
        else if((y2curposition>=17)&&(y2curposition<=22)){
            ygtest=y2curposition+2

        }
        else if((y2curposition>=23)&&(y2curposition<=24)){
            ygtest=y2curposition-6
        }
        if((y2curposition>=1)&&(y2curposition<=12)){
            yrtest=y2curposition+4
        }
        else if((y2curposition>=13)&&(y2curposition<=16)){
            yrtest=y2curposition-12
        }
        else if((y2curposition>=17)&&(y2curposition<=18)){
            yrtest=y2curposition+6
        }
        else if((y2curposition>=19)&&(y2curposition<=24)){
            yrtest=y2curposition-2
        }
        if((y2curposition>=1)&&(y2curposition<=8)){
            ybtest=y2curposition+8
        }
        else if((y2curposition>=9)&&(y2curposition<=16)){
            ybtest=y2curposition-8
        }
        else if((y2curposition>=17)&&(y2curposition<=20)){
            ybtest=y2curposition+4
        }
        else if((y2curposition>=21)&&(y2curposition<=24)){
            ybtest=y2curposition-4
        }
        console.log("ybtest="+ybtest)
        console.log("yrtest="+yrtest)
        console.log("ygtest="+ygtest)
        console.log(g1curposition)
        console.log(g2curposition)
        console.log(g3curposition)
        console.log(g4curposition)
        console.log(r1curposition)
        console.log(r2curposition)
        console.log(r3curposition)
        console.log(r4curposition)
        console.log(b1curposition)
        console.log(b2curposition)
        console.log(b3curposition)
        console.log(b4curposition)
        console.log(y1curposition)
        console.log(y2curposition)
        console.log(y3curposition)
        console.log(y4curposition)


    if(ygtest==g1curposition){

        ykill=ykill+1;
        ykillchance=ykillchance+1;
        ky=1;

    }
    else  if(ygtest==g2curposition){

        ykill=ykill+1;
        ykillchance=ykillchance+1;
        ky=2;

    }
    else  if(ygtest==g3curposition){

        ykill=ykill+1;
        ykillchance=ykillchance+1;
        ky=3;

    }

    else  if(ygtest==g4curposition){

        ykill=ykill+1;
        ykillchance=ykillchance+1;
        ky=4;

    }
    else if(ybtest==b1curposition){

        ykill=ykill+1;
        ykillchance=ykillchance+1;
        ky=5;

    }
    else  if(ybtest==b2curposition){

        ykill=ykill+1;
        ykillchance=ykillchance+1;
        ky=6;

    }
    else  if(ybtest==b3curposition){

        ykill=ykill+1;
        ykillchance=ykillchance+1;
        ky=7;

    }

    else  if(ybtest==b4curposition){

        ykill=ykill+1;
        ykillchance=ykillchance+1;
        ky=8;

    }
   else if(yrtest==r1curposition){

        ykill=ykill+1;
        ykillchance=ykillchance+1;
        ky=9;

    }
    else if(yrtest==r2curposition){

        ykill=ykill+1;
        ykillchance=ykillchance+1;
        ky=10;

    }
    else if(yrtest==r3curposition){

        ykill=ykill+1;
        ykillchance=ykillchance+1;
        ky=11;

    }
    else if(yrtest==r4curposition){

        ykill=ykill+1;
        ykillchance=ykillchance+1;
        ky=12;

    }


    else{
        ykillchance=0
    }
           }
    else{
        ykillchance=0
    }}

if(s==y3){
    if((y3curposition!=13)&&(y3curposition!=5)&&(y3curposition!=9)&&(y3curposition!=25))
    {
        if((y3curposition>=1)&&(y3curposition<=4)){
            ygtest=y3curposition+12
        }
        else if((y3curposition>=5)&&(y3curposition<=16)){
            ygtest=y3curposition-4
        }
        else if((y3curposition>=17)&&(y3curposition<=22)){
            ygtest=y3curposition+2

        }
        else if((y3curposition>=23)&&(y3curposition<=24)){
            ygtest=y3curposition-6
        }
        if((y3curposition>=1)&&(y3curposition<=12)){
            yrtest=y3curposition+4
        }
        else if((y3curposition>=13)&&(y3curposition<=16)){
            yrtest=y3curposition-12
        }
        else if((y3curposition>=17)&&(y3curposition<=18)){
            yrtest=y3curposition+6
        }
        else if((y3curposition>=19)&&(y3curposition<=24)){
            yrtest=y3curposition-2
        }
        if((y3curposition>=1)&&(y3curposition<=8)){
            ybtest=y3curposition+8
        }
        else if((y3curposition>=9)&&(y3curposition<=16)){
            ybtest=y3curposition-8
        }
        else if((y3curposition>=17)&&(y3curposition<=20)){
            ybtest=y3curposition+4
        }
        else if((y3curposition>=21)&&(y3curposition<=24)){
            ybtest=y3curposition-4
        }
        console.log("ybtest="+ybtest)
        console.log("yrtest="+yrtest)
        console.log("ygtest="+ygtest)
        console.log(g1curposition)
        console.log(g2curposition)
        console.log(g3curposition)
        console.log(g4curposition)
        console.log(r1curposition)
        console.log(r2curposition)
        console.log(r3curposition)
        console.log(r4curposition)
        console.log(b1curposition)
        console.log(b2curposition)
        console.log(b3curposition)
        console.log(b4curposition)
        console.log(y1curposition)
        console.log(y2curposition)
        console.log(y3curposition)
        console.log(y4curposition)


    if(ygtest==g1curposition){

        ykill=ykill+1;
        ykillchance=ykillchance+1;
        ky=1;

    }
    else  if(ygtest==g2curposition){

        ykill=ykill+1;
        ykillchance=ykillchance+1;
        ky=2;

    }
    else  if(ygtest==g3curposition){

        ykill=ykill+1;
        ykillchance=ykillchance+1;
        ky=3;

    }

    else  if(ygtest==g4curposition){

        ykill=ykill+1;
        ykillchance=ykillchance+1;
        ky=4;

    }
    else if(ybtest==b1curposition){

        ykill=ykill+1;
        ykillchance=ykillchance+1;
        ky=5;

    }
    else  if(ybtest==b2curposition){

        ykill=ykill+1;
        ykillchance=ykillchance+1;
        ky=6;

    }
    else  if(ybtest==b3curposition){

        ykill=ykill+1;
        ykillchance=ykillchance+1;
        ky=7;

    }

    else  if(ybtest==b4curposition){

        ykill=ykill+1;
        ykillchance=ykillchance+1;
        ky=8;

    }
   else if(yrtest==r1curposition){

        ykill=ykill+1;
        ykillchance=ykillchance+1;
        ky=9;

    }
    else if(yrtest==r2curposition){

        ykill=ykill+1;
        ykillchance=ykillchance+1;
        ky=10;

    }
    else if(yrtest==r3curposition){

        ykill=ykill+1;
        ykillchance=ykillchance+1;
        ky=11;

    }
    else if(yrtest==r4curposition){

        ykill=ykill+1;
        ykillchance=ykillchance+1;
        ky=12;

    }

    else{
        ykillchance=0
    }
           }
    else{
        ykillchance=0
    }
}

if(s==y4){
    if((y4curposition!=13)&&(y4curposition!=5)&&(y4curposition!=9)&&(y4curposition!=25))
    {
        if((y4curposition>=1)&&(y4curposition<=4)){
            ygtest=y4curposition+12
        }
        else if((y4curposition>=5)&&(y4curposition<=16)){
            ygtest=y4curposition-4
        }
        else if((y4curposition>=17)&&(y4curposition<=22)){
            ygtest=y4curposition+2

        }
        else if((y4curposition>=23)&&(y4curposition<=24)){
            ygtest=y4curposition-6
        }
        if((y4curposition>=1)&&(y4curposition<=12)){
            yrtest=y4curposition+4
        }
        else if((y4curposition>=13)&&(y4curposition<=16)){
            yrtest=y4curposition-12
        }
        else if((y4curposition>=17)&&(y4curposition<=18)){
            yrtest=y4curposition+6
        }
        else if((y4curposition>=19)&&(y4curposition<=24)){
            yrtest=y4curposition-2
        }
        if((y4curposition>=1)&&(y4curposition<=8)){
            ybtest=y4curposition+8
        }
        else if((y4curposition>=9)&&(y4curposition<=16)){
            ybtest=y4curposition-8
        }
        else if((y4curposition>=17)&&(y4curposition<=20)){
            ybtest=y4curposition+4
        }
        else if((y4curposition>=21)&&(y4curposition<=24)){
            ybtest=y4curposition-4
        }
        console.log("ybtest="+ybtest)
        console.log("yrtest="+yrtest)
        console.log("ygtest="+ygtest)
        console.log(g1curposition)
        console.log(g2curposition)
        console.log(g3curposition)
        console.log(g4curposition)
        console.log(r1curposition)
        console.log(r2curposition)
        console.log(r3curposition)
        console.log(r4curposition)
        console.log(b1curposition)
        console.log(b2curposition)
        console.log(b3curposition)
        console.log(b4curposition)
        console.log(y1curposition)
        console.log(y2curposition)
        console.log(y3curposition)
        console.log(y4curposition)


    if(ygtest==g1curposition){

        ykill=ykill+1;
        ykillchance=ykillchance+1;
        ky=1;

    }
    else  if(ygtest==g2curposition){

        ykill=ykill+1;
        ykillchance=ykillchance+1;
        ky=2;

    }
    else  if(ygtest==g3curposition){

        ykill=ykill+1;
        ykillchance=ykillchance+1;
        ky=3;

    }

    else  if(ygtest==g4curposition){

        ykill=ykill+1;
        ykillchance=ykillchance+1;
        ky=4;

    }
    else if(ybtest==b1curposition){

        ykill=ykill+1;
        ykillchance=ykillchance+1;
        ky=5;

    }
    else  if(ybtest==b2curposition){

        ykill=ykill+1;
        ykillchance=ykillchance+1;
        ky=6;

    }
    else  if(ybtest==b3curposition){

        ykill=ykill+1;
        ykillchance=ykillchance+1;
        ky=7;

    }

    else  if(ybtest==b4curposition){

        ykill=ykill+1;
        ykillchance=ykillchance+1;
        ky=8;

    }
   else if(yrtest==r1curposition){

        ykill=ykill+1;
        ykillchance=ykillchance+1;
        ky=9;

    }
    else if(yrtest==r2curposition){

        ykill=ykill+1;
        ykillchance=ykillchance+1;
        ky=10;

    }
    else if(yrtest==r3curposition){

        ykill=ykill+1;
        ykillchance=ykillchance+1;
        ky=11;

    }
    else if(yrtest==r4curposition){

        ykill=ykill+1;
        ykillchance=ykillchance+1;
        ky=12;

    }


    else{
        ykillchance=0
    }
           }
    else{
        ykillchance=0
    }
}

if((b==0)&&(ykillchance==0)&&(killchance==0))
{
turnchange();
}
console.log("ykillchance"+ykillchance)
console.log("killchance"+killchance)
if(check==0){
    console.log("executing check==0")
    if((ykillchance!=0)){
    diceclick.enabled=true;
    mousearea1.enabled=false;
    extrachance.opacity=1;
    }
}

if(check==1){
    console.log("executing check==1")
if(ykillchance>0){
 killchance=killchance+1}
tdelay.running=true;

}
if(ky==1){
    console.log("killing g1")
    ky=0;
    g1.x=166
    g1.y=290
    g1curposition=1;
    gmovedirection[1]=0
    ykillchance=ykillchance-1;

}
else if(ky==2){
    console.log("killing g2")
    ky=0;
    g2.x=198
    g2.y=300
     g2curposition=1;
    gmovedirection[2]=0
     ykillchance=ykillchance-1;

}
else if(ky==3){
    console.log("killing g3")
    ky=0;
    g3.x=184
    g3.y=328
     g3curposition=1;
    gmovedirection[3]=0
     ykillchance=ykillchance-1;

}
else if(ky==4){
    console.log("killing g4")
    ky=0;
    g4.x=150
    g4.y=320
     g4curposition=1;
    gmovedirection[4]=0
     ykillchance=ykillchance-1;

}
else if(ky==5){
    console.log("killing b1")
    ky=0;
    b1.x=290
    b1.y=158
     b1curposition=1;
    bmovedirection[1]=0
     ykillchance=ykillchance-1;

}
else if(ky==6){
    console.log("killing b2")
    ky=0;
    b2.x=320
    b2.y=150
    b2curposition=1;
    bmovedirection[2]=0
     ykillchance=ykillchance-1;

}
else if(ky==7){
    console.log("killing b3")
    ky=0;
    b3.x=336
    b3.y=182
    b3curposition=1;
    bmovedirection[3]=0
     ykillchance=ykillchance-1;

}
else if(ky==8){
    console.log("killing b4")
    ky=0;
    b4.x=300
    b4.y=192
    b4curposition=1;
    bmovedirection[4]=0
     ykillchance=ykillchance-1;

}
else if(ky==9){
    console.log("killing r1")
    ky=0;
    r1.x=174
    r1.y=16
    r1curposition=1;
    rmovedirection[1]=0
     ykillchance=ykillchance-1;

}
else if(ky==10){
    console.log("killing r2")
    ky=0;
    r2.x=188
    r2.y=30
    r2curposition=1;
    rmovedirection[2]=0
     ykillchance=ykillchance-1;

}
else if(ky==11){
    console.log("killing r3")
    ky=0;
    r3.x=174
    r3.y=42
    r3curposition=1;
    rmovedirection[3]=0
     ykillchance=ykillchance-1;

}
else if(ky==12){
    console.log("killing r4")
    ky=0;
    r4.x=160
    r4.y=30
    r4curposition=1;
    rmovedirection[4]=0
     ykillchance=ykillchance-1;

}
}
}
function specialmove(dval){
    mousearea1.enabled=false
    dicevalues[b]=dval;
    console.log("b="+b);
    //dicedisplay.text=dval+",";

    if((dval==4)||(dval==8)){
    //tell the user to again click on dice
        b=b+1;
        diceclick.enabled=true;
        console.log("again click on cice value")
        extrachance.opacity=1;
    }else{

        i=b;
        displaychoices(b);}
    }


function displaychoices(b){
    if(b==1){
         console.log("executing i=2");
        if(ma[1]!=1){
        text1.text=dicevalues[0];
        mouse_area1.enabled=true;}
        if(ma[2]!=1){
        text2.text=dicevalues[1];
        mouse_area2.enabled=true;}
        mouse_area3.enabled=false;
        mouse_area4.enabled=false;
        mouse_area5.enabled=false;

      }
     if(b==2){
         console.log("executing i=3");
         if(ma[1]!=1){
         mouse_area1.enabled=true;
          text1.text=dicevalues[0];}
         if(ma[2]!=1){
         mouse_area2.enabled=true;
         text2.text=dicevalues[1];}
         if(ma[3]!=1){
         mouse_area3.enabled=true;
          text3.text=dicevalues[2];}
         mouse_area4.enabled=false;
         mouse_area5.enabled=false;
     }
     if(b==3){
         console.log("executing b=4")
         if(ma[1]!=1){
         mouse_area1.enabled=true;
          text1.text=dicevalues[0];}
         if(ma[2]!=1){
         mouse_area2.enabled=true;
         text2.text=dicevalues[1];}
         if(ma[3]!=1){
         mouse_area3.enabled=true;
         text3.text=dicevalues[2];}
         if(ma[4]!=1){
         mouse_area4.enabled=true;
         text4.text=dicevalues[3];}
         mouse_area5.enabled=false;
     }
     if(b==4){
         console.log("executing b=5")
         if(ma[1]!=1){
         mouse_area1.enabled=true;
          text1.text=dicevalues[0];}
         if(ma[2]!=1){
         mouse_area2.enabled=true;
         text2.text=dicevalues[1];}
         if(ma[3]!=1){
         mouse_area3.enabled=true;
         text3.text=dicevalues[2];}
         if(ma[4]!=1){
         mouse_area4.enabled=true;
         text4.text=dicevalues[3];}
         if(ma[5]!=1){
             mouse_area5.enabled=true;
             text4.text=dicevalues[4];
         }
     }
     mousearea1.enabled=false;
    rectangle3.x=10;
    rectangle3.y=10;
}

function userinput(val){
    valueselected=val;
    allowselect=1;
    console.log("select the pawn to move")
}
function selectionmove(pawnselected){
    if(pawnselected==g1){
        check=1;
        gfinalmovevalue=(valueselected*68)
        gmovepawn=1;
       moveconsent=1;
        tg1.running=true;

    }
    if(pawnselected==g2){
         check=1;
        gfinalmovevalue=(valueselected*68)
        gmovepawn=2;
       moveconsent=1;
        tg1.running=true;
    }
    if(pawnselected==g3){
         check=1;
        gfinalmovevalue=(valueselected*68)
        gmovepawn=3;
       moveconsent=1;
        tg1.running=true;
    }
    if(pawnselected==g4){
         check=1;
        gfinalmovevalue=(valueselected*68)
        gmovepawn=4;
       moveconsent=1;
        tg1.running=true;
    }
    if(pawnselected==b1){
         check=1;
        bfinalmovevalue=(valueselected*68)
        bmovepawn=1;
         moveconsent=1;
        tb1.running=true;
    }
    if(pawnselected==b2){
         check=1;
        bfinalmovevalue=(valueselected*68)
        bmovepawn=2;
         moveconsent=1;
        tb1.running=true;
    }
    if(pawnselected==b3){
         check=1;
        bfinalmovevalue=(valueselected*68)
        bmovepawn=3;
         moveconsent=1;
        tb1.running=true;
    }
    if(pawnselected==b4){
         check=1;
        bfinalmovevalue=(valueselected*68)
        bmovepawn=4;
         moveconsent=1;
        tb1.running=true;
    }
    if(pawnselected==r1){
         check=1;
        rfinalmovevalue=(valueselected*68)
        rmovepawn=1;
         moveconsent=1;
        tr1.running=true;
    }
    if(pawnselected==r2){
         check=1;
        rfinalmovevalue=(valueselected*68)
        rmovepawn=2;
         moveconsent=1;
        tr1.running=true;
    }
    if(pawnselected==r3){
         check=1;
        rfinalmovevalue=(valueselected*68)
        rmovepawn=3;
         moveconsent=1;
        tr1.running=true;
    }
    if(pawnselected==r4){
         check=1;
        rfinalmovevalue=(valueselected*68)
        rmovepawn=4;
         moveconsent=1;
        tr1.running=true;
    }
    if(pawnselected==y1){
         check=1;
        yfinalmovevalue=(valueselected*68)
        ymovepawn=1;
         moveconsent=1;
        ty1.running=true;
    }
    if(pawnselected==y2){
         check=1;
        yfinalmovevalue=(valueselected*68)
        ymovepawn=2;
         moveconsent=1;
        ty1.running=true;
    }
    if(pawnselected==y3){
         check=1;
        yfinalmovevalue=(valueselected*68)
        ymovepawn=3;
         moveconsent=1;
        ty1.running=true;
    }
    if(pawnselected==y4){
         check=1;
        yfinalmovevalue=(valueselected*68)
        ymovepawn=4;
         moveconsent=1;
        ty1.running=true;
    }

}
function backtoselection(){
    if(b==1){
        console.log("executing back 2 sel b=1")
        if((mac[1]==0)||(mac[2]==0)){
            console.log("executing displaychoices")
            displaychoices();

    }
    else{
        check=0;
            console.log("executing turnchange")
         resetspecial();
        rectangle3.x= 8
        rectangle3.y= -368
            console.log("killchance"+"  "+killchance)
            if(killchance>0){
                specialchance=1;
                console.log("specialchance="+specialchance)
                extrachance.opacity=1;
                mousearea1.enabled=true;
                diceclick.enabled=true;

            }
            else {

                mousearea1.enabled=false;
                diceclick.enabled=true;
                turnchange();
            }

    }}

    if(b==2){
         console.log("executing back 2 sel b=2")
        if((mac[1]==0)||(mac[2]==0)||(mac[3]==0)){
            console.log("executing displaychoices")
            displaychoices();
            }

    else{
        check=0;
        console.log("executing turnchange")
             resetspecial()

        rectangle3.x= 8
        rectangle3.y= -368
            if(killchance>0){
                specialchance=1;
                console.log("specialchance="+specialchance)
                extrachance.opacity=1;
                mousearea1.enabled=true;
                diceclick.enabled=true;

            }
            else {

                mousearea1.enabled=false;
                diceclick.enabled=true;
                turnchange();
            }


    }}

    if(b==3){
         console.log("executing back 2 sel b=3")
        if((mac[1]==0)||(mac[2]==0)||(mac[3]==0)||(mac[4]==0)){
            console.log("executing display choices")
            displaychoices();
        }

    else{
        check=0;
        console.log("executing turnchange")
        resetspecial();

        rectangle3.x= 8
        rectangle3.y= -368
            if(killchance>0){
                specialchance=1;
                console.log("specialchance="+specialchance)
                extrachance.opacity=1;
                mousearea1.enabled=true;
                diceclick.enabled=true;
            }
            else {

                mousearea1.enabled=false;
                diceclick.enabled=true;
                turnchange();
            }
    }
}
    if(b==4){
        console.log("executing back 2 sel b=3")
        if((mac[1]==0)||(mac[2]==0)||(mac[3]==0)||(mac[4]==0)||(mac[5]==0)){
            console.log("executing display choices")
            displaychoices();
        }
 else{
        check=0;
        console.log("executing turnchange")
        resetspecial();

        rectangle3.x= 8
        rectangle3.y= -368
            if(killchance>0){
                specialchance=1;
                console.log("specialchance="+specialchance)
                extrachance.opacity=1;
                mousearea1.enabled=true;
                diceclick.enabled=true;
            }
            else {

                mousearea1.enabled=false;
                diceclick.enabled=true;
                turnchange();
            }
    }
}}
function resetspecial(){
    b=0;
    i=0;
    mac[1]=0;
    mac[2]=0;
    mac[3]=0;
    mac[4]=0;
    ma[1]=0;
    ma[2]=0;
    ma[3]=0;
    ma[4]=0;
    check=0;
    allowselect=0
    mouse_area1.enabled=true
    mouse_area2.enabled=true
    mouse_area3.enabled=true
    mouse_area4.enabled=true
    mouse_area5.enabled=true
    return;
}
function extrachances(c){
    console.log("you got "+" c extra chances click on to throw cowrie")
    killchance=killchance-1;
}
function specialfunction(u){
    diceclick.enabled=true;
   // mousearea1.enabled=false;
    killchance=killchance-1;
    if(killchance==0){
        specialchance=0;
    }
    else if(killchance>0){
        if(u==g1){
            moveconsent=1;
            gmovepawn=1;
            gfinalmovevalue=(dicevalue*68);
            tg1.running=true;
        }
        if(u==g2){
             moveconsent=1;
            gmovepawn=2;
            gfinalmovevalue=(dicevalue*68);
            tg1.running=true;
        }
        if(u==g3){
             moveconsent=1;
            gmovepawn=3;
            gfinalmovevalue=(dicevalue*68);
            tg1.running=true;
        }
        if(u==g4){
             moveconsent=1;
            gmovepawn=4;
            gfinalmovevalue=(dicevalue*68);
            tg1.running=true;
        }
        if(u==b1){
             moveconsent=1;
            bmovepawn=1;
            bfinalmovevalue=(dicevalue*68);
            tb1.running=true;
        }
        if(u==b2){
             moveconsent=1;
             bmovepawn=2;
              bfinalmovevalue=(dicevalue*68);
            tb1.running=true;
        }
        if(u==b3){
             moveconsent=1;
             bmovepawn=3;
              bfinalmovevalue=(dicevalue*68);
            tb1.running=true;
        }
        if(u==b4){
             moveconsent=1;
             bmovepawn=4;
              bfinalmovevalue=(dicevalue*68);
            tb1.running=true;
        }
        if(u==r1){
             moveconsent=1;
            rmovepawn=1;
            rfinalmovevalue=(dicevalue*68);
            tr1.running=true;
        }
        if(u==r2){
             moveconsent=1;
             rmovepawn=2;
              rfinalmovevalue=(dicevalue*68);
            tr1.running=true;
        }
        if(u==r3){
             moveconsent=1;
             rmovepawn=3;
              rfinalmovevalue=(dicevalue*68);
            tr1.running=true;
        }
        if(u==r4){
             moveconsent=1;
             rmovepawn=4;
              rfinalmovevalue=(dicevalue*68);
            tr1.running=true;
        }
        if(u==y1){
             moveconsent=1;
            ymovepawn=1;
            yfinalmovevalue=(dicevalue*68);
            ty1.running=true;
        }
        if(u==y2){
             moveconsent=1;
             ymovepawn=2;
              yfinalmovevalue=(dicevalue*68);
            ty1.running=true;
        }
        if(u==y3){
             moveconsent=1;
             ymovepawn=3;
              yfinalmovevalue=(dicevalue*68);
            ty1.running=true;
        }
        if(u==y4){
             moveconsent=1;
             ymovepawn=4;
              yfinalmovevalue=(dicevalue*68);
            ty1.running=true;
        }
    }
}

